<?php
$sub_menu = '910210';
include_once('./_common.php');
include_once(G5_EDITOR_LIB);

auth_check($auth[$sub_menu], 'w');

if ($w == '')
{
    $sound_only = '<strong class="sound_only">필수</strong>';
	
	$com['com_president_display'] = 'display:none;';
	$com['com_manager_display'] = 'display:none;';
	$pdo['pdo_price_display'] = 'display:none;';
	$pdo['pdo_pay_status_text_display'] = 'display:none;';
	$pdo['pdo_prd_times'] = 0;
	$cam['cam_prd_time'] = 0;
    $cam['cam_reviewer_yn'] = 1;
	$cam['cam_recruit_count'] = 0;
    $cam['cam_best_use_yn'] = 1;
    $cam['cam_point_type'] = 'group';
    $cam['cam_reviewer_point'] = 0;
    $cam['cam_best_point'] = 0;
    $html_title = '등록';
	
}
else if ($w == 'u')
{
	$cam = sql_fetch(" SELECT * FROM {$g5['campaign_table']} WHERE cam_idx = '".$cam_idx."' ");
	
	if (!$cam['cam_idx'])
		alert('존재하지 않는 캠페인 자료입니다.');

	$pdo = sql_fetch(" SELECT * FROM {$g5['product_order_table']} WHERE pdo_idx = '".$cam['pdo_idx']."' ");
	if (!$pdo['pdo_idx'])
		alert('존재하지 않는 신청자료입니다.');
	
	$prd = sql_fetch(" SELECT * FROM {$g5['product_table']} WHERE prd_idx = '".$pdo['prd_idx']."' ");
	if (!$prd['prd_idx'])
		alert('존재하지 않는 상품자료입니다.');

	$com = sql_fetch(" SELECT * FROM {$g5['company_table']} WHERE com_idx = '".$cam['com_idx']."' ");
	// 고객 정보
	$mb = get_member($cam['mb_id_company']);
	if (!$mb['mb_id'])
		alert('존재하지 않는 회원자료입니다.');
	
	// 영업자 정보
	$mb2 = get_member($cam['mb_id_saler']);
	
	// 정보등록자 정보
	$mb3 = get_member($cam['mb_id_info']);
	
	$style_mb_id = 'background-color:#dadada;';
	$style_mb_id_saler = 'background-color:#dadada;';
	$style_mb_name_company = 'background-color:#dadada;';
	$style_mb_name_saler = 'background-color:#dadada;';
	$style_mb_name_info = 'background-color:#dadada;';
	$style_prd_name = 'background-color:#dadada;';
	$style_com_name = 'background-color:#dadada;';
	$html_title = '수정';
	
    $cam['cam_name'] = get_text($cam['cam_name']);
    $cam['cam_brief'] = get_text($cam['cam_brief']);
    
	
	// 날짜 초기값 NULL 설정, 배열로 선언해 주세요.
	$date_array=array('cam_info_reg_dt','cam_recruit_start_dt','cam_recruit_end_dt','cam_notice_dt','cam_review_start_dt','cam_review_end_dt','cam_best_select_dt');
	
	// 회원 메타 확장값(들) 추출
	$sql = " SELECT GROUP_CONCAT(CONCAT(mta_key, '=', COALESCE(mta_value, 'NULL'))) AS mbr_metas 
			FROM {$g5['meta_table']} WHERE mta_db_table = 'member' AND mta_db_id = '".$cam['mb_id_company']."' ";
	$mta1 = sql_fetch($sql,1);
	$pieces = explode(',', $mta1['mbr_metas']);
	foreach ($pieces as $piece) {
		list($key, $value) = explode('=', $piece);
		$mb[$key] = $value;
	}
	unset($pieces, $piece);

	// 영업자 메타 확장값(들) 추출
	$sql = " SELECT GROUP_CONCAT(CONCAT(mta_key, '=', COALESCE(mta_value, 'NULL'))) AS mbr_metas FROM {$g5['meta_table']} 
				WHERE mta_db_table = 'member' AND mta_db_id = '".$cam['mb_id_saler']."' ";
		
	$mta2 = sql_fetch($sql,1);
	$pieces = explode(',', $mta2['mbr_metas']);
	foreach ($pieces as $piece) {
		list($key, $value) = explode('=', $piece);
		$mb2[$key] = $value;
	}
	unset($pieces, $piece);

	// SNS 채널 추출 (term_relation)
	$cam_channel = sql_fetch(" SELECT GROUP_CONCAT( CAST(trm_idx AS CHAR) ORDER BY tmr_sort) AS cam_channels 
								FROM {$g5['term_relation_table']} 
								WHERE tmr_db_table = 'campaign' AND tmr_db_key = 'channel' AND tmr_db_id = '".$cam['cam_idx']."' ");
	
	// 관련 파일(post_file) 추출
	$sql = "SELECT * FROM {$g5['file_table']} 
			WHERE fle_db_table = 'campaign' AND fle_db_id = '".$cam['cam_idx']."' ORDER BY fle_sort, fle_reg_dt DESC ";
	$rs = sql_query($sql,1);
	
    $sql = (" SELECT * FROM {$g5['board_file_table']} WHERE bo_table='{$bo_table}' AND wr_id='{$cam['cam_idx']}' AND bf_no='1' ");
    
	//파일 배열로 만들기.
	for($i=0;$row=sql_fetch_array($rs);$i++) {
		$cam[$row['fle_type']][$row['fle_sort']]['file'] = (is_file(G5_PATH.$row['fle_path'].'/'.$row['fle_name'])) ? 
							'&nbsp;&nbsp;<a href="'.G5_USER_URL.'/lib/download.php?file_fullpath='.urlencode(G5_PATH.$row['fle_path'].'/'.$row['fle_name']).'&file_name_orig='.$row['fle_name_orig'].'">파일다운로드</a>'
							.'&nbsp;&nbsp;<input type="checkbox" name="'.$row['fle_type'].'_del['.$row['fle_sort'].']" value="1"> <b style="color:red">삭제</b> &nbsp;/&nbsp; '.$row['fle_name'].''
							:'';
		$cam[$row['fle_type']][$row['fle_sort']]['fle_name'] = (is_file(G5_PATH.$row['fle_path'].'/'.$row['fle_name'])) ? $row['fle_name'] : '' ;
		$cam[$row['fle_type']][$row['fle_sort']]['fle_path'] = (is_file(G5_PATH.$row['fle_path'].'/'.$row['fle_name'])) ? $row['fle_path'] : '' ;
		$cam[$row['fle_type']][$row['fle_sort']]['exists'] = (is_file(G5_PATH.$row['fle_path'].'/'.$row['fle_name'])) ? 1 : 0 ;
	}
	
	// 이미지 파일
	$fle_type1 = "campaign_img";
	for ($i=0; $i<6; $i++) {
		if ($cam[$fle_type1][$i]['exists']) {
			$cam[$fle_type1][$i]['img'] = '<div style="margin-top:10px;"><img src="'.G5_URL.$cam[$fle_type1][$i]['fle_path'].'/'.$cam[$fle_type1][$i]['fle_name'].'" style="width:200px;"></div>';
		}
	}
}
else
    alert('제대로 된 값이 넘어오지 않았습니다.');

// 상품명,상품회차 추출하기. kjw
if (isset($pdo_idx)) {
	$sql = "SELECT *
			,( SELECT count(cam_idx) FROM {$g5['campaign_table']} WHERE pdo_idx = pdo.pdo_idx AND cam_status IN ('pending','ing','ok') ) AS cam_count
			,( SELECT mb_name FROM {$g5['member_table']} WHERE mb_id = pdo.mb_id_saler ) AS mb_name
			FROM {$g5['product_order_table']} AS pdo WHERE pdo_idx = '{$pdo_idx}' ";
	$proo = sql_fetch($sql,1);	
}

// 라디오&체크박스 선택상태 자동 설정 (필드명 배열 선언!)
$check_array=array('cam_type','cam_reviewer_yn','cam_best_use_yn','cam_point_type');
for ($i=0;$i<sizeof($check_array);$i++) {
	${$check_array[$i].'_'.$cam[$check_array[$i]]} = ' checked';
}

// 넘겨줄 변수가 많아서 qstr 별도 설정
$qstr = $qstr."&amp;sfl_date=$sfl_date&amp;st_date=$st_date&amp;en_date=$en_date"
	."&amp;ser_trm_cat1=$ser_trm_cat1&amp;ser_trm_cat2=$ser_trm_cat2&amp;ser_trm_cat3=$ser_trm_cat3"
	."&amp;ser_trm_salesarea=$ser_trm_salesarea"
	."&amp;sns_trm_idxs=$sns_trm_idxs";

$g5['title'] = '캠페인 '.$html_title;
include_once (G5_ADMIN_PATH.'/admin.head.php');

add_javascript(G5_POSTCODE_JS, 0);
?>

<form name="form01" id="form01" action="./campaign_form_update.php" onsubmit="return form01_submit(this);" method="post" enctype="multipart/form-data">
<input type="hidden" name="w" value="<?=$w?>">
<input type="hidden" name="sfl" value="<?=$sfl?>">
<input type="hidden" name="stx" value="<?=$stx?>">
<input type="hidden" name="sst" value="<?=$sst?>">
<input type="hidden" name="sod" value="<?=$sod?>">
<input type="hidden" name="page" value="<?=$page?>">
<input type="hidden" name="token" value="">
<input type="hidden" name="cam_idx" value="<?=$cam_idx?>">
<input type="hidden" name="sfl_date" value="<?=$sfl_date?>">
<input type="hidden" name="st_date" value="<?=$st_date?>">
<input type="hidden" name="en_date" value="<?=$en_date?>">
<input type="hidden" name="sfl_date2" value="<?=$sfl_date2?>">
<input type="hidden" name="st_date2" value="<?=$st_date2?>">
<input type="hidden" name="en_date2" value="<?=$en_date2?>">
<input type="hidden" name="ser_trm_idx_cat1" value="<?=$ser_trm_idx_cat1?>">
<input type="hidden" name="ser_trm_idx_cat2" value="<?=$ser_trm_idx_cat2?>">
<input type="hidden" name="ser_trm_idx_cat3" value="<?=$ser_trm_idx_cat3?>">
<input type="hidden" name="ser_trm_idx_salesarea" value="<?=$ser_trm_idx_salesarea?>">
<input type="hidden" name="sns_trm_idxs" value="<?=$sns_trm_idxs?>">

<div class="local_desc01 local_desc">
	<p>신청된 상품에 대해서만 캠페인 등록이 가능합니다. 캠페인 등록을 위해서는 상품을 먼저 신청해 주세요. <a href="./product_order_form.php">[상품신청바로가기]</a>
	<br>한번 등록 후에는 변경 불가능 항목들: 고객아이디/이름, 신청상품, 업업자아이디/이름, 업체명</p>
</div>

<div class="tbl_frm01 tbl_wrap">
	<table>
	<caption><?=$g5['title']; ?></caption>
	<colgroup>
		<col class="grid_4" style="width:12%;">
		<col style="width:38%;">
		<col class="grid_4" style="width:12%;">
		<col>
	</colgroup>
	<tbody>
	
	<?php if ($w == '') { // 신규일때만 자동등록 가능. ?>
	<tr>
		<th scope="row"><label for="auto_cam_make">자동캠페인 등록<strong class="sound_only">필수</strong><span class="agree_ck"> 필수 </span></label></th>
		<td>
			<?=help("구매한 상품회차 및 남은회차 만큼 자동등록 됩니다."); ?>			
			<input type="radio" name="cam_auto_make_yn" value="1" id="cam_auto_make_yn1"  class="cam_auto_make_yn" <?=($cam['cam_auto_make_yn']=='1')?'checked':''; ?>  > &nbsp<label for="cam_auto_make_yn1"> 사용 &nbsp </label>
			<input type="radio" name="cam_auto_make_yn" value="0" id="cam_auto_make_yn0"  class="cam_auto_make_yn" <?=($cam['cam_auto_make_yn']=='0')?'checked':''; ?>checked="checked"> &nbsp<label for="cam_auto_make_yn0"> 사용안함 </label>
			<input type="hidden" name="pdo_prd_times" value="<?= $proo['pdo_prd_times'] ?>" class="pdo_prd_times"> <!--상품회차-->
		</td>
	</tr>
	<?php } ?>
	<tr> 
		<th scope="row">업체명</th>
		<td colspan="3">
			<input readonly type="hidden" placeholder="업체고유번호" name="com_idx" value="<?=$cam['com_idx'] ?>" id="com_idx" required class="frm_input required" style="<?=$style_com_idx?>" size="15" maxlength="30">
			<input readonly type="text" placeholder="업체명" name="com_name" value="<?=$com['com_name'] ?>" id="com_name" <?=$required_com_name?> class="frm_input <?=$required_com_name_class?>" style="<?=$style_com_name?>;width:191px;" minlength="1" maxlength="30">
			<?php if ($w == '' || !auth_check($auth[$sub_menu],'w',1) ) { ?><a class="global_btn" id="btn_com_idx" style="<?php if ($is_admin!='super') echo 'display:none;'; ?>">업체검색</a><?php } ?>
			<span class="span_com_president" style="margin-left:15px;<?=$com['com_president_display']?>"><?=$com['com_president']?></span>
			<span class="span_com_manager" style="margin-left:5px;<?=$com['com_manager_display']?>;">(<?=$com['com_manager']?>)</span>
		</td>
    </tr>
	<tr> 
		<th scope="row">이름/고객아이디</th>
		<td>
            <input readonly type="text" placeholder="회원명" name="mb_name_company" value="<?=$mb['mb_name'] ?>" id="mb_name_company" <?=$required_mb_name_company?> class="frm_input <?=$required_mb_name_company_class?>" style="<?=$style_mb_name_company?>" size="15" minlength="2">
			<input readonly type="text" placeholder="회원ID" name="mb_id_company" value="<?=$cam['mb_id_company'] ?>" id="mb_id_company" required class="frm_input required" style="<?=$style_mb_id?>" size="15" minlength="3" maxlength="30">
			<?php/* if ($w == '' || !auth_check($auth[$sub_menu], 'w',1) ) { ?><a class="global_btn" id="btn_mb_id_company">업체(회원)검색</a><?php }*/ ?>
		</td>
		<th scope="row">업체 연락처</th>
		<td>
			<input type="hidden" name="cam_mb_tel" value="<?=$cam['cam_mb_tel'] ?>" id="cam_mb_tel" class="frm_input" style="width:140px">
			<input type="text" name="com_tel" value="<?=$mb['mb_hp'] ?>" id="com_tel" class="frm_input" style="width:140px">
		</td>
	</tr>
	<tr>
		<th scope="row">신청자명</th>
		<td><input type="text" name="cam_mb_name" value="<?=$cam['cam_mb_name'] ?>" id="cam_mb_name" class="frm_input" style="width:92px"></td>
		<th scope="row">이메일</th>
		<td><input type="text" name="cam_mb_email" value="<?=$cam['cam_mb_email'] ?>" id="cam_mb_email" class="frm_input" style="width:140px"></td>
	</tr>
	<tr> 
		<th scope="row">신청상품</th>
		<td>
			<?=help("고객이 선택된 상태에서 신청 상품을 검색 & 등록할 수 있습니다."); ?>
			<input readonly type="hidden" name="pdo_idx" value="<?=$cam['pdo_idx'] ?>" required class="frm_input required" >
			<input readonly type="text" placeholder="신청상품" name="prd_name" value="<?=$prd['prd_name'] ?>" id="prd_name" <?=$required_prd_name?> class="frm_input <?=$required_prd_name_class?>" style="<?=$style_prd_name?>" size="15" minlength="3" maxlength="30">
			<?php if ($w == '' || $member['mb_level'] >= 9 ) { ?><a class="global_btn" id="btn_pdo_idx" style="display:none;">신청상품검색</a><?php } ?>
			<span class="span_pdo_price" style="margin-left:15px;<?=$pdo['pdo_price_display']?>;"><?=number_format($pdo['pdo_price'])?></span>
			<span class="span_pdo_pay_status_text" style="margin-left:5px;<?=$pdo['pdo_pay_status_text_display']?>;">(<?=$g5['set_pdo_pay_status_value'][$pdo['pdo_pay_status']]?>)</span>
			<?php if ($w == 'u') { ?>&nbsp;&nbsp;  [<a href="./product_order_form.php?w=u&pdo_idx=<?=$cam['pdo_idx']?>" target="_blank">상세보기</a>]<?php } ?>
		</td>
		<th scope="row">캠페인진행차수</th>
		<td>		
			<?=help("기본으로 자동 증가됨, 안맞을 경우에만 수정해주세요."); ?>
			<input type="text" name="cam_prd_time" value="<?=$cam['cam_prd_time'] ?>" style="width:20px;"> -
			<input type="text" name="cam_prd_retime" value="<?=$cam['cam_prd_retime'] ?>" style="width:20px;">
			&nbsp;회차/총<span class="span_pdo_prd_times"><?=$pdo['pdo_prd_times']?></span>회중
		</td>
	</tr>
	<tr> 
		<th scope="row">담당자아이디/이름</th>
		<td colspan="3">
			<input type="hidden" name="mb_email_saler" value="<?= $mb2['mb_email'] ?>" id="mb_email_saler"  >
			<input type="text" name="mb_hp_saler" value="<?= $mb2['mb_hp'] ?>" id="mb_hp_saler" readonly >
			<input readonly type="text" placeholder="담당자ID" name="mb_id_saler" value="<?=$cam['mb_id_saler'] ?>" id="mb_id_saler" required class="frm_input required" style="<?=$style_mb_id_saler?>" size="15" minlength="3" maxlength="30">
			<input readonly type="text" placeholder="담당자명" name="mb_name_saler" value="<?=$mb2['mb_name'] ?>" id="mb_name_saler" <?=$required_mb_name_saler?> class="frm_input <?=$required_mb_name_saler_class?>" style="<?=$style_mb_name_saler?>" size="15" minlength="3" maxlength="30">
			<?php if ($w == '' || $member['mb_level'] >= 9 ) { ?><a class="global_btn" id="btn_mb_id_saler" style="<?php if ($is_admin!='super') echo 'display:none;'; ?>">담당자검색</a><?php } ?>
		</td>
	</tr>
	
	<tr> 
		<th scope="row">카테고리</th>
		<td colspan="3">
			<?=help("대표 카테고리를 선택하세요. 2차, 3차 카테고리를 추가로 설정해 주셔도 됩니다. 2,3차가 필요 없는 경우는 그냥 두세요."); ?>
			<select name="trm_idx_cat1" id="trm_idx_cat1"><?=$category_form_options?></select>
			<script>$('select[name="trm_idx_cat1"]').val('<?=$cam['trm_idx_cat1']?>');</script>
		</td>
	</tr>
	<tr>
		<th scope="row">카테고리2</th>
		<td>
			<select name="trm_idx_cat2" id="trm_idx_cat2"><option value="">2차 카테고리 선택</option><?=$category_form_options?></select>
			<script>$('select[name="trm_idx_cat2"]').val('<?=$cam['trm_idx_cat2']?>');</script>
		</td>
		<th scope="row">카테고리3</th>
		<td>
			<select name="trm_idx_cat3" id="trm_idx_cat3"><option value="">3차 카테고리 선택</option><?=$category_form_options?></select>
			<script>$('select[name="trm_idx_cat3"]').val('<?=$cam['trm_idx_cat3']?>');</script>
		</td>
	</tr>
    <tr> 
    <th scope="row"><label for="cam_option">옵션</label></th>
		<td colspan="3">
            <select name="cam_option" id="cam_option"><?=$g5['set_cam_status_options2']?></select>
			<script>$('select[name="cam_option"]').val('<?=$cam['cam_option']?>');</script>
		</td>
	</tr>
    
	<tr>
		<th scope="row">상권</th>
		<td colspan="3">
			<select name="trm_idx_salesarea" id="trm_idx_salesarea"><?=$salesarea_form_options?></select>
			<script>$('select[name="trm_idx_salesarea"]').val('<?=$cam['trm_idx_salesarea']?>');</script>
			<span class="addr_list"></span>
		</td>
	</tr>
	<tr>
		<th scope="row">캠페인명</th>
		<td colspan="3"><input type="text" name="cam_name" value="<?=$cam['cam_name'] ?>" id="cam_name"  class="frm_input " style="width:60%"></td>
    </tr>
    <tr>
		<th scope="row">네이버 플레이스 URL</th>
		<td colspan="3"><input type="text" name="com_naver_place_url" value="<?=$cam['com_naver_place_url'] ?>" id="com_naver_place_url" class="frm_input" style="width:60%"></td>
    </tr>
                
	<tr> 
		<th scope="row">간단설명</th>
		<td colspan="3"><input type="text" name="cam_brief" value="<?=$cam['cam_brief'] ?>" id="cam_brief" class="frm_input" style="width:60%"></td>
	</tr>
	<tr> 
		<th scope="row">SNS 선택</th>
		<td colspan="3">
			<?php
			echo $g5['sns_channel_checkboxs'];
			if ( $cam_channel['cam_channels']) {
				$row['cam_channels_array'] = explode(",",$cam_channel['cam_channels']);
				sort($row['cam_channels_array']);
				foreach ($row['cam_channels_array'] as $key) {
			?>
			<script>$('input[name^=sns_channel][value="<?=$key?>"]').attr('checked','checked');</script>
			<?php
				}
            }
            ?>
		</td>
	</tr>
	<tr>
		<th scope="row">리뷰어모집형태</th>
		<td>
			<input type="radio" name="cam_reviewer_yn" value="0" id="cam_reviewer_yn_0" <?=$cam_reviewer_yn_0?>>
			<label for="cam_reviewer_yn_0">비모집형</label> &nbsp;&nbsp;
			<input type="radio" name="cam_reviewer_yn" value="1" id="cam_reviewer_yn_1" <?=$cam_reviewer_yn_1?>>
			<label for="cam_reviewer_yn_1">모집형</label>
		</td>
		<th scope="row">모집인원</th>
		<td><input type="text" name="cam_recruit_count" value="<?=$cam['cam_recruit_count'] ?>" id="cam_recruit_count" class="frm_input" style="width:20px"> 명</td>
	</tr>
	<tr> 
		<th scope="row">정보등록자</th>
		<td>
			<input readonly type="text" placeholder="등록자ID" name="mb_id_info" value="<?=$cam['mb_id_info'] ?>" id="mb_id_info" required class="frm_input required" style="<?=$style_mb_id_info?>" size="15" minlength="3" maxlength="30">
			<input readonly type="text" placeholder="등록자명" name="mb_name_info" value="<?=$mb3['mb_name'] ?>" id="mb_name_info" <?=$required_mb_name_info?> class="frm_input <?=$required_mb_name_info_class?>" style="<?=$style_mb_name_info?>" size="15" minlength="2">
			<?php if ($w == '' || $member['mb_level'] >= 9 ) { ?><a class="global_btn" id="btn_mb_id_info">회원검색</a><?php } ?>
        </td>
		<th scope="row">정보등록일</th>
		<td>
			<input type="text" name="cam_info_reg_dt" value="<?=$cam['cam_info_reg_dt'] ?>" id="cam_info_reg_dt" class="frm_input" style="width:130px">
			<input id="today3" type="checkbox" value="<?=date("Y-m-d H:i:s"); ?>" onclick="javascript:$(this).prev().val( $(this).val() );">
			<label for="today3">오늘로 지정</label>
		</td>
	</tr>
	<tr>
		<th scope="row" >리뷰어 신청 시작일</th>
		<td><input type="text" autocomplete="off" name="cam_recruit_start_dt" value="<?=substr($cam['cam_recruit_start_dt'],0,10) ?>" id="cam_recruit_start_dt" class="frm_input" style="width:130px"></td>
		<th scope="row">리뷰어 신청 종료일</th>
		<td><input type="text" name="cam_recruit_end_dt" value="<?=substr($cam['cam_recruit_end_dt'],0,10)?>" id="cam_recruit_end_dt" class="frm_input" style="width:130px"></td>
	</tr>
    
	<tr class="norun">
		<th scope="row">리뷰어 발표일</th>
		<td><input type="text" name="cam_notice_dt" value="<?=substr($cam['cam_notice_dt'],0,10)?>" id="cam_notice_dt" class="frm_input" style="width:130px"></td>
		<th scope="row">리뷰어 선정상태</th>
		<td>
			<select name="cam_notice_status" id="cam_notice_status"><?=$g5['set_cam_notice_status_options']?></select>
			<script>$('select[name="cam_notice_status"]').val('<?=$cam['cam_notice_status']?>');</script>
		</td>
	</tr>
    
	<tr class="norun">
		<th scope="row">리뷰 등록 시작일</th>
		<td><input type="text" name="cam_review_start_dt" value="<?=substr($cam['cam_review_start_dt'],0,10)?>" id="cam_review_start_dt" class="frm_input" style="width:130px"></td>
		<th scope="row">리뷰 등록 종료일</th>
		<td><input type="text" name="cam_review_end_dt" value="<?=substr($cam['cam_review_end_dt'],0,10)?>" id="cam_review_end_dt" class="frm_input" style="width:130px"></td>
	</tr>
	<tr class="norun" >
		<th scope="row">베스트선정일</th>
		<td><input type="text" name="cam_best_select_dt" value="<?=substr($cam['cam_best_select_dt'],0,10)?>" id="cam_best_select_dt" class="frm_input" style="width:130px"></td>
		<th scope="row">베스트선정사용여부</th>
		<td>
			<input type="radio" name="cam_best_use_yn" value="1" id="cam_best_use_yn_1" <?=$cam_best_use_yn_1?>>
			<label for="cam_best_use_yn_1">사용함</label> &nbsp;&nbsp;
			<input type="radio" name="cam_best_use_yn" value="0" id="cam_best_use_yn_0" <?=$cam_best_use_yn_0?>>
			<label for="cam_best_use_yn_0">사용안함</label>			
		</td>		
	</tr>	
	<tr>
		<th scope="row">포인트지급방법</th>
		<td colspan="3">
			<input type="radio" name="cam_point_type" value="group" id="cam_point_type_group" <?=$cam_point_type_group?>>
			<label for="cam_point_type_group">일괄지정</label> &nbsp;&nbsp;
			<input type="radio" name="cam_point_type" value="each" id="cam_point_type_each" <?=$cam_point_type_each?>>
			<label for="cam_point_type_each">개별지정</label>
		</td>
	</tr>
	<tr>
		<th scope="row">리뷰어포인트</th>
		<td><input type="text" name="cam_reviewer_point" value="<?=($cam['cam_reviewer_point']=='') ? $setting['set_cam_reviewer_point'] : $cam['cam_reviewer_point'];?>" id="cam_reviewer_point" class="frm_input" style="width:50px"> Point</td>
		<th scope="row">베스트당첨포인트</th>
		<td><input type="text" name="cam_best_point" value="<?=($cam['cam_best_point']=='') ? $setting['set_cam_best_point'] : $cam['cam_best_point'];?>" id="cam_best_point" class="frm_input" style="width:50px"> Point</td>
	</tr>
	<tr>
		<th scope="row">이미지</th>
		<td colspan="3">
			<?=help("사진을 반드시 등록해 주세요. (등록 후에도 언제든 수정 가능!) ")?>
			<?php for ($i=0; $i<4; $i++) { ?>
			<input type="file" name="campaign_img_file[<?=$i?>]" class="frm_input">
			<?=$cam['campaign_img'][$i]['file'].$cam['campaign_img'][$i]['img']?><br>
			<?php } ?>
		</td>
    </tr>
	<tr class="norun">
		<th scope="row">복사테그</th>
		<td colspan="3"><input type="text" id="cam_tags" name="cam_tags" value="<?=$cam['cam_tags']?>" style="width:99%;"/></td>
	</tr>
	<tr>
		<th scope="row">내용</th>
		<td colspan="3">
			<?=help('- 캠페인 상세 보기 페이지 내용 부분입니다. 모바일웹에서 보여지므로 이미지는 100% 형태로 나타납니다.')?>
			<?php if ($w == 'u') echo help('- 캠페인 타입 변경후 저장시 기존 내용이 삭제 됩니다.'); ?>
			<div style="margin: 5px 0 16px 0;font-size: 18px;">
				<input type="radio" id="cam_type1" name = "cam_type" value="visite" <?=($cam['cam_type']=='visite')?'checked':''; ?>/>
				<label for="cam_type1"> 방문형 &nbsp&nbsp&nbsp </label>
				<input type="radio" id="cam_type2" name = "cam_type" value="delivery" <?=($cam['cam_type']=='delivery')?'checked':''; ?>/>
				<label for="cam_type2"> 배송형 &nbsp&nbsp&nbsp </label>
				<input type="radio" id="cam_type3" name = "cam_type" value="PressCorps" <?=($cam['cam_type']=='PressCorps')?'checked':''; ?>/>
				<label for="cam_type3"> 기자단 &nbsp&nbsp&nbsp </label>
                <input type="radio" id="cam_type4" name = "cam_type" value="receipt" <?=($cam['cam_type']=='receipt')?'checked':''; ?>/>
				<label for="cam_type4"> 영수증 리뷰 &nbsp&nbsp&nbsp </label>
                <input type="radio" id="cam_type5" name = "cam_type" value="reservation" <?=($cam['cam_type']=='reservation')?'checked':''; ?>/>
				<label for="cam_type5"> 예약자 리뷰 &nbsp&nbsp&nbsp </label>
			</div>
			<?php
			$cam_cont0 = 'set_cam_content_cam_type1';
			$cam_cont1 = 'set_cam_content_cam_type2';
			$cam_cont2 = 'set_cam_content_PressCorps';
			$cam_cont3 = 'set_cam_content_cam_receipt';
			$cam_cont4 = 'set_cam_content_cam_reservation';
			if ($w == 'u') {
			  switch ($cam['cam_type']) {
				case 'visite': $cam_cont0 = 'cam_content'; break;
				case 'delivery': $cam_cont1 = 'cam_content'; break;
				case 'PressCorps': $cam_cont2 = 'cam_content'; break;
				case 'receipt': $cam_cont3 = 'cam_content'; break;
				case 'reservation': $cam_cont4 = 'cam_content'; break;
			  }
			}
			?>
			<div class='cam_content_type1'>
			  <div class="form_help">[ 방문형 ]</div>
			  <?=editor_html("cam_content", get_text($setting[$cam_cont0], 0))?>
			</div>
			<div class='cam_content_type2'>
			  <div class="form_help">[ 배송형 ]</div>
			  <?=editor_html("cam_content1", get_text($setting[$cam_cont1], 0))?>
			</div>
			<div class='cam_content_PressCorps'>
			  <div class="form_help">[ 기자단 ]</div>
			  <?=editor_html("cam_content2", get_text($setting[$cam_cont2], 0))?>
			</div>
			<div class='cam_content_receipt'>
			  <div class="form_help">[ 영수증 리뷰 ]</div>
			  <?=editor_html("cam_content3", get_text($setting[$cam_cont3], 0))?>
			</div>
			<div class='cam_content_reservation'>
			  <div class="form_help">[ 예약자 리뷰 ]</div>
			  <?=editor_html("cam_content4", get_text($setting[$cam_cont4], 0))?>
			</div>
		</td>
	</tr>
	
	<tr>
		<th scope="row">필수 키워드</th>
		<td colspan="3">
			<input type="text" id="keyword" onKeypress="return insertKeyword(event)">
			<button type="button" id="add_keyword" class="btn_submit" onClick="return insertKeyword()">키워드 추가</button>
			<ul id="keyword_tags">
				<?php // 키워드 가져오기
				if ($w == 'u') {
					$sql = "SELECT DISTINCT kw.kyw_name FROM {$g5['keyword_campaign_table']} AS kc 
							RIGHT JOIN {$g5['keyword_table']} AS kw ON kw.kyw_idx = kc.kyw_idx 
							WHERE kc.cam_idx = {$cam_idx}";
					$keyword_result = sql_query($sql);
					while ($kyw = sql_fetch_array($keyword_result)) {
				?>
				<li data-keyword="<?=$kyw['kyw_name']?>">
					<input type="hidden" name="keyword[]" value="<?=$kyw['kyw_name']?>">
					#&nbsp;<?=$kyw['kyw_name']?><a href="javascript:void(0)" onClick="removeKeywordTag('<?=$kyw['kyw_name']?>')">&times;</a>
				</li>
				<?php
					}
				}
				?>
			</ul>
		</td>
	</tr>
	
	<tr>
		<th scope="row">반려사유</th>
		<td colspan="3"><textarea name="cam_notice" id="cam_notice"><?=$cam['cam_notice']?></textarea></td>
	</tr>
	
	<tr>
		<th scope="row">메모</th>
		<td colspan="3"><textarea name="cam_memo" id="cam_memo"><?=$cam['cam_memo']?></textarea></td>
	</tr>
	
	<?php if ($w == 'u') { ?>
	<tr>
		<th scope="row">등록일</th>
		<td><span class="span_cam_reg_dt"><?=$cam['cam_reg_dt'] ?></span></td>
		<th scope="row">취소일</th>
		<td><?=($pdo['pdo_cancel_dt'] != '0000-00-00 00:00:00')? '<span class="span_pdo_cancel_dt">'.$pdo['pdo_cancel_dt'].'</span>' : '-'?></td>
	</tr>
	<?php } ?>
	
	<tr>
		<th scope="row"><label for="cam_status">상태</label></th>
		<td colspan="3">
			<select name="cam_status" id="cam_status"><?=$g5['set_cam_status_options']?></select>
			<script>$('select[name="cam_status"]').val('<?=$cam['cam_status']?>');</script>&nbsp
            <input type="checkbox" name="chklms" value="1" id="chklms" >&nbsp <label for="chklms" style="color:red;"> 체크 해지하면 문자 미발송 됩니다. </label> &nbsp	
            
		</td>
    </tr>
    <tr>
		<th scope="row">영수증 압축파일</th>
		<td colspan="3">
			<?=help('- 압축파일은 ZIP 만 업로드하세요. ')?><b>다운 파일 :</b> 
			<input type="file" accept=".zip" name="campaign_img_file[4]" class="frm_input"> <?= $cam['campaign_img'][4]['file']?>			
		</td>
    </tr>
	<tr>
		<th scope="row" rowspan='2'><label for="cam_status">사내 캠페인</label></th>
		<td><input type="checkbox" name="cam_nct" value="1" id="cam_nct" <?= ($cam['cam_nct']=='1')? 'checked' : ''; ?> >&nbsp <label for="cam_nct" style="color:#147CB8;font-size:13px;font-weight:1000"> 직원용 캠페인 </label></td>
		<th scope="row"><label for="cam_status">사내 캠페인 선착순</label></th>
		<td><input type="text" name="cam_nct_cnt" id='cam_nct_cnt' value="<?=$cam['cam_nct_cnt']?>" > 명</td>		
		<?/*<tr>
			<td colspan="3">
				<?= help('- 압축파일은 ZIP 만 업로드하세요. '); ?>
				<b>다운 파일 :</b> 
				<input type="file" name="campaign_img_file[5]" class="frm_input"> <?= $cam['campaign_img'][5]['file']?>			
			</td>
		</tr>*/?>
	</tr>
	
	<?php if ($w == 'u') { ?>
	<tr>
		<th scope="row"><label for="cam_sort">정렬</label></th>
		<td colspan="3">
			<?=help('- 기본값은 9999 입니다.')?>
			<input type="text" name="cam_sort" id='cam_sort' value="<?=$cam['cam_sort']?>" >
		</td>
	</tr>
	<?php } ?>
	
	<!--<tr>
		<th scope="row">
			<label for="cp_head_ct">인스타그램#태그</label>
		</th>
		<td colspan="3" class="cp_i_tag">
			<?php 			
			$sql3 = " SELECT trm_idx FROM {$g5['term_relation_table']} WHERE tmr_db_key = 'campaign_tag' AND tmr_db_id = '{$cam_idx}' ";
			$trm1 = sql_query($sql3);
			for ($j=0; $row=sql_fetch_array($trm1); $j++) {
				$trm2 = sql_fetch(" SELECT trm_idx,trm_name FROM {$g5['term_table']} WHERE trm_taxonomy = 'campaign_tag' AND trm_idx = '{$row['trm_idx']}' ");
				$trm['trm_name'] .= '#'.$trm2['trm_name']; // 변수 값(문자열) 연결 
			}
			?>
			<input type="text" id="tag_text" name="tag_text" value="<?=$trm['trm_name'] ?>" placeholder="( #kafain_태그명 )으로 한번만 입력하세요." style="width:90%" class="frm_input">				          											
		</td>
	</tr>
	-->
	</tbody>
	</table>
</div>

<div class="btn_confirm01 btn_confirm">
    <input type="submit" value="확인" class="btn_submit" id="btn_submit" accesskey='s'>
    <a href="./campaign_list.php?<?=$qstr?>" id="btn_cancel">목록</a>
	<?php if ($w == 'u') { ?><a href="<?=G5_URL?>/_u/m/campaign_view.php?device=mobile&cam_idx=<?=$cam_idx?>" target="_blank" id="btn_cancel" style="background: #a03400;">미리보기</a><?php } ?>	
	<?php // 캠페인 복사
	
	// 상품 회차중 마지막 등록된 캠페인 회차 추출하기.
	$cam_last = sql_fetch(" SELECT * FROM {$g5['campaign_table']} WHERE pdo_idx = '".$pdo_idx."' ORDER BY cam_idx DESC ");
	
	// tail안에 모달 사용변수 선언.
	$pro_mb_id = $mb_id;
	
	// *** 상품신청 (구매) 상품이 있는지 체크 ***
	$pdo = sql_query(" SELECT pdo_idx, pdo_recruit_count
						,( SELECT prd_times FROM {$g5['product_table']} WHERE prd_idx = pdo.prd_idx ) AS prd_times
						,( SELECT count(cam_idx) FROM {$g5['campaign_table']} WHERE pdo_idx = pdo.pdo_idx AND cam_status IN ('pending','ing','ok') ) AS cam_count
					FROM {$g5['product_order_table']} AS pdo 
					WHERE pdo_pay_status = 'payall' AND mb_id = '{$mb_id}' ");
	for ($i=0; $row2=sql_fetch_array($pdo); $i++) {
		if ($row2['prd_times'] > $row2['cam_count']) $a++;
	}

	// 일괄수정 버튼 마지막상품은 안보임.
	if ($w == 'u' && $cam_last['cam_prd_time'] != 1 && $cam['cam_prd_time'] < $proo['pdo_prd_times'] ) {
		echo '<input type="button" value="일괄수정" id="btn_submit2" class="btn_submit2" accesskey="s">';
		echo '<input type="hidden" name="cam_auto" value="0" id="cam_auto" class="cam_auto">';			
		echo "<input type='hidden' name='pdo_prd_times' value='".$proo['pdo_prd_times']."'> ";
	}
	
	if ( $cam_last['cam_prd_time'] != 0 && $a > 0 ) { // 캠페인 진행 회차만들기.
		echo ' <span class="cam_copy">복사</span>';
		echo ' <input type="hidden" class="cam_idx_copy" value="'.$cam_idx.'"> ';
		echo ' <input type="hidden" class="pro_mb_id" value="'.$pro_mb_id.'"> ';
	}
		
	// 다시회차 만들떄 문제 지금 프로그램은 마지막에 만든 다시회차상품을 다시회차해야 이어서 카운트가 올라간다.~~~~!!!!!!!!!!!!
	if ($cam['cam_prd_retime'] == '0' ) {
		// 다시회차
		echo ' <span class="cam_copy cam_retime">다시회차</span>';
		echo ' <input type="hidden" class="cam_idx_copy" value="'.$cam_idx.'"> ';
		echo ' <input type="hidden" class="cam_recruit_count" value="'.$cam['cam_recruit_count'].'"> ';
		echo ' <input type="hidden" class="pdo_prd_times" value="'.$proo['pdo_prd_times'].'"> ';
	}
	?>
</div>
</form>


<script>
$(function() {

	// 대표이미지 plus 함수.
	$(document).on('click','.file_plus',function(e) {
		//수정확인.
		var upd = $("input[name='w']").val();
		//cnt
		var n = $(".value_cnt").val();
		//plus 이미지 setting개수만큼 보여주기.
		if ( n == '<?=$setting['set_cam_title_img'] -1;?>') {
			$(this).hide();
		}
		
		var fileRow = '<div class="file_make_img_wrap"><input type="file" name="campaign_img_file['+n+']" class="frm_input file_make_img"> <a class="sns_btn_del"><img src="'+g5_url+'/theme/kafain_10/mobile/img/btn_minus.png" style="width:27px;margin-left:2px;" /></a></div>';
		
		//입력부분.
		if ( upd == 'u') {
			$(".div_file_img").last().after(fileRow);
		} else {
			$(".file_make_img_wrap").last().after(fileRow);
		}
		
		//카운트 +하기.
		$(".value_cnt").val( parseInt(n)+1 );
	});
	
	// 대표이미지 리스트 삭제
	$(document).on('click','.sns_btn_del', function(e) {
		n = $(".value_cnt").val(); // 카운트 -하기.
		$(".value_cnt").val(parseInt(n)-1); // 삭제하기.
		$(this).parent().remove();	
		
		// plus 이미지 setting개수보다 작으면 안보여주기.
		if ( n <= '<?=$setting['set_cam_title_img'];?>')
			$(".file_plus").show();
	});
	
	
	// **** 달력 ****
	// 2016-6-7문자로 입력된 날짜를 월,일을 2자리 만드는 함수
	function stringToYYYYMMDD(date) {
		var YMD = date.split('-');
	    function pad(num) {
			return num.length < 2 ? '0' + num : num;
	    }
		return YMD[0] + '-' + pad(YMD[1]) + '-' + pad(YMD[2]);
	}
			
	// 특정날짜들 배열
	var disabledDays = [<?=$setting['set_campaign_holidays']?>];
	var datepickerOption = {
		changeMonth: true,
		changeYear: true,
		dateFormat: "yy-mm-dd",
		showButtonPanel: true,
		yearRange: "c-99:c+99",
		beforeShowDay: function(date) {
			// 주말(토, 일요일) 선택 막기
			var day = date.getDay();
			
			// 특정일 선택막기
			var m = date.getMonth(), d = date.getDate(), y = date.getFullYear();
			for (i = 0; i < disabledDays.length; i++) {
				if ($.inArray(y + '-' +(m+1) + '-' + d,disabledDays) != -1) {
					return [false];
				}
			}
			
			// 주말 포함하여 계산
			if (<?= $setting['set_campaign_holiday_include_yn']?> == 0) {
				if (<?=$setting['set_weekend_holidays_yn']?> == 0) {
					return [true],[(day != 0)]; //일 주말 설정
				} else {
					return [true],[(day != 0 && day != 6)]; //토 / 일 주말 설정 
				}
			} else { // 주말 건너뛰고 계산
				return [true];
			}
		}
	}

	if ('<?=$w?>' == '') {
		
		// 캠페인 시간 설정 에서 리뷰어 신청 이후 부분들은 전부 disabled
		$('#cam_recruit_end_dt').css("background","#EAEAEA").attr('disabled',true);
		$('#cam_notice_dt').css("background","#EAEAEA").attr('disabled',true);
		$('#cam_review_start_dt').css("background","#EAEAEA").attr('disabled',true);
		$('#cam_review_end_dt').css("background","#EAEAEA").attr('disabled',true);
		$('#cam_best_select_dt').css("background","#EAEAEA").attr('disabled',true);
				
		// 리뷰어 신청 시작
		$("#cam_recruit_start_dt").datepicker(datepickerOption);

		// 리뷰어 신청 입력
		$("#cam_recruit_start_dt").on('click', function() {	
			$("#cam_recruit_start_dt").change(function() {
			
				// 환경설정에서 값 가져오기
				var holiday = "<?=$setting['set_campaign_holidays']?>";
				var holidays = $.trim(holiday);//공백 정리.
				var holidays_array = holidays.split(',');//콤마 기준으로 자르기.
				
				// 활성화하기
				$('#cam_recruit_end_dt').css("background","#fff").attr('disabled',false).removeClass('hasDatepicker');
				$('#cam_notice_dt').css("background","#fff").attr('disabled',false).removeClass('hasDatepicker');
				$('#cam_review_start_dt').css("background","#fff").attr('disabled',false).removeClass('hasDatepicker');
				$('#cam_review_end_dt').css("background","#fff").attr('disabled',false).removeClass('hasDatepicker');
				$('#cam_best_select_dt').css("background","#fff").attr('disabled',false).removeClass('hasDatepicker');	
				
				// (리뷰신청 시작 날짜) 만들기
				var start_dt_val = $(this).val();
				var arr = start_dt_val.split('-');
				var m_date = new Date( arr[0],arr[1]-1,arr[2] );
				var m_date1 = new Date( arr[0],arr[1]-1,arr[2] );
				
				// 자동 계산 +D 입력.
				// ***** 리뷰어 신청 끝 자동입력 ******
				m_date.setDate(m_date.getDate() + <?=$setting['set_campaign_recruit_end_dday']?>);
				var recruit_end_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();

				// 주말 포함하여 계산 하기
				if (<?= $setting['set_campaign_holiday_include_yn']?> == 0) {
					var cnt_Day =  <?=$setting['set_campaign_recruit_end_dday']?>;
					
					//시작~끝 날짜안에 토/일 있는지 검사.
					for (var i = 1; i <= cnt_Day; i++) {
						m_date1.setDate(m_date1.getDate() + 1);
						var start_day = new Date(m_date1).getDay(); // 요일 추출
						
						// 일요일이 있으면 +1.
						if (<?=$setting['set_weekend_holidays_yn']?> == 0 && start_day == 0) {
							m_date.setDate(m_date.getDate() + 1);
							recruit_end_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
						}
						
						// 주말설정 : 토/일요일. 
						if (<?=$setting['set_weekend_holidays_yn']?> == 1 && start_day == 6) {
							m_date.setDate(m_date.getDate() + 2);
							recruit_end_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();	
						
							// 요일확인(일요일이 마지막 날인지 확인하기 위해서)
							var day_confirm = new Date(m_date).getDay();
							// 일요일이 마지막 날이면 +1 하기.
							if (day_confirm == 0) {
								m_date.setDate(m_date.getDate() + 1);
								recruit_end_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
							}
						}
					}
				}

				// 공휴일 확인 및 작업
				$.each( holidays_array, function(index,value) {
					//날짜 비교하기 위한작업
					var value1 = value.replace(/'/gi,'');
					
					// 공휴일 날짜 월,일 1자리를 2자리로 만들기.
					var value2 = stringToYYYYMMDD(value1);
					var start_dt_val2 = stringToYYYYMMDD(start_dt_val);
					var recruit_end_make2 = stringToYYYYMMDD(recruit_end_make);
					
					var strDate = new Date( value2 ); // 환경설정-공휴일
					var endDate = new Date(start_dt_val2); // 리뷰어 신청 시작일
					var endDate2 = new Date(recruit_end_make2); // 입력되는 날짜.
					
					// 시작~끝 날짜 사이에 공휴일 있으면 +1씩 하기.
					if ( strDate >= endDate) {
						if (strDate <= endDate2) {
							// 요일먼저 확인
							day_confirm = new Date(m_date).getDay();
							
							// 공휴일 있으면 +1씩 하기
							m_date.setDate(m_date.getDate() + 1);
							recruit_end_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
						
							// 주말 포함하여 계산 하기
							if (<?= $setting['set_campaign_holiday_include_yn']?> == 0) {
								// 토/일요일 포함.
								if (<?=$setting['set_weekend_holidays_yn']?> == 1 ) {
									// 토요일이 있으면 +2 하기.
									if (day_confirm == 6) {
										m_date.setDate(m_date.getDate() + 2);
										recruit_end_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
									}
								}
								// 일요일 포함.
								if (<?=$setting['set_weekend_holidays_yn']?> == 0 ) {
									// 일요일이 있으면 +1 하기.
									if (day_confirm == 0) {
										m_date.setDate(m_date.getDate() + 1);
										recruit_end_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
									}
								}
							}
							
						}
					}
				});

				// 주말 포함하여 계산 하기
				if (<?= $setting['set_campaign_holiday_include_yn']?> == 0) {
					// 다시 요일확인(토/일요일이 마지막 날인지 확인하기 위해서)
					day_confirm = new Date(m_date).getDay();
					if (<?=$setting['set_weekend_holidays_yn']?> == 1 ) {
						// 토요일이 마지막 날이면 +2 하기.
						if (day_confirm == 6) {
							m_date.setDate(m_date.getDate() + 2);
							recruit_end_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
						}
						// 일요일이 마지막 날이면 +1 하기.
						if (day_confirm == 0) {
							m_date.setDate(m_date.getDate() + 1);
							recruit_end_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
						}
					}
					
					// 일요일이 마지막 날이면 +1 하기.
					day_confirm = new Date(m_date).getDay();
					if (<?=$setting['set_weekend_holidays_yn']?> == 0 ) {
						if (day_confirm == 0) {
							m_date.setDate(m_date.getDate() + 1);
							recruit_end_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
						}
					}
				}

				//값 입력.
				$('#cam_recruit_end_dt').val( recruit_end_make );
				
			// ***** 리뷰어 발표 자동입력 ******	
				// 이전 날짜값 분할하기 
				arr = recruit_end_make.split('-');
				var m_date2 = new Date( arr[0],arr[1]-1,arr[2] );
				
				// 자동 계산 D-day + 하기. 
				m_date.setDate(m_date.getDate() + <?=$setting['set_campaign_notice_dday']?>);
				var notice_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
			
				// 주말 포함하여 계산 하기
				if (<?= $setting['set_campaign_holiday_include_yn']?> == 0) {
					cnt_Day =  <?=$setting['set_campaign_notice_dday']?>;
					
					// 시작~끝 날짜안에 토/일 있는지 검사.
					for(var i = 1; i <= cnt_Day; i++) {
						m_date2.setDate(m_date2.getDate() + 1);
						start_day = new Date(m_date2).getDay(); // 요일 추출
						
						// 일요일이 있으면 +1.
						if (<?=$setting['set_weekend_holidays_yn']?> == 0 && start_day == 0) {
							m_date.setDate(m_date.getDate() + 1);
							notice_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
						}
						
						// 주말설정 : 토/일요일. 
						if (<?=$setting['set_weekend_holidays_yn']?> == 1 && start_day == 6) {
							m_date.setDate(m_date.getDate() + 2);
							notice_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
							
							// 요일확인(일요일이 마지막 날인지 확인하기 위해서)
							day_confirm = new Date(m_date).getDay();
							// 일요일이 마지막 날이면 +1 하기.
							if (day_confirm == 0) {
								m_date.setDate(m_date.getDate() + 1);
								notice_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
							}
						}
					}			
				}
		
				// 공휴일 확인 및 작업
				$.each( holidays_array, function(index,value) {
					value1 = value.replace(/'/gi,'');
								
					//공휴일 날짜 월,일 1자리를 2자리로 만들기.
					value2 = stringToYYYYMMDD(value1);
					start_dt_val2 = stringToYYYYMMDD(recruit_end_make);
					recruit_end_make2 = stringToYYYYMMDD(notice_dt_make);
					
					strDate = new Date(value2);
					endDate = new Date(start_dt_val2);
					endDate2 = new Date(recruit_end_make2);

					if ( strDate >= endDate) {
						if (strDate <= endDate2) {
							// 요일먼저 확인
							day_confirm = new Date(m_date).getDay();
							
							// 공휴일 있으면 +1씩 하기
							m_date.setDate(m_date.getDate() + 1);
							notice_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
						
							// 주말 포함하여 계산 하기
							if (<?= $setting['set_campaign_holiday_include_yn']?> == 0) {	
								// 토/일요일 포함.
								if (<?=$setting['set_weekend_holidays_yn']?> == 1 ) {
									// 토요일이 있으면 +2 하기.
									if (day_confirm == 6) {
										m_date.setDate(m_date.getDate() + 2);
										notice_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
									}
								}
								// 일요일 포함.
								if (<?=$setting['set_weekend_holidays_yn']?> == 0 ) {
									// 일요일이 있으면 +1 하기.
									if (day_confirm == 0) {
										m_date.setDate(m_date.getDate() + 1);
										notice_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
									}
								}
							}

						}
					}
				});

				// 주말 포함하여 계산 하기
				if (<?= $setting['set_campaign_holiday_include_yn']?> == 0) {
					// 다시 요일확인(토/일요일이 마지막 날인지 확인하기 위해서)
					day_confirm = new Date(m_date).getDay();
					if (<?=$setting['set_weekend_holidays_yn']?> == 1 ) {
						// 토요일이 마지막 날이면 +2 하기.
						if (day_confirm == 6) {
							m_date.setDate(m_date.getDate() + 2);
							notice_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
						}
						// 일요일이 마지막 날이면 +1 하기.
						if (day_confirm == 0) {
								m_date.setDate(m_date.getDate() + 1);
								notice_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
						}
					}
					
					// 일요일이 마지막 날이면 +1 하기.
					day_confirm = new Date(m_date).getDay();
					if (<?=$setting['set_weekend_holidays_yn']?> == 0 && day_confirm == 0) {
						m_date.setDate(m_date.getDate() + 1);
						notice_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
					}
				}

				$('#cam_notice_dt').val( notice_dt_make );

			// ***** 리뷰 등록 시작 자동입력 ******
				// 이전 날짜값 분할하기
				arr = notice_dt_make.split('-');
				var m_date3 = new Date( arr[0],arr[1]-1,arr[2] );
				
				m_date.setDate(m_date.getDate() + <?=$setting['set_campaign_review_start_dday']?>);		
				var review_start_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
				
				// 주말 포함하여 계산 하기
				if (<?= $setting['set_campaign_holiday_include_yn']?> == 0) {			
					cnt_Day =  <?=$setting['set_campaign_review_start_dday']?>;
					
					// 시작~끝 날짜안에 토/일 있는지 검사.
					for(var i = 1; i <= cnt_Day; i++) {
						m_date3.setDate(m_date3.getDate() + 1);
						start_day = new Date(m_date3).getDay(); // 요일 추출
						
						// 일요일이 있으면 +1.
						if (<?=$setting['set_weekend_holidays_yn']?> == 0 && start_day == 0) {
							m_date.setDate(m_date.getDate() + 1);
							review_start_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
						}				
						// 주말설정 : 토/일요일. 
						if (<?=$setting['set_weekend_holidays_yn']?> == 1 && start_day == 6) {
							m_date.setDate(m_date.getDate() + 2);
							review_start_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
							
							// 요일확인(일요일이 마지막 날인지 확인하기 위해서)
							day_confirm = new Date(m_date).getDay();
							// 일요일이 마지막 날이면 +1 하기.
							if (day_confirm == 0) {
								m_date.setDate(m_date.getDate() + 1);
								review_start_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
							}
						}
					}			
				}
			
				// 공휴일 확인 및 작업
				$.each( holidays_array, function(index,value) {
					value1 = value.replace(/'/gi,'');
					
					// 공휴일 날짜 월,일 1자리를 2자리로 만들기.
					value2 = stringToYYYYMMDD(value1);
					start_dt_val2 = stringToYYYYMMDD(notice_dt_make);
					recruit_end_make2 = stringToYYYYMMDD(review_start_dt_make);
					
					strDate = new Date(value2);
					endDate = new Date(start_dt_val2);
					endDate2 = new Date(recruit_end_make2);

					if ( strDate >= endDate) {
						if (strDate <= endDate2) {
							// 요일먼저 확인
							day_confirm = new Date(m_date).getDay();
							
							// 공휴일 있으면 +1씩 하기
							m_date.setDate(m_date.getDate() + 1);
							review_start_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
						
							// 주말 포함하여 계산 하기
							if (<?= $setting['set_campaign_holiday_include_yn']?> == 0) {	
								// 토/일요일 포함.
								if (<?=$setting['set_weekend_holidays_yn']?> == 1 ) {
									//토요일이 있으면 +2 하기.
									if (day_confirm == 6) {
										m_date.setDate(m_date.getDate() + 2);
										review_start_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
									}
								}
								//일요일 포함.
								if (<?=$setting['set_weekend_holidays_yn']?> == 0 ) {
									// 일요일이 있으면 +1 하기.
									if (day_confirm == 0) {
										m_date.setDate(m_date.getDate() + 1);
										review_start_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
									}
								}
							}		
						}
					}
				});
			
				// 주말 포함하여 계산 하기
				if (<?= $setting['set_campaign_holiday_include_yn']?> == 0) {
					// 다시 요일확인(토/일요일이 마지막 날인지 확인하기 위해서)
					day_confirm = new Date(m_date).getDay();
					if (<?=$setting['set_weekend_holidays_yn']?> == 1 ) {
						// 토요일이 마지막 날이면 +2 하기.
						if (day_confirm == 6) {
							m_date.setDate(m_date.getDate() + 2);
							review_start_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
						}
						// 일요일이 마지막 날이면 +1 하기.
						if (day_confirm == 0) {
							m_date.setDate(m_date.getDate() + 1);
							review_start_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
						}
					}
					
					//일요일이 마지막 날이면 +1 하기.
					day_confirm = new Date(m_date).getDay();
					if (<?=$setting['set_weekend_holidays_yn']?> == 0 && day_confirm == 0) {
						m_date.setDate(m_date.getDate() + 1);
						review_start_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
					}
				}
				
				$('#cam_review_start_dt').val( review_start_dt_make );

			//***** 리뷰 등록 끝 자동입력 ******
				//이전 날짜값 분할하기
				arr = review_start_dt_make.split('-');
				var m_date4 = new Date( arr[0],arr[1]-1,arr[2] );
				
				m_date.setDate(m_date.getDate() + <?=$setting['set_campaign_review_end_dday']?>);
				var review_end_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
				
				// 주말 포함하여 계산 하기
				if (<?= $setting['set_campaign_holiday_include_yn']?> == 0) {
					cnt_Day =  <?=$setting['set_campaign_review_end_dday']?>;
					
					// 시작~끝 날짜안에 토/일 있는지 검사.
					for(var i = 1; i <= cnt_Day; i++) {
						m_date4.setDate(m_date4.getDate() + 1);
						start_day = new Date(m_date4).getDay(); //요일 추출
						
						// 일요일이 있으면 +1.
						if (<?=$setting['set_weekend_holidays_yn']?> == 0 && start_day == 0) {
							m_date.setDate(m_date.getDate() + 1);
							review_end_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
						}				
						// 주말설정 : 토/일요일. 
						if (<?=$setting['set_weekend_holidays_yn']?> == 1 && start_day == 6) {
							m_date.setDate(m_date.getDate() + 2);
							review_end_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
							
							// 요일확인(일요일이 마지막 날인지 확인하기 위해서)
							day_confirm = new Date(m_date).getDay();
							// 일요일이 마지막 날이면 +1 하기.
							if (day_confirm == 0) {
								m_date.setDate(m_date.getDate() + 1);
								review_end_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
							}
						}
					}			
				}

				// 공휴일 확인 및 작업
				$.each( holidays_array, function(index,value) {
					value1 = value.replace(/'/gi,'');
								
					// 공휴일 날짜 월,일 1자리를 2자리로 만들기.
					value2 = stringToYYYYMMDD(value1);
					start_dt_val2 = stringToYYYYMMDD(review_start_dt_make);
					recruit_end_make2 = stringToYYYYMMDD(review_end_dt_make);
					
					strDate = new Date(value2);
					endDate = new Date(start_dt_val2);
					endDate2 = new Date(recruit_end_make2);
					
					if ( strDate >= endDate) {
						if (strDate <= endDate2) {
							// 요일먼저 확인
							day_confirm = new Date(m_date).getDay();
							
							// 공휴일 있으면 +1씩 하기
							m_date.setDate(m_date.getDate() + 1);
							review_end_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
						
							// 주말 포함하여 계산 하기
							if (<?= $setting['set_campaign_holiday_include_yn']?> == 0) {	
								//토/일요일 포함.
								if (<?=$setting['set_weekend_holidays_yn']?> == 1 ) {
									// 토요일이 있으면 +2 하기.
									if (day_confirm == 6) {
										m_date.setDate(m_date.getDate() + 2);
										review_end_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
									}
								}
								// 일요일 포함.
								if (<?=$setting['set_weekend_holidays_yn']?> == 0 ) {
									// 일요일이 있으면 +1 하기.
									if (day_confirm == 0) {
										m_date.setDate(m_date.getDate() + 1);
										review_end_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
									}
								}
							}
							
						}
					}
				});
		
				// 주말 포함하여 계산 하기
				if (<?= $setting['set_campaign_holiday_include_yn']?> == 0) {	
					// 다시 요일확인(토/일요일이 마지막 날인지 확인하기 위해서)
					day_confirm = new Date(m_date).getDay();
					if (<?=$setting['set_weekend_holidays_yn']?> == 1 ) {
						// 토요일이 마지막 날이면 +2 하기.
						if (day_confirm == 6) {
							m_date.setDate(m_date.getDate() + 2);
							review_end_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
						}
						// 일요일이 마지막 날이면 +1 하기.
						if (day_confirm == 0) {
								m_date.setDate(m_date.getDate() + 1);
								review_end_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
						}
					}
				
					// 일요일이 마지막 날이면 +1 하기.
					day_confirm = new Date(m_date).getDay();
					if (<?=$setting['set_weekend_holidays_yn']?> == 0 && day_confirm == 0) {
						m_date.setDate(m_date.getDate() + 1);
						review_end_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
					}
				}
				$('#cam_review_end_dt').val( review_end_dt_make );
			
			//***** 베스트 발표 자동입력 ******
				// 이전 날짜값 분할하기
				arr = review_end_dt_make.split('-');
				var m_date5 = new Date( arr[0],arr[1]-1,arr[2] );
				
				m_date.setDate(m_date.getDate() + <?=$setting['set_campaign_best_select_dday']?>);
				var best_select_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
				
				// 주말 포함하여 계산 하기
				if (<?= $setting['set_campaign_holiday_include_yn']?> == 0) {
					cnt_Day =  <?=$setting['set_campaign_best_select_dday']?>;
					
					// 시작~끝 날짜안에 토/일 있는지 검사.
					for(var i = 1; i <= cnt_Day; i++) {
						m_date5.setDate(m_date5.getDate() + 1);
						start_day = new Date(m_date5).getDay(); // 요일 추출
						
						// 일요일이 있으면 +1.
						if (<?=$setting['set_weekend_holidays_yn']?> == 0 && start_day == 0) {
							m_date.setDate(m_date.getDate() + 1);
							best_select_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
						}				
						// 주말설정 : 토/일요일. 
						if (<?=$setting['set_weekend_holidays_yn']?> == 1 && start_day == 6) {
							m_date.setDate(m_date.getDate() + 2);
							best_select_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
							
							// 요일확인(일요일이 마지막 날인지 확인하기 위해서)
							day_confirm = new Date(m_date).getDay();
							// 일요일이 마지막 날이면 +1 하기.
							if (day_confirm == 0) {
								m_date.setDate(m_date.getDate() + 1);
								best_select_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
							}
						}		
					}			
				}
			
				// 공휴일 확인 및 작업
				$.each( holidays_array, function(index,value) {
					value1 = value.replace(/'/gi,'');
					
					// 공휴일 날짜 월,일 1자리를 2자리로 만들기.
					value2 = stringToYYYYMMDD(value1);
					start_dt_val2 = stringToYYYYMMDD(review_end_dt_make);
					recruit_end_make2 = stringToYYYYMMDD(best_select_dt_make);
					
					strDate = new Date(value2);
					endDate = new Date(start_dt_val2);
					endDate2 = new Date(recruit_end_make2);
					
					if ( strDate >= endDate) {
						if (strDate <= endDate2) {
							// 요일먼저 확인
							day_confirm = new Date(m_date).getDay();

							// 공휴일 있으면 +1씩 하기
							m_date.setDate(m_date.getDate() + 1);
							best_select_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
						
							// 주말 포함하여 계산 하기
							if (<?= $setting['set_campaign_holiday_include_yn']?> == 0) {	
								// 토/일요일 포함.
								if (<?=$setting['set_weekend_holidays_yn']?> == 1 ) {
									// 토요일이 있으면 +2 하기.
									if (day_confirm == 6) {
										m_date.setDate(m_date.getDate() + 2);
										best_select_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
									}
								}
								// 일요일 포함.
								if (<?=$setting['set_weekend_holidays_yn']?> == 0 ) {
									// 일요일이 있으면 +1 하기.
									if (day_confirm == 0) {
										m_date.setDate(m_date.getDate() + 1);
										best_select_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
									}
								}
							}
						}
					}
				});
			
				// 주말 포함하여 계산 하기
				if (<?= $setting['set_campaign_holiday_include_yn']?> == 0) {
					// 다시 요일확인(토/일요일이 마지막 날인지 확인하기 위해서)
					day_confirm = new Date(m_date).getDay();
					if (<?=$setting['set_weekend_holidays_yn']?> == 1 ) {
						// 토요일이 마지막 날이면 +2 하기.
						if (day_confirm == 6) {
							m_date.setDate(m_date.getDate() + 2);
							best_select_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
						}
						// 일요일이 마지막 날이면 +1 하기.
						if (day_confirm == 0) {
								m_date.setDate(m_date.getDate() + 1);
								best_select_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
						}
					}
					
					// 일요일이 마지막 날이면 +1 하기.
					day_confirm = new Date(m_date).getDay();
					if (<?=$setting['set_weekend_holidays_yn']?> == 0 && day_confirm == 0) {
						m_date.setDate(m_date.getDate() + 1);
						best_select_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
					}
				}
				
				$('#cam_best_select_dt').val( best_select_dt_make );
			
			//***** datepicker 부분 ******
				// 리뷰어 신청 종료
				var nowDate = $('#cam_recruit_start_dt').datepicker('getDate');
				$("#cam_recruit_end_dt").datepicker(Object.assign(datepickerOption, { minDate: nowDate }));
			
				// 리뷰등록 시작
				var nowDate = $('#cam_notice_dt').datepicker('getDate');
				$("#cam_review_start_dt").datepicker(Object.assign(datepickerOption, { minDate: nowDate }));
			
				// 리뷰등록 종료		
				var nowDate = $('#cam_review_start_dt').datepicker('getDate');
				$("#cam_review_end_dt").datepicker(Object.assign(datepickerOption, { minDate: nowDate }));
			
				// 베스트 발표
				var nowDate = $('#cam_review_end_dt').datepicker('getDate');
				$("#cam_best_select_dt").datepicker(Object.assign(datepickerOption, { minDate: nowDate }));

				// 리뷰신청 날짜가 빈값이면 전부 초기화.
				$cam_recruit_start_val = $(this).val();
				if ($cam_recruit_start_val == '') {
					// 나머지들 초기화.
					$('#cam_recruit_end_dt').val('').css("background","#EAEAEA").attr('disabled',true);
					$('#cam_notice_dt').val('').css("background","#EAEAEA").attr('disabled',true);
					$('#cam_review_start_dt').val('').css("background","#EAEAEA").attr('disabled',true);
					$('#cam_review_end_dt').val('').css("background","#EAEAEA").attr('disabled',true);
					$('#cam_best_select_dt').val('').css("background","#EAEAEA").attr('disabled',true);
				}	
			});
			
		});

		// 리뷰어 발표 (개별로 변경시.)
		$("#cam_recruit_end_dt").change(function() {
			// 활성화하기
			$('#cam_notice_dt').val('').css("background","#fff").attr('disabled',false).removeClass('hasDatepicker');
			
			// 나머지들 초기화.
			$('#cam_review_start_dt').val('').css("background","#EAEAEA").attr('disabled',true);
			$('#cam_review_end_dt').val('').css("background","#EAEAEA").attr('disabled',true);
			$('#cam_best_select_dt').val('').css("background","#EAEAEA").attr('disabled',true);

			// 리뷰어 신청
			var recruit_start = $("#cam_recruit_end_dt").val();
				
			// 날짜 자르기
			var recruit_start_array = recruit_start.split('-');
			var recruit_start_year = recruit_start_array[0];
			var recruit_start_month = recruit_start_array[1];
			var recruit_start_day = recruit_start_array[2];
			
			$("#cam_notice_dt").datepicker(Object.assign(datepickerOption, {
				minDate: new Date(recruit_start_year, recruit_start_month - 1, recruit_start_day)
			}));
		});
			
		// 리뷰 등록 시작
		$("#cam_notice_dt").change(function() {
			//활성화하기
			$('#cam_review_start_dt').val('').css("background","#fff").attr('disabled',false).removeClass('hasDatepicker');
			
			//나머지들 초기화.
			$('#cam_review_end_dt').val('').css("background","#EAEAEA").attr('disabled',true);
			$('#cam_best_select_dt').val('').css("background","#EAEAEA").attr('disabled',true);
			
			//리뷰어 신청
			var nowDate = $('#cam_notice_dt').datepicker('getDate');
			
			$("#cam_review_start_dt").datepicker(Object.assign(datepickerOption, { minDate: nowDate }));
		});
		
		//리뷰 등록 끝
		$("#cam_review_start_dt").change(function() {
			//활성화하기
			$('#cam_review_end_dt').val('').css("background","#fff").attr('disabled',false).removeClass('hasDatepicker');
			
			//나머지들 초기화.
			$('#cam_best_select_dt').val('').css("background","#EAEAEA").attr('disabled',true);
					
			//리뷰어 신청
			var nowDate = $('#cam_review_start_dt').datepicker('getDate');
			$("#cam_review_end_dt").datepicker(Object.assign(datepickerOption, { minDate: nowDate }));
		});
		
		// 리뷰 등록 끝
		$("#cam_review_end_dt").change(function() {
			// 활성화하기
			$('#cam_best_select_dt').val('').css("background","#fff").attr('disabled',false).removeClass('hasDatepicker');		
			// 리뷰어 신청
			var nowDate = $('#cam_review_end_dt').datepicker('getDate');
			$("#cam_best_select_dt").datepicker(Object.assign(datepickerOption, { minDate: nowDate }));
		});
	}
	else // 수정
	{
		// 리뷰어 신청 시작
		$("#cam_recruit_start_dt,#cam_recruit_end_dt,#cam_notice_dt,#cam_review_start_dt,#cam_review_end_dt,#cam_best_select_dt").datepicker(datepickerOption);
	}
	// **** 달력 ****


	// ***내용*** 방문형 배송형 따라서 변경하기.
	$('input:radio[name=cam_type]').change(function() {
		$cam_type_val = $( 'input:radio[name=cam_type]:checked' ).val();
		$(".cam_content_type1").hide();
		$(".cam_content_type2").hide();
		$(".cam_content_receipt").hide();
		$(".cam_content_reservation").hide();
		$(".cam_content_PressCorps").hide();
		$(".norun").hide();
		switch ($cam_type_val) {
			case 'visite':
				$(".cam_content_type1").show();
				$(".cam_content_type1").css('padding-top','0px');
			break;
			case 'delivery':
				$(".cam_content_type2").show();
				$(".cam_content_type2").css('padding-top','0px');
			break;
			case 'PressCorps':
				$(".cam_content_PressCorps").show();
				$(".cam_content_PressCorps").css('padding-top','0px');
				$(".norun").show();
			break;
			case 'receipt':
				$(".cam_content_receipt").show();
				$(".cam_content_receipt").css('padding-top','0px');
			break;
			case 'reservation':
				$(".cam_content_reservation").show();
				$(".cam_content_reservation").css('padding-top','0px');
			break;
		}
	});
	
	// 캠페인 복사 모달.
	$(document).off('click','.cam_copy').on('click', '.cam_copy', function(e) {
		// 이전에 모집인원 html 만든게 있으면 지우기.
		$(".cam_recruit_count_wrap").detach();
		
		// 캠페인 idx 값.
		var cam_idx_copy = $(this).next().val();
		// 모집인원, 회원아이디 값.
		var pro_mb_id = $(this).next().next().val();
		// 캠페인 진행 상품회차.
		var pdo_prd_times = $(this).next().next().next().val();

		// 다시회차,복사 구분방법.
		var text_device = $(this).html();
		
		if ( text_device == '다시회차') {
			var text_device_val = 're';
			// 복사에서 사용하는 기능 숨기기.
			$(".pro_copy_wrap").hide();
			$(".pro_copy_wrap").before(
				'<div class="cam_recruit_count_wrap">'
					+'<span class="cam_recruit_count_title">모집인원 : </span>'
					+'<input type="text" name="cam_recruit_form_count" value="'+pro_mb_id+'" class="cam_recruit_count_input" >'
				+'</div>');
			// submit 이름 변경하기.
			$("#cam_copy_submit").val("진행");
		} else {
			// 다시회차 에서 숨긴 상품선택 보이게하기.
			$(".pro_copy_wrap").show();
			var text_device_val = 'cp';
			// submit 이름 변경하기.
			$("#cam_copy_submit").val("복사");
		}
		
		$(".modal_title").text('캠페인 '+text_device);
		
		// 모달 창 오픈
		$('#modal09').bPopup(function() {
			if ( text_device_val == 'cp') {
				// ajax로 상품선택 만들기.
				$.ajax({
					url:g5_url+'/_u/ajax/ajax_cam_copy.php', type:'get',
					data:{"mod":"list","cam_idx":cam_idx_copy,"mb_id":pro_mb_id}, 
					dataType:'json', timeout:40000,
					success:function(res) {
						// 옵션 입력하기.
						$("#goods_check2").html(res.op_list);
					}
				});
			}
			
			// submit 클릭!
			$(document).off('click','#cam_copy_submit').on('click','#cam_copy_submit',function(e) {
				
				if ( text_device_val == 'cp') {
					// 상품선택 빈값 확인.
					if ( $('#goods_check2').val().length < 1) {
						alert("상품을 선택해주세요.");
						$('#goods_check2').focus();
						return false;
					};
				}
				
				if ( text_device_val == 're') {
					// 모집인원 빈값 확인.
					if ( $('input[name=cam_recruit_form_count]').val().length < 1) {
						alert("모집인원을 입력해주세요.");
						$('input[name=cam_recruit_form_count]').focus();
						return false;
					};
				}
				
				// 날짜 빈값확인.
				if ( $('#cam_copy_day').val().length < 1) {
					alert("날짜를 입력해주세요.");
					$('#cam_copy_day').focus();
					return false;
				};

				document.getElementById("cam_copy_submit").disabled = "disabled";

				// 값 가져오기.
				var goods_check2 = $('#goods_check2').val();
				var start_day = $('#cam_copy_day').val();
				var cam_recruit_count = $('input[name=cam_recruit_form_count]').val();
				
				// ajax 작업.
				$.ajax({
					url:g5_url+'/_u/ajax/ajax_cam_copy.php', type:'get',
					data:{"mod":"in","cam_idx":cam_idx_copy,"start_day":start_day,"goods_check2":goods_check2,"text_device_val":text_device_val,"cam_recruit_count":cam_recruit_count,"pdo_prd_times":pdo_prd_times}, 
					dataType:'json', timeout:40000,
					async:false,
					success:function(res) {
						alert( res.msg );
						location.reload();
					}
				});
			});
		});
	});	
	// 캠페인 복사 달력.
	$("#cam_copy_day").datepicker(datepickerOption);
});

		
// 모달창에 불러올 현재 레벨 설정 (초기=업체회원!)
var modal_mb_lv = 4;

function form01_submit(f) {
	<?=get_editor_js("cam_content")?>	
	<?=get_editor_js("cam_content1")?>
	<?=get_editor_js("cam_content2")?>
    <?=get_editor_js("cam_content3")?>
    <?=get_editor_js("cam_content4")?>
	
	if (!f.prd_name.value) {
		alert('신청상품을 선택해 주세요.');
		return false;
	}
	
	if (!f.com_idx.value) {
		alert('업체를 선택해 주세요.');
		return false;
	}
	
	// 복사태그
	if (f.cam_tags.value.length < 0) {
		alert("두자이상 복사태그를 입력해주세요.");
		f.cam_tags.focus();
		return false;
	};
	
	// 업데이트 중에 두번클릭 막기.
	document.getElementById("btn_submit").disabled = "disabled";
	document.getElementById("btn_submit2").disabled = "disabled";
	document.getElementById("btn_cancel").disabled = "disabled";
	
	$("#btn_submit").hide();
	$("#btn_cancel").hide();
	$("#btn_submit2").hide();
	$(".cam_copy").hide();
	
	$(".btn_confirm").append(" <img src='"+g5_url+"/theme/kafain_10/img/loading.gif' alt=''> <div class='up_ing'>등록중 입니다.</div>");
	
    return true;
}

// 일괄수정 클릭.
$('#btn_submit2').click(function() {	
	var result = confirm( '[ <?=$proo['pdo_prd_name']?> 상품 ] 캠페인들 기간설정을 일괄수정 하시겠습니까?' );
	if (result) {
		$("#cam_auto").val(1); // value 값 변경(일괄수정  = 1, 일반수정 = 0).
		$("#form01").submit();
	} else {
		return false;
	}
});

</script>

<?php
include_once (G5_ADMIN_PATH.'/admin.tail.php');
?>
