<?php
$sub_menu = '910210';
include_once("./_common.php");
include_once(G5_LIB_PATH.'/register.lib.php');
include_once(G5_LIB_PATH.'/thumbnail.lib.php');
include_once(G5_LIB_PATH.'/mailer.lib.php');
include_once(G5_LIB_PATH.'/pclzip.lib.php');

// error_reporting(E_ALL);
// ini_set("display_errors", 1);

if (!function_exists('rm_rf')) {
function rm_rf($file) {
    if (file_exists($file)) {
        if (is_dir($file)) {
            $handle = opendir($file);
            while($filename = readdir($handle)) {
                if ($filename != '.' && $filename != '..')
                    rm_rf($file.'/'.$filename);
            }
            closedir($handle);

            @chmod($file, G5_DIR_PERMISSION);
            @rmdir($file);
        } else {
            @chmod($file, G5_FILE_PERMISSION);
            @unlink($file);
        }
    }
}
}

if (!function_exists('zip_dir')) {
function zip_dir($dir) {
	$allowed_ext = "/jpg|jpeg|png|bmp|gif/i";
	if (is_dir($dir)) {
		$handle = opendir($dir);
		while ($file = readdir($handle)) {
			if ($file != "." && $file != "..") {
				$file_info = pathinfo($file);
				preg_match($allowed_ext, $file_info['extension'], $matches);
				if (count($matches) <= 0) {
					if (is_dir($dir."/".$file)) {
						rm_rf($dir.'/'.$file);
					} else {
						@unlink($dir."/".$file);
					}
				}
				
				if (preg_match("/[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]/", $file)) {
					$new_name = md5($file_info['filename']).'.'.$file_info['extension'];
					@rename($dir.'/'.$file, $dir.'/'.$new_name);
				}
			}
		}
	}
}
}

$today = date("Y-m-d 23:59:59", mktime(00,00,00,date("m")  , date("d"), date("Y")));


// 주소 길이 줄이기.
$USER_URL = str_replace("http://www.", " ", G5_USER_URL);

// 업데이트하기.
if ($w == 'u')
    check_demo();

auth_check($auth[$sub_menu], 'w');
//check_admin_token();


// 넘겨줄 변수가 많아서 qstr 별도 설정
$qstr = $qstr.$qsns."&amp;sfl_date=$sfl_date&amp;st_date=$st_date&amp;en_date=$en_date"
	."&amp;sfl_date2=$sfl_date2&amp;st_date2=$st_date2&amp;en_date2=$en_date2"
	."&amp;ser_trm_cat1=$ser_trm_cat1&amp;ser_trm_cat2=$ser_trm_cat2&amp;ser_trm_cat3=$ser_trm_cat3"
	."&amp;ser_trm_salesarea=$ser_trm_salesarea"
	."&amp;sns_trm_idxs=$sns_trm_idxs";

//내용
if ( $cam_type == 'visite' ) {
	$cam_content =  $cam_content;
}
if ( $cam_type == 'delivery' ) {
	$cam_content =  $cam_content1;
}
if ( $cam_type == 'PressCorps' ) {
	$cam_content =  $cam_content2;
}
if ( $cam_type == 'receipt' ) {
	$cam_content =  $cam_content3;
}
if ( $cam_type == 'reservation' ) {
	$cam_content =  $cam_content4;
}
// 신청 정보 추출
$pdo = sql_fetch(" SELECT * FROM {$g5['product_order_table']} WHERE pdo_idx = '".$pdo_idx."' ");
$prd = sql_fetch(" SELECT * FROM {$g5['product_table']} WHERE prd_idx = '".$pdo['prd_idx']."' ");

// 캠페인 정보 추출
if ($w != '') {
	$cam = sql_fetch(" SELECT * FROM {$g5['campaign_table']} WHERE cam_idx = '".$cam_idx."' ");

	// 취소인 경우 취소날짜 / 취소를 취소하는 경우는 다시 날짜 복구
	if ( $cam['pdo_status'] != 'cancel' && $pdo_status == 'cancel')
		$sql_cancel_dt = " , pdo_cancel_dt = '".G5_TIME_YMDHIS."' ";
	if ( $cam['pdo_status'] == 'cancel' && $pdo_status != 'cancel')
		$sql_cancel_dt = " , pdo_cancel_dt = '0000-00-00 00:00:00' ";
}

// 최종 결제일 있는 경우만 설정
$sql_pdo_payall_dt = ($pdo_payall_dt) ? " , pdo_payall_dt = '".$pdo_payall_dt."' " : " , pdo_payall_dt = '0000-00-00 00:00:00' ";

$sql_common = "	mb_id_company = '{$_POST['mb_id_company']}'
	, mb_id_saler = '{$_POST['mb_id_saler']}'
	, com_idx = '{$_POST['com_idx']}'
	, pdo_idx = '{$_POST['pdo_idx']}'
	, trm_idx_cat1 = '{$_POST['trm_idx_cat1']}'
	, trm_idx_cat2 = '{$_POST['trm_idx_cat2']}'
	, trm_idx_cat3 = '{$_POST['trm_idx_cat3']}'
	, trm_idx_salesarea = '{$_POST['trm_idx_salesarea']}'
	, cam_auto_make_yn = '{$cam_auto_make_yn}'
	, cam_prd_time = '{$_POST['cam_prd_time']}'	
    , cam_mb_name = '{$_POST['cam_mb_name']}'
    , com_naver_place_url = '{$_POST['com_naver_place_url']}'
	, cam_mb_tel = '{$_POST['cam_mb_tel']}'
	, cam_mb_email = '{$_POST['cam_mb_email']}'
	, cam_mb_saler = '{$_POST['mb_name_saler']}'
	, cam_prd_name = '{$_POST['prd_name']}'
	, cam_nct = '{$_POST['cam_nct']}'
	, cam_nct_only = '{$_POST['cam_nct_only']}'
	, cam_nct_cnt = '{$_POST['cam_nct_cnt']}'
	, cam_type = '{$_POST['cam_type']}'
    , cam_name = '{$_POST['cam_name']}'
	, cam_brief = '{$_POST['cam_brief']}'
	, cam_reviewer_yn = '{$_POST['cam_reviewer_yn']}'
	, cam_recruit_count = '{$_POST['cam_recruit_count']}'
	, mb_id_info = '{$_POST['mb_id_info']}'
	, cam_info_reg_dt = '{$_POST['cam_info_reg_dt']}'
	, cam_recruit_start_dt = '{$_POST['cam_recruit_start_dt']}'
	, cam_recruit_end_dt = '{$_POST['cam_recruit_end_dt']}'
	, cam_notice_dt = '{$_POST['cam_notice_dt']}'
	, cam_notice_status = '{$_POST['cam_notice_status']}'
	, cam_review_start_dt = '{$_POST['cam_review_start_dt']}'
	, cam_review_end_dt = '{$_POST['cam_review_end_dt']}'
	, cam_best_select_dt = '{$_POST['cam_best_select_dt']}'
	, cam_best_use_yn = '{$_POST['cam_best_use_yn']}'
	, cam_point_type = '{$_POST['cam_point_type']}'
	, cam_reviewer_point = '{$_POST['cam_reviewer_point']}'
	, cam_best_point = '{$_POST['cam_best_point']}'
	, cam_head_content = '{$_POST['cam_head_content']}'
    , cam_tags = '{$cam_tags}'
    , cam_option = '{$cam_option}'
	, cam_content = '{$cam_content}'
	, cam_notice = '{$_POST['cam_notice']}'	
	, cam_memo = '{$_POST['cam_memo']}'
	, cam_status = '{$_POST['cam_status']}'
";

// 생성
if ($w == '') {
	
	// 캠페인 자동등록 할때. hd02
	if ($cam_auto_make_yn == '1') {
		for ($i = $cam_prd_time ; $i <= $pdo_prd_times ; $i++) {
			// 처음 입력되는 값들.
			if ( $i == $cam_prd_time ) {
				$cam_period = " cam_recruit_start_dt = '{$cam_recruit_start_dt}',
								cam_recruit_end_dt = '{$cam_recruit_end_dt}',
								cam_notice_dt = '{$cam_notice_dt}',
								cam_notice_status = '{$cam_notice_status}',
								cam_review_start_dt = '{$cam_review_start_dt}',
								cam_review_end_dt = '{$cam_review_end_dt}',
								cam_best_select_dt = '{$cam_best_select_dt}' ";
			}
			// 자동등록으로 입력되는 값들.
			else {
				
				$cam_row = sql_fetch( "SELECT * FROM {$g5['campaign_table']} ORDER BY cam_idx DESC" ,1);
				
				// 자동등록에 시작할 날짜 설정하기. (베스트사용)
				if ($cam_best_use_yn == '1') {					
					$start_day = $cam_row['cam_best_select_dt'];
				}
				// 베스트 미사용.
				else {
					$start_day = $cam_row['cam_review_end_dt'];
				}
				
				// 함수로 자동날짜 만들기.
				$cam_period = cam_day_auto($start_day);
				$cam_period .= ", cam_notice_status = '".$cam_notice_status."' ";
			}
			
			$sql = " insert into  {$g5['campaign_table']}
					set pdo_idx = '{$pdo_idx}',
						cam_type = '{$cam_type}',
						cam_reviewer_yn = '{$cam_reviewer_yn}',
						mb_id_company = '{$mb_id_company}',
						com_idx = '{$com_idx}',
						cam_prd_name = '{$prd_name}',
						cam_nct = '{$cam_nct}',
						cam_nct_only = '{$cam_nct_only}',
						cam_nct_cnt = '{$cam_nct_cnt}',
						mb_id_saler = '{$mb_id_saler}',
						cam_mb_saler = '{$mb_name_saler}',
						trm_idx_cat1 = '{$trm_idx_cat1}',
						trm_idx_cat2 = '{$trm_idx_cat2}',
						trm_idx_cat3 = '{$trm_idx_cat3}',
						trm_idx_salesarea = '{$trm_idx_salesarea}',
						cam_auto_make_yn = '{$cam_auto_make_yn}',
						cam_channels = '{$cam_channels}',
						cam_prd_time = '{$i}',
                        cam_mb_name = '{$cam_mb_name}',
                        com_naver_place_url = '{$com_naver_place_url}',
						cam_mb_tel = '{$cam_mb_tel}',
						cam_mb_email = '{$cam_mb_email}',
                        cam_name = '{$cam_name}',
						cam_brief = '{$cam_brief}',
						cam_recruit_count = '{$cam_recruit_count}',
						mb_id_info = '{$member['mb_id']}',
						cam_info_reg_dt = '".G5_TIME_YMDHIS."',
						".$cam_period.",
						cam_point_type = '{$cam_point_type}',
						cam_best_use_yn = '{$cam_best_use_yn}',
						cam_reviewer_point = '{$cam_reviewer_point}',
						cam_best_point = '{$cam_best_point}',
						cam_head_content = '{$cam_head_content}',
                        cam_tags = '{$cam_tags}',
                        cam_option = '{$cam_option}',
						cam_content = '{$cam_content}',
						cam_reg_dt = '".G5_TIME_YMDHIS."',
						cam_status = '{$cam_status}' ";

			sql_query($sql); 			
			$cam_idx = sql_insert_id();
			
			// campaign_table에 다시회차 사용할 cam_idx_parent에 자기자신 아이디값으로 업데이트하기.
			$sql2 = " UPDATE {$g5['campaign_table']} SET  cam_idx_parent = '{$cam_idx}' WHERE cam_idx = '{$cam_idx}' ";
			sql_query($sql2);
			
			unset($start_day, $cam_period);
			
			// Campaign - Term relation SNS 정보 업데이트
			if ( sizeof($sns_channel) ) {
				for ($j=0;$j<sizeof($sns_channel);$j++) {
					//-- 기존 디비 삭제를 위해 배열 미리 생성 --//
					$sns_channel_array[] = $sns_channel[$j];
					// cam_channels 정보 설정
					$cam_channels .= '^'.$sns_channel[$j].'^,';

					// term_relation 정보 업데이트 (있으면 수정, 없으면 추가)
					term_relation_update(array('tmr_db_table'=>'campaign'
													,'tmr_db_key'=>'channel'
													,'trm_idx'=>$sns_channel[$j]
													,"tmr_db_id"=>$cam_idx
													,"dup_permit"=>1
					));
				}

				// 삭제(해제)된 항목들을 관련 디비 전부 제거함
				$del_where = (sizeof($sns_channel_array))? " AND trm_idx NOT IN (".implode(",",$sns_channel_array).") ":"";
				$sql = " DELETE FROM {$g5['term_relation_table']} WHERE tmr_db_id='{$cam_idx}' ".$del_where." ";
				sql_query($sql);			
				
				// 캠페인 SNS 채널 정보 업데이트
				$sql = " UPDATE {$g5['campaign_table']} SET cam_channels = '".substr($cam_channels,0,-1)."' WHERE cam_idx='".$cam_idx."' ";
				sql_query($sql);
				
				unset($cam_channels);
			}
			
			// 자동등록 파일 처리 (파일 타입이 여러개면 일련번호 붙여서 확장해 주세요.) 등록한 파일수 만큼 돌아라~!
			$fle_type1 = "campaign_img";
			for ($j=0;$j<count( array_filter($_FILES[$fle_type1.'_file']['name']) );$j++) {
				
				// 자동등록 시 맨 처음 캠페인?
				if ($i == $cam_prd_time) {
					// 파일 등록
					$uploaded[] = upload_jt_file(array("fle_idx"=>$fle_idx
										,"mb_id"=>$member['mb_id']
										,"fle_src_file"=>$_FILES[$fle_type1.'_file']['tmp_name'][$j] //파일이름.
										,"fle_orig_file"=>$_FILES[$fle_type1.'_file']['name'][$j] //원본 파일명.
										,"fle_mime_type"=>$_FILES[$fle_type1.'_file']['type'][$j] //이미지 타입정보.
										,"fle_content"=>$fle_content
										,"fle_path"=>'/data/campaign_img/'.$cam_idx		//<---- 저장 디렉토리
										,"fle_db_table"=>"campaign"
										,"fle_db_id"=>$cam_idx
										,"fle_type"=>$fle_type1
										,"fle_sort"=>$j
					));					
					
					// 압축파일 해제
					if ($_FILES[$fle_type1.'_file']['name'][4]) {
						$zip_info = pathinfo($_FILES[$fle_type1.'_file']['name'][4]);
						$extract_dir = G5_DATA_PATH.'/campaign_img/'.$cam_idx.'/'.$zip_info['filename'];
						
						$archive = new PclZip(G5_DATA_PATH.'/campaign_img/'.$cam_idx.'/'.$_FILES[$fle_type1.'_file']['name'][4]);
						$archive->extract(PCLZIP_OPT_PATH, $extract_dir);
						@chmod($extract_dir, G5_DIR_PERMISSION);
					}
					
				}
				// 자동등록 시 맨 처음 아닌 경우
				else {					
					// 처음등록된 캠페인번호 저정하기. 복사할떄 사용해야함.
					$first_id = sql_fetch(" SELECT * FROM {$g5['campaign_table']} WHERE cam_name = '{$cam_name}' AND mb_id_info = '{$member['mb_id']}' AND cam_idx = cam_idx_parent AND cam_prd_time = '1' ");

					// 디렉토리 생성 (퍼미션도 변경! = 폴더 사용권한 open)
					@mkdir(G5_PATH.'/data/campaign_img/'.$cam_idx, G5_DIR_PERMISSION);
					@chmod(G5_PATH.'/data/campaign_img/'.$cam_idx, G5_DIR_PERMISSION);

					// 디렉토리 설정
					$dir = G5_PATH.'/data/campaign_img/'.$cam_idx;
					// 원본 파일 경로
					$dir2 = G5_PATH.'/data/campaign_img/'.$first_id['cam_idx'];
					// copy 서버에 파일생성. (원본,복사)
					copy( $dir2.'/'.$uploaded[$j]['upfile_name'],$dir.'/'.$uploaded[$j]['upfile_name'] );

					// 업로드 한후 ,퍼미션을 변경함 (폴더 사용권한 close)
					@chmod($dir2.'/'.$uploaded[$j]['upfile_name'], G5_FILE_PERMISSION);
					
					// 0번째 입력된 파일정보 추출하기.
					$file0 = sql_fetch( "SELECT * FROM {$g5['file_table']} WHERE mb_id = '{$member['mb_id']}' AND fle_db_id = '{$first_id['cam_idx']}' AND fle_name_orig = '{$_FILES[$fle_type1.'_file']['name'][$j]}' AND fle_sort = '{$j}' ");
					
					// DB에 입력하기.
					$fle_sql = " INSERT INTO {$g5['file_table']} SET
									mb_id='".$file0['mb_id']."'
									, fle_db_table='".$file0['fle_db_table']."'
									, fle_db_id='".$cam_idx."'
									, fle_type='".$file0['fle_type']."'
									, fle_host='".$file0['fle_host']."'
									, fle_path='/data/campaign_img/{$cam_idx}'
									, fle_name='".$file0['fle_name']."'
									, fle_name_orig='".$file0['fle_name_orig']."'
									, fle_width='".$file0['fle_width']."'
									, fle_height='".$file0['fle_height']."'
									, fle_content='".$file0['fle_content']."'
									, fle_password='".$file0['fle_password']."'
									, fle_down_level='".$file0['fle_down_level']."'
									, fle_down_max='".$file0['fle_down_max']."'
									, fle_expire_date='".$file0['fle_expire_date']."'
									, fle_sort='".$file0['fle_sort']."'
									, fle_mime_type='".$file0['fle_mime_type']."'
									, fle_filesize='".$file0['fle_filesize']."'
									, fle_token='".$file0['fle_token']."'
									, fle_status='".$file0['fle_status']."' 
									, fle_reg_dt='".G5_TIME_YMDHIS."'
							";
					sql_query($fle_sql);					
				}
			};
			
			// 태그 수정 & 입력 START ******************
			$tag_text = $cam_idx.'_kafain';
			$tag_text_array = explode("#",$tag_text); // 테그입력 #으로 분할
			
			foreach(array_filter($tag_text_array) as $tag) {
				$trm1 = sql_fetch(" SELECT trm_idx,trm_name FROM {$g5['term_table']} WHERE trm_taxonomy = 'campaign_tag' AND trm_name = '".trim($tag)."' ");
				$tag_split = trim($tag);
				
				// 삭제를 위해서 배열을 생성
				$trm_exist_array .= ','.$trm1['trm_idx'];
						
				if (!$trm1['trm_idx']) { //term 없으면 입력.
					if (ISSET($tag_split)) {
						$sql = "INSERT INTO  {$g5['term_table']} SET trm_idx_parent = '0', trm_country = 'ko_KR', trm_name = '{$tag_split}', trm_taxonomy = 'campaign_tag', trm_status = 'ok', trm_reg_dt = '".G5_TIME_YMDHIS."' ";						
						sql_query($sql);
						$trm_idx2 = sql_insert_id();
						
						$sql2 = " INSERT INTO  {$g5['term_relation_table']} SET trm_idx = '{$trm_idx2}', tmr_db_table = 'campaign', tmr_db_key = 'campaign_tag', tmr_db_id = '{$cam_idx}', tmr_reg_dt = '".G5_TIME_YMDHIS."' ";
						sql_query($sql2);
					}
				}
				// term 있으면 입력.
				else {
					if (ISSET($tag_split)) {
						$trm2 = sql_fetch(" SELECT trm_idx FROM {$g5['term_relation_table']} WHERE tmr_db_key = 'campaign_tag' AND trm_idx = '{$trm1['trm_idx']}' AND tmr_db_id = '{$cam_idx}' ");
						
						if (!$trm2['trm_idx']) { //term_relation 없으면 입력.
							$sql3 = " INSERT INTO  {$g5['term_relation_table']} SET trm_idx = '{$trm1['trm_idx']}', tmr_db_table = 'campaign', tmr_db_key = 'campaign_tag', tmr_db_id = '{$cam_idx}', tmr_reg_dt = '".G5_TIME_YMDHIS."' ";
							sql_query($sql3);
						}
					}
				}
			}
						
			// 기존에는 있었는데 삭제된 태그들 제거
			if (substr($trm_exist_array,1)) {
				sql_query(" DELETE FROM {$g5['term_relation_table']} 
							WHERE tmr_db_table = 'campaign' 
								AND tmr_db_key = 'campaign_tag'
								AND tmr_db_id = '".$cam_idx."'
								AND trm_idx NOT IN (".substr($trm_exist_array,1).") ");
			}
			// 태그 수정 & 입력 END ******************
			
		};//배열 끝
	}
	// 캠페인 1개등록 할때.
	if ($cam_auto_make_yn == '0') {
		// 진행 차수 오버 체크
		$cam_sum = sql_fetch(" SELECT count(cam_idx) AS cnt FROM {$g5['campaign_table']} WHERE pdo_idx = '{$pdo_idx}' AND cam_status NOT IN ('cancel','trash') ");
		if ( $cam_sum['cnt'] >= $pdo['pdo_prd_times'] ) {
			alert("진행 횟수 오버입니다. 새로 상품을 구매하신 후 캠페인을 신청을 해 주세요.");
		}
		
		// 업체 정보 생성
		$sql = " INSERT into {$g5['campaign_table']}
					SET cam_reg_dt = '".G5_TIME_YMDHIS."'
					,{$sql_common} 
		";
		sql_query($sql,1);
		$cam_idx = sql_insert_id();
		
		// campaign_table에 다시회차 사용할 cam_idx_parent에 자기자신 아이디값으로 업데이트하기.
		$sql2 = " UPDATE {$g5['campaign_table']} SET  cam_idx_parent = '{$cam_idx}' WHERE cam_idx = '{$cam_idx}' ";
		sql_query($sql2);
		
		$tag_text = $cam_idx.'_kafain';//태그
		
		// Campaign - Term relation SNS 정보 업데이트
		if ( sizeof($sns_channel) ) {
			for ($i=0;$i<sizeof($sns_channel);$i++) {
				// 기존 디비 삭제를 위해 배열 미리 생성
				$sns_channel_array[] = $sns_channel[$i];
				// cam_channels 정보 설정
				$cam_channels .= '^'.$sns_channel[$i].'^,';

				// term_relation 정보 업데이트 (있으면 수정, 없으면 추가)
				term_relation_update(array('tmr_db_table'=>'campaign'
												,'tmr_db_key'=>'channel'
												,'trm_idx'=>$sns_channel[$i]
												,"tmr_db_id"=>$cam_idx
												,"dup_permit"=>1
				));
			}
		}
		// 삭제(해제)된 항목들을 관련 디비 전부 제거함
		$del_where = (sizeof($sns_channel_array))? " AND trm_idx NOT IN (".implode(",",$sns_channel_array).") ":"";
		$sql = " DELETE FROM {$g5['term_relation_table']} WHERE tmr_db_id='{$cam_idx}' ".$del_where." ";
		sql_query($sql);

		// 캠페인 SNS 채널 정보 업데이트
		$sql = " UPDATE {$g5['campaign_table']} SET cam_channels = '".substr($cam_channels,0,-1)."' WHERE cam_idx='".$cam_idx."' ";
		sql_query($sql);
		
		unset($cam_channels);	
	}
}
// 수정
else if ($w == 'u') {

	if (!$cam['cam_idx'])
		alert('존재하지 않는 신청자료입니다.');
 
	//리뷰 등록 종료일 변경되면 u_campaign_apply -> cma_reg_end_dt 같이 변경하기.
	//변경전 리뷰 등록 종료일 추출.
	$now_cam = sql_fetch( "SELECT * FROM {$g5['campaign_table']} WHERE cam_idx='{$cam_idx}' ",1); 
	
	if ( $now_cam['cam_review_end_dt'] != $cam_review_end_dt ) {
		sql_query(" UPDATE {$g5['campaign_apply_table']} SET cma_reg_end_dt = '{$cam_review_end_dt}' WHERE cam_idx = '{$cam_idx}' AND cma_reg_end_dt = '{$now_cam['cam_review_end_dt']}' ",1);
	}
	
	//캠페인 업데이트.
    $sql = " UPDATE {$g5['campaign_table']} SET {$sql_common}, cam_prd_retime = '{$_POST['cam_prd_retime']}', cam_sort = '{$_POST['cam_sort']}' WHERE cam_idx = '{$cam_idx}' ";
    sql_query($sql,1);
		
	//캠페인 테이블에 상권 변경하기.
	$sql = " UPDATE {$g5['campaign_table']} SET trm_idx_salesarea = '{$_POST['trm_idx_salesarea']}' WHERE com_idx = '{$com_idx}' ";
    sql_query($sql,1);
	
	// 업체 테이블에 상권 변경하기.
	$sql = " UPDATE {$g5['company_table']} SET trm_idx_salesarea = '{$_POST['trm_idx_salesarea']}' WHERE com_idx = '{$com_idx}' ";
    sql_query($sql,1);

	// 일괄수정
	if ($cam_auto == '1') {
		// 처음값은 위에서 +1한 값으로 루프돌리기.
		$cam_prd_time_p = $cam_prd_time + 1;
		
		for ($i = $cam_prd_time_p ; $i <= $pdo_prd_times ; $i++) {			
			// 등록할 캠페인 추출하기.
			$cam = sql_fetch(" SELECT * FROM {$g5['campaign_table']} WHERE pdo_idx = '".$pdo_idx."' AND cam_prd_time = '".number_format($i-1)."' ");
				
			// 자동등록에 시작할 날짜 설정하기. (베스트사용)
			if ($cam['cam_best_use_yn'] == '1') {
				// 처음 루프는 지금입력한 캠페인 시작기준은
				if ( $cam_prd_time_p == $i ) {
					$start_day2 = $cam_best_select_dt;
				} else {
					$start_day2 = $cam['cam_best_select_dt'];
				}
			}
			// 베스트 미사용.
			else {
				// 처음 루프는 지금입력한 캠페인 시작기준은
				if ($cam_prd_time_p == $i) {
					$start_day2 = $cam_review_end_dt;
				} else {
					$start_day2 = $cam['cam_review_end_dt'];
				}
			}			
			// 함수로 자동날짜 만들기.
			$cam_period2 = cam_day_auto($start_day2);
			
			// 업데이트할 캠페인 추출하기.
			$cam2 = sql_fetch(" SELECT * FROM {$g5['campaign_table']} WHERE pdo_idx = '".$pdo_idx."' AND cam_prd_time = '".$i."' ");
			
			// 업데이트하기.
			$sql2 = " UPDATE {$g5['campaign_table']} SET ".$cam_period2." WHERE cam_idx = '".$cam2['cam_idx']."' ";
			sql_query($sql2,1);			
		}
	}
	
	// 업체요청으로 캠페인 중단하면 (리뷰등록 선정자들에게 cma_review_yn = 1 로 만들어주기.)
	if ( $cam_status == 'com_cancel') {		
		$sql3 = " UPDATE {$g5['campaign_apply_table']} SET cma_review_yn = '1' WHERE cam_idx = '".$cam_idx."' AND cma_status = 'chosen' ";
		sql_query($sql3,1);		
    }
}
else if ($w=="d") {

	if (!$cam['cam_idx']) {
		alert('존재하지 않는 신청자료입니다.');
	} else {
		// 자료 삭제
		$sql = " UPDATE {$g5['campaign_table']} SET cam_status = 'trash' WHERE cam_idx = $cam_idx ";
		sql_query($sql,1);
	}
	
	goto_url('./campaign_list.php?'.$qstr, false);
}
else
    alert('제대로 된 값이 넘어오지 않았습니다.');

// 내용 변수 삭제.
unset($cam_content);

// keyword
if ($cam_idx && is_array($keyword) && count($keyword) > 0) {
	$sql = "DELETE FROM {$g5['keyword_campaign_table']} WHERE cam_idx = '{$cam_idx}'";
	sql_query($sql);
	
	$keywords = "";
	$keyword = array_unique($keyword);
	$keyword = array_filter($keyword);
	foreach ($keyword as $kyw) {
		$tmp = preg_replace("/[\{\}\[\]\/?.,;:|\)*~`!^\-+<>@\#$%&\\\=\(\'\"]/i", "", $kyw);
		$keywords .= "'{$tmp}',";
	}
	$keywords = substr($keywords, 0, -1);
	$sql = "SELECT DISTINCT kyw_name FROM {$g5['keyword_table']} WHERE kyw_name IN ({$keywords})";
	$keyword_result = sql_query($sql);
	$exists_keyword = array();
	while ($kyw = sql_fetch_array($keyword_result)) {
		$exists_keyword[] = $kyw['kyw_name'];
	}
	$new_keyword = array_values(array_diff($keyword, $exists_keyword));
	foreach ($new_keyword as $kyw) {
		$sql = "INSERT INTO {$g5['keyword_table']} SET 
					kyw_name = '{$kyw}',
					kyw_ip = '{$_SERVER['REMOTE_ADDR']}',
					kyw_date = '".G5_TIME_YMD."',
					kyw_time = '".G5_TIME_HIS."',
					kyw_reg_dt = '".G5_TIME_YMDHIS."'
				";
		sql_query($sql);
	}
	$sql = "SELECT kyw_idx FROM {$g5['keyword_table']} WHERE kyw_name IN ({$keywords})";
	$kyw_cam_result = sql_query($sql);
	while ($add_kyw = sql_fetch_array($kyw_cam_result)) {
		$sql = "INSERT INTO {$g5['keyword_campaign_table']} SET kyw_idx = '{$add_kyw['kyw_idx']}', cam_idx = '{$cam_idx}', kyc_reg_dt = '".G5_TIME_YMDHIS."'";
		sql_query($sql);
	}
}

// Campaign - Term relation SNS 정보 업데이트
if ( $w == 'u' || $w=="d" ) {
	if ( sizeof($sns_channel) ) {
		for ($i=0;$i<sizeof($sns_channel);$i++) {
			// 기존 디비 삭제를 위해 배열 미리 생성
			$sns_channel_array[] = $sns_channel[$i];
			// cam_channels 정보 설정
			$cam_channels .= '^'.$sns_channel[$i].'^,';

			// term_relation 정보 업데이트 (있으면 수정, 없으면 추가)
			term_relation_update(array('tmr_db_table'=>'campaign'
											,'tmr_db_key'=>'channel'
											,'trm_idx'=>$sns_channel[$i]
											,"tmr_db_id"=>$cam_idx
											,"dup_permit"=>1
			));
		}
	}

	// 삭제(해제)된 항목들을 관련 디비 전부 제거함
	$del_where = (sizeof($sns_channel_array))? " AND trm_idx NOT IN (".implode(",",$sns_channel_array).") ":"";
	$sql = " DELETE FROM {$g5['term_relation_table']} WHERE tmr_db_id='{$cam_idx}' ".$del_where." ";
	sql_query($sql);

	// 캠페인 SNS 채널 정보 업데이트
	$sql = " UPDATE {$g5['campaign_table']} SET cam_channels = '".substr($cam_channels,0,-1)."' WHERE cam_idx='".$cam_idx."' ";
	sql_query($sql);
}

// 파일 처리1 (파일 타입이 여러개면 일련번호 붙여서 확장해 주세요.) ----------------
// 캠페인 1개만 등록할때 / 수정할때.
if ($cam_auto_make_yn == '0' || $w == 'u') {

	$fle_type1 = "campaign_img";
	for ($i=0;$i<count($_FILES[$fle_type1.'_file']['name']);$i++) {
		// 삭제인 경우
		if (${$fle_type1.'_del'}[$i] == 1) {
			
			if ($i == 4) {
				$sql = "SELECT * FROM {$g5['file_table']} WHERE fle_db_id = '{$cam_idx}' AND fle_sort = 4";
				$del_file = sql_fetch($sql);
				$file_info = pathinfo($del_file['fle_name_orig']);
				rm_rf(G5_DATA_PATH.'/campaign_img/'.$del_file['fle_db_id'].'/'.$file_info['filename']);
			}
			
			if ($cam_idx) {
				delete_jt_file(array("fle_db_table"=>"campaign", "fle_db_id"=>$cam_idx, "fle_type"=>$fle_type1, "fle_sort"=>$i, "fle_delete"=>1));
			}
			else {
				// fle_db_id를 던져서 바로 삭제할 수도 있고 $fle_db_table, $fle_db_id, $fle_token 를 던져서 삭제할 수도 있음
				delete_jt_file(array("fle_db_table"=>"campaign"
									,"fle_db_id"=>$cam_idx
									,"fle_type"=>$fle_type1
									,"fle_sort"=>$i
									,"fle_delete"=>1
				));
			}
		}
		// 파일 등록 곽진원
		if ($_FILES[$fle_type1.'_file']['name'][$i]) {
			$upfile_info = upload_jt_file(array("fle_idx"=>$fle_idx
								,"mb_id"=>$member['mb_id']
								,"fle_src_file"=>$_FILES[$fle_type1.'_file']['tmp_name'][$i]
								,"fle_orig_file"=>$_FILES[$fle_type1.'_file']['name'][$i]
								,"fle_mime_type"=>$_FILES[$fle_type1.'_file']['type'][$i]
								,"fle_content"=>$fle_content
								,"fle_path"=>'/data/campaign_img/'.$cam_idx		//<---- 저장 디렉토리
								,"fle_db_table"=>"campaign"
								,"fle_db_id"=>$cam_idx
								,"fle_type"=>$fle_type1
								,"fle_sort"=>$i
							));
		}
	}
	// 압축파일 해제(수정)
	if ($_FILES[$fle_type1.'_file']['name'][4]) {
		
		$zip_info = pathinfo($_FILES[$fle_type1.'_file']['name'][4]);
		$extract_dir = G5_DATA_PATH.'/campaign_img/'.$cam_idx.'/'.$zip_info['filename'];
		
		$archive = new PclZip(G5_DATA_PATH.'/campaign_img/'.$cam_idx.'/'.$_FILES[$fle_type1.'_file']['name'][4]);
		$archive->extract(PCLZIP_OPT_PATH, $extract_dir);
		@chmod($extract_dir, G5_DIR_PERMISSION);
		
		zip_dir($extract_dir);
	}
	
	// 태그 수정 & 입력 START ******************
	$tag_text_array = explode("#",$tag_text); // 테그입력 #으로 분할

	foreach(array_filter($tag_text_array) as $tag) {	
		$trm1 = sql_fetch(" SELECT trm_idx,trm_name FROM {$g5['term_table']} WHERE trm_taxonomy = 'campaign_tag' AND trm_name = '".trim($tag)."' ");
		$tag_split = trim($tag);
		
		// 삭제를 위해서 배열을 생성
		$trm_exist_array .= ','.$trm1['trm_idx'];
				
		if (!$trm1['trm_idx']) {	//term 없으면 입력.
			if (ISSET($tag_split)) {				
				$sql = "INSERT INTO  {$g5['term_table']} SET trm_idx_parent = '0', trm_country = 'ko_KR', trm_name = '{$tag_split}', trm_taxonomy = 'campaign_tag', trm_status = 'ok', trm_reg_dt = '".G5_TIME_YMDHIS."' ";						
				sql_query($sql);
				
				$trm_idx2 = sql_insert_id();
				
				$sql2 = " INSERT INTO  {$g5['term_relation_table']} SET trm_idx = '{$trm_idx2}', tmr_db_table = 'campaign', tmr_db_key = 'campaign_tag', tmr_db_id = '{$cam_idx}', tmr_reg_dt = '".G5_TIME_YMDHIS."' ";
				sql_query($sql2);				
			}
		}
		// term 있으면 입력.
		else {
			if (ISSET($tag_split)) {
				$trm2 = sql_fetch(" SELECT trm_idx FROM {$g5['term_relation_table']} WHERE tmr_db_key = 'campaign_tag' AND trm_idx = '{$trm1['trm_idx']}' AND tmr_db_id = '{$cam_idx}' ");
				
				if (!$trm2['trm_idx']) { 	//term_relation 없으면 입력.
					$sql3 = " INSERT INTO  {$g5['term_relation_table']} SET trm_idx = '{$trm1['trm_idx']}', tmr_db_table = 'campaign', tmr_db_key = 'campaign_tag', tmr_db_id = '{$cam_idx}', tmr_reg_dt = '".G5_TIME_YMDHIS."' ";
					sql_query($sql3);					
				}
			}
		}
	}
				
	// 기존 태그들 제거
	if (substr($trm_exist_array,1)) {
		sql_query(" DELETE FROM {$g5['term_relation_table']} 
					WHERE tmr_db_table = 'campaign' 
						AND tmr_db_key = 'campaign_tag'
						AND tmr_db_id = '".$cam_idx."'
						AND trm_idx NOT IN (".substr($trm_exist_array,1).") ");
	}
	// 태그 수정 & 입력 END ******************
	
}


//-- 필드명 추출 mb_ 와 같은 앞자리 3자 추출 --//
$r = sql_query(" desc {$g5['campaign_table']} ");
while ( $d = sql_fetch_array($r) ) {$db_fields[] = $d['Field'];}
$db_prefix = substr($db_fields[0],0,3);

//-- 체크박스 값이 안 넘어오는 현상 때문에 추가, 폼의 체크박스는 모두 배열로 선언해 주세요.
$checkbox_array=array();
for ($i=0;$i<sizeof($checkbox_array);$i++) {
	if (!$_REQUEST[$checkbox_array[$i]])
		$_REQUEST[$checkbox_array[$i]] = 0;
}

//-- 메타 입력 (디비에 있는 설정된 값은 입력하지 않는다.) --//
$db_fields[] = "mb_zip";	// 건너뛸 변수명은 배열로 추가해 준다.
$db_fields[] = "mb_sido_cd";	// 건너뛸 변수명은 배열로 추가해 준다.
foreach($_REQUEST as $key => $value ) {
	//-- 해당 테이블에 있는 필드 제외하고 테이블 prefix 로 시작하는 변수들만 업데이트 --//
	if (!in_array($key,$db_fields) && substr($key,0,3)==$db_prefix) {
		meta_update(array("mta_db_table"=>"product_order","mta_db_id"=>$cam_idx,"mta_key"=>$key,"mta_value"=>$value));
	}
}

// 이메일발송. ( $cam_mb_email=업체 , $mb_email_saler=담당자 )
// 상태값이 변경되었을때만 문자 메일 발송함.
if ( $cam['cam_status'] != $cam_status && $chklms == '1' ) {
		
	if ($cam_status == 'pending' || $cam_status == 'ing' || $cam_status == 'reject' || $cam_status == 're_pending' || $cam_status == 'ok' || $cam_status == 'cancel') {
		if ($cam_mb_email != '' || $mb_email_saler != '') {
			// 메일제목
			// 진행대기, 진행
			if ($cam_status == 'ing') {
				if ($today < $cam_recruit_start_dt ) {
					$subject = $setting['set_cam_status_pending_email_subject'];
				} else {
					$subject = $setting['set_cam_status_ing_email_subject'];
				}
			}
			// 반려
			if ($cam_status == 'reject') {
				$subject = $setting['set_cam_status_reject_email_subject'];
			}
			// 재접수
			if ($cam_status == 're_pending') {
				$subject = $setting['set_cam_status_re_pending_email_subject'];
			}
			// 완료
			if ($cam_status == 'ok') {
				$subject = $setting['set_cam_status_ok_email_subject'];
			}
			// 취소
			if ($cam_status == 'cancel') {
				$subject = $setting['set_cam_status_cancel_email_subject'];
			}
			// 등록
			if ($cam_status == 'pending') {
				// 캠페인 자동등록 할때.
				if ($cam_auto_make_yn == '1') {
					$subject = $setting['set_auto_campaign_pending_email_subject'];
					$subject = preg_replace("/{회차}/", $cam_prd_time_auto, $subject);
				} else {
					$subject = $setting['set_campaign_pending_email_subject'];					
				}
			}
			
			if ($cam_auto_make_yn != '1') {
				$subject = preg_replace("/{회차}/", $cam_prd_time, $subject);
			}
			$subject = preg_replace("/{상품명}/", $prd_name, $subject);
			$subject = preg_replace("/{캠페인번호}/", $cam_idx, $subject);
			$subject = preg_replace("/{캠페인명}/", $cam_name, $subject);
			$subject = preg_replace("/{신청모집일}/", substr($cam_recruit_start_dt,0,10), $subject);
			$subject = preg_replace("/{대표자명}/", $com_president, $subject);
			$subject = preg_replace("/{업체명}/", $com_name, $subject);
			$subject = preg_replace("/{회원아이디}/", $mb_id, $subject);
			$subject = preg_replace("/{이메일}/", $cam_mb_email, $subject);			
			$subject2 = $subject;
			
			// 메일 내용
			// 진행대기, 진행
			if ($cam_status == 'ing') {
				if ($today < $cam_recruit_start_dt ) {
					$content = $setting['set_cam_status_pending_email_content'];
					$content = preg_replace("/{DATA_READ_URL}/", '<a href="'.G5_USER_URL.'/k/campaign_form.php?w=u&cam_idx='.$cam_idx.'&pdo_idx='.$pdo_idx.'&mb_id='.$now_cam['mb_id_company'].'" style="color:white;">캠페인보기</a>', $content);
				} else {
					$content = $setting['set_cam_status_ing_email_content'];
					$content = preg_replace("/{DATA_ING_URL}/", '<a href="'.G5_USER_URL.'/k/campaign_form2.php?cam_idx='.$cam_idx.'" style="color:white;">캠페인보기</a>', $content);
				}
			}
			// 반려
			if ($cam_status == 'reject') {
				$content = $setting['set_cam_status_reject_email_content'];
				$content = preg_replace("/{사유}/", $cam_notice, $content);
				$content = preg_replace("/{DATA_READ_URL}/", '<a href="'.G5_USER_URL.'/k/campaign_form.php?w=u&cam_idx='.$cam_idx.'&pdo_idx='.$pdo_idx.'&mb_id='.$now_cam['mb_id_company'].'" style="color:white;">캠페인보기</a>', $content);
			}
			//재접수
			if ($cam_status == 're_pending') {
                $content = $setting['set_cam_status_re_pending_email_content'];
                $content = preg_replace("/{DATA_READ_URL}/", '<a href="'.G5_USER_URL.'/k/campaign_form.php?w=u&cam_idx='.$cam_idx.'&pdo_idx='.$pdo_idx.'&mb_id='.$now_cam['mb_id_company'].'" style="color:white;">캠페인보기</a>', $content);
                }
                //완료(종료)
                if ($cam_status == 'ok') {
                $content = $setting['set_cam_status_ok_email_content'];
                $content = preg_replace("/{DATA_COMPLETE_URL}/", '<a href="'.G5_USER_URL.'/k/campaign_form2.php?cam_idx='.$cam_idx.'" style="color:white;">결과보기</a>', $content);
                }
                //취소
                if ($cam_status == 'cancel') {
                $content = $setting['set_cam_status_cancel_email_content'];
                $content = preg_replace("/{DATA_READ_URL}/", '<a href="'.G5_USER_URL.'/k/campaign_form2.php?cam_idx='.$cam_idx.'" style="color:white;">결과보기</a>', $content);
                }
                //등록
                if($cam_status == 'pending'){
                    if($w == ''){
                        //자동등록 할때.
                        if($cam_auto_make_yn == '1'){
                            $content = $setting['set_auto_campaign_pending_email_content'];
                            $content = preg_replace("/{회차}/", $cam_prd_time_auto, $content);
                        }else{
                            $content = $setting['set_campaign_pending_email_content'];					
                        }
                    }
                    
                    if($w == 'u'){
                        $content = $setting['set_cam_status_pending_email_content'];
                        $content = preg_replace("/{DATA_READ_URL}/", '<a href="'.G5_USER_URL.'/k/campaign_form.php?w=u&cam_idx='.$cam_idx.'&pdo_idx='.$pdo_idx.'&mb_id='.$now_cam['mb_id_company'].'" style="color:white;">캠페인보기</a>', $content);
                    }
                }
                
                if($cam_auto_make_yn != '1'){
                    $content = preg_replace("/{회차}/", $cam_prd_time, $content);
                }
                $content = preg_replace("/{상품명}/", $prd_name, $content);
                $content = preg_replace("/{캠페인번호}/", $cam_idx, $content);
                $content = preg_replace("/{캠페인명}/", $cam_name, $content);
                $content = preg_replace("/{신청모집일}/", substr($cam_recruit_start_dt,0,10), $content);
                $content = preg_replace("/{모집종료일}/", substr($cam_recruit_end_dt,0,10), $content);
                $content = preg_replace("/{리뷰어발표일}/", substr($cam_notice_dt,0,10), $content);
                $content = preg_replace("/{대표자명}/", $com_president, $content);
                $content = preg_replace("/{업체명}/", $com_name, $content);
                $content = preg_replace("/{회원아이디}/", $mb_id, $content);
                $content = preg_replace("/{이메일}/", $cam_mb_email, $content);
                $content = preg_replace("/{담당자}/", $mb_name_saler, $content);		
                $content = preg_replace("/{HOME_URL}/", '<a href="'.G5_URL.'">'.G5_URL.'</a>', $content);
                            
                        
                //업체(고객)
                if( $cam_mb_email != '' && $cam_status != 're_pending' && strpos($subject, '{고객}') !== false ){
                    $subject = preg_replace("/{고객}/", '', $subject);
                    $subject = preg_replace("/{담당자}/", '', $subject);
                    mailer($config['cf_admin_email_name'], $config['cf_admin_email'], $cam_mb_email, $subject, $content, 1);
                    //echo '고객<br>';
                }
                //담당자(영업자)
                if( $mb_email_saler != '' && $cam_status != 're_pending' && strpos($subject2, '{담당자}') !== false ){			
                    $subject2 = preg_replace("/{담당자}/", '', $subject2);
                    $subject2 = preg_replace("/{고객}/", '', $subject2);
                    mailer($config['cf_admin_email_name'], $config['cf_admin_email'], $mb_email_saler, $subject2, $content, 2);
                    //echo '담당자';
                }
                
                //재접수 (관리자 페이지에서는 관라자만 받음. 업체 페이지 에서는 관리자,담당자 받음.)
                if($cam_status == 're_pending'){
                    $subject = preg_replace("/{관리자}/", '', $subject);
                    $subject = preg_replace("/{담당자}/", '', $subject);
                    mailer($config['cf_admin_email_name'], $config['cf_admin_email'], 'kafain2016@naver.com', $subject, $content, 2);
                }
                //echo $cam_mb_email.'<br>';
                //echo $mb_email_saler.'<br>';
            }
        }
    
    
        // 문자 발송.
        if ($cam_status == 'ing' || $cam_status == 'reject' || $cam_status == 'ok' || $cam_status == 'cancel') {		
            //자료동의 확인 핸드폰발송.
            if($com_tel != ''){
                $from_number = hyphen_hp_number($setting['set_sms_callback']);
                
                //진행대기,진행
                if ($cam_status == 'ing') {
                    if($today < $cam_recruit_start_dt ){
                        $content = $setting['set_cam_status_pending_sms_content'];
                    }else{
                        $content = $setting['set_cam_status_ing_sms_content'];
                    }
                    $content = preg_replace("/{URL}/", ''.$USER_URL.'/c/cv.php?'.$cam_idx.'', $content);
                }
                //반려
                if ($cam_status == 'reject') {
                $content = $setting['set_cam_status_reject_sms_content'];
                $content = preg_replace("/{사유}/", $cam_notice, $content);
                }
                //완료
                if ($cam_status == 'ok') {
                $content = $setting['set_cam_status_ok_sms_content'];			
                $content = preg_replace("/{URL}/", ''.$USER_URL.'/c/cv.php?'.$cam_idx.'', $content);
                }
                //취소
                if ($cam_status == 'cancel') {
                $content = $setting['set_cam_status_cancel_sms_content'];
                }
                
                //$content = preg_replace("/{신청자}/", $cam_mb_name, $content);		
                $content = preg_replace("/{회차}/", $cam_prd_time, $content);
                $content = preg_replace("/{캠페인번호}/", $cam_idx, $content);
                $content = preg_replace("/{상품명}/", $prd_name, $content);
                $content = preg_replace("/{캠페인명}/", $cam_name, $content);
                $content = preg_replace("/{신청모집일}/", substr($cam_recruit_start_dt,0,10), $content);
                $content2 = $content;
                 
            
            
                // 엔씨티 서버를 이용한 SMS 문자 발송 ( {고객} => 있을때만 발송됨. ) 
                if( strpos($content, '{고객}') !== false ){
                    $content = preg_replace("/{고객}/", '', $content);
                    $content = preg_replace("/{담당자}/", '', $content);
                    
                    lms_nct(array("to_number"=>$com_tel
                                    ,"from_number"=>$from_number
                                    ,"subject"=>$setting['set_lms_subject']
                                    ,"content"=>$content
                                    ,"file_name"=>$_SERVER['SCRIPT_NAME']
                    ));
                    
                    //echo $com_tel.'<br>';
                    //echo $from_number.'<br>';
                    //echo $content.'<br>';
                    //exit;
                }
                if( strpos($content2, '{담당자}') !== false ){
                    $content2 = preg_replace("/{고객}/", '', $content2);
                    $content2 = preg_replace("/{담당자}/", '', $content2);
                    
                    lms_nct(array("to_number"=>$mb_hp_saler
                                    ,"from_number"=>$from_number
                                    ,"subject"=>$setting['set_lms_subject']
                                    ,"content"=>$content2
                                    ,"file_name"=>$_SERVER['SCRIPT_NAME']
                    ));
                    
                    //echo $mb_hp_saler.'<br>';
                    //echo $from_number.'<br>';
                    //echo $content.'<br>';
                    //exit;
                }
                
                unset($mb_hp_saler); unset($com_tel); unset($content); unset($content2);
            }
        }
        
    }
    
    goto_url('./campaign_form.php?'.$qstr.'&amp;w=u&amp;cam_idx='.$cam_idx.'&amp;pdo_idx='.$pdo_idx.'&amp;mb_id='.$mb_id_company, false);