<?php
$sub_menu = '910210';
include_once('./_common.php');
auth_check($auth[$sub_menu], "r");

$g5['title'] = '캠페인 관리';
include_once (G5_ADMIN_PATH.'/admin.head.php');

$today = date("Y-m-d 23:59:59", mktime(00,00,00,date("m")  , date("d"), date("Y")));

//-- 카테고리 검색 조건 생성
$sql_trm_idx_cat1 = ($ser_trm_idx_cat1) ? " AND cam.trm_idx_cat1 IN (".$ser_trm_idx_cat1.") " : "";
$sql_trm_idx_cat2 = ($ser_trm_idx_cat2) ? " AND cam.trm_idx_cat2 IN (".$ser_trm_idx_cat2.") " : "";
$sql_trm_idx_cat3 = ($ser_trm_idx_cat3) ? " AND cam.trm_idx_cat3 IN (".$ser_trm_idx_cat3.") " : "";

//-- 상권 검색
$sql_trm_idx_salesarea = ($ser_trm_idx_salesarea) ? " AND cam.trm_idx_salesarea IN (".$ser_trm_idx_salesarea.") " : "";


//-- SNS 채널 INNER JOIN 추가 (FROM 절에 추가!) / u.project.php에 변수 있음 $g5['channel_name'][$key]...
if( $sns_trm_idxs ) {	// 이전에 넘어온 변수가 있으면 (수정이나 삭제 갔다 온 경우!)
	$sns_array = explode(",",substr($sns_trm_idxs,1));
	// 체크 박스 체크를 위해서 설정해야 함
	for($i=0;$i<sizeof($sns_array);$i++) {
		$sns[$sns_array[$i]] = $sns_array[$i];
	}
}
unset($sns_trm_idxs);	// 하단 .= 로 연결되므로 먼저 초기화!
foreach ($g5['sns_channel_search'] as $key => $value) {
    //echo "\$a[$key] => $value / ";
	if($sns[$key]) {	// checkbox checked로 넘어온 경우
		$sns_trm_idxs .= ",".$key;	// SNS 검색 조건절 생성
		$sql_cam_channels .= '^'.$key.'^,';
		${'sns_checked_'.$key} = ' checked';
	}
	$cam_sns_checkboxs .= '<label for="sns_'.$key.'" class="sns_channel">
								<input type="checkbox" id="sns_'.$key.'" name="sns['.$key.']" value="'.$key.'" '.${'sns_checked_'.$key}.'>
								<img src="'.G5_THEME_IMG_URL.'/sns_channel_'.$key.'.png" title="'.$value.'"  style="width:18px;"/>
							  </label>';
}

if( substr($sns_trm_idxs,1) ){
	$sql_sns = "  AND cam_channels = '".substr($sql_cam_channels,0,-1)."' ";
}

//****** cam_status 검색 S ******
//체크박스로 검색
if($cam_status) {
    for($i=0; $i<count($cam_status); $i++){	
        $cam_status_make .= "'".$cam_status[$i]."',";
    }
}

//진행대기 sql문입력할 변수 만들기.
$cam_status_make2 = str_replace("'ing2',","", $cam_status_make);
$cam_status_make3 = ','.$cam_status_make2;
$cam_status_make3 = substr($cam_status_make3,0,-1);

//print_r2($cam_status_make);
//echo '111'.strpos($cam_status_make, "'ing',").'<br>';
//echo '222'.strpos($cam_status_make, "'ing2',").'<br>';
if($cam_status_make != ''){
	if( strpos($cam_status_make, "'ing',") !== false && strpos($cam_status_make, "'ing2',") === false  ){
		$sql_status = "  AND cam_status IN (".substr($cam_status_make,0,-1).") AND '{$today}' > cam_recruit_start_dt ";
	}else if ( strpos($cam_status_make, "'ing',") === false && strpos($cam_status_make, "'ing2',") !== false ){
		$sql_status = "  AND cam_status IN ('ing'".$cam_status_make3.") AND '{$today}' < cam_recruit_start_dt ";
	}else{
		$sql_status = "  AND cam_status IN (".substr($cam_status_make,0,-1).") ";
	}

	//페이징으로 검색 변수 만들기.
	$cam_status_make_url = str_replace("'","",$cam_status_make);
}

//페이징으로 검색
if($page != '' && $cam_status_make_url ){
	$cam_status = explode(",", substr($cam_status_make_url,0,-1));

	for($i=0; $i<count($cam_status); $i++){
		$cam_status_make2 .= "'".$cam_status[$i]."',";
	}

	$cam_status_make2_1 = str_replace("'ing2',","", $cam_status_make2);
	$cam_status_make3_1 = ','.$cam_status_make2_1;
	$cam_status_make3_1 = substr($cam_status_make3_1,0,-1);
	
	//echo strpos($cam_status_make2, "ing").' :진행중<br>';
	//echo strpos($cam_status_make2, "ing2").' :진행대기<br>';	
	if( strpos($cam_status_make2, "'ing',") !== false && strpos($cam_status_make2, "'ing2',") === false  ){		
		$sql_status = "  AND cam_status IN (".substr($cam_status_make2,0,-1).") AND '{$today}' > cam_recruit_start_dt ";	
	}else if ( strpos($cam_status_make2, "'ing',") === false && strpos($cam_status_make2, "'ing2',") !== false ){		
		$sql_status = "  AND cam_status IN ('ing'".$cam_status_make3_1.") AND '{$today}' < cam_recruit_start_dt ";		
	}else{		
		$sql_status = "  AND cam_status IN (".substr($cam_status_make2,0,-1).") ";		
	}
}
//****** cam_status 검색 E ******


// FROM 절 생성
$sql_common = " FROM {$g5['campaign_table']} AS cam 
					LEFT JOIN {$g5['company_table']} AS com ON com.com_idx = cam.com_idx 
					{$sql_join}
				";

// 기본 검색 조건
$sql_search = " WHERE (1) AND cam_status != 'trash' ".$sql_trm_idx_cat1." ".$sql_trm_idx_cat2." ".$sql_trm_idx_cat3." ".$sql_trm_idx_salesarea;

//날짜 검색 조건 설정
if ($st_date && $sfl_date)	// 시작일 있는 경우
	$sql_search .= " AND {$sfl_date} >= '{$st_date} 00:00:00' ";
if ($en_date && $sfl_date)	// 종료일 있는 경우
	$sql_search .= " AND {$sfl_date} <= '{$en_date} 23:59:59' ";

//날짜 검색 조건 설정2
if ($st_date2 && $sfl_date2)	// 시작일 있는 경우
	$sql_search .= " AND {$sfl_date2} >= '{$st_date2} 00:00:00' ";
if ($en_date2 && $sfl_date2)	// 종료일 있는 경우
	$sql_search .= " AND {$sfl_date2} <= '{$en_date2} 23:59:59' ";

//항목선택
if ($stx && !preg_match("/mem_s\./", $sfl) && !preg_match("/mem_c\./", $sfl) ) {    
    switch ($sfl) {
		case ($sfl == 'cam_status1') : //진행대기
            $sql_search .= "AND ( cam_status IN ('{$stx}') AND '{$today}' < cam_recruit_start_dt )";
            break;
		case ($sfl == 'cam_status2') : //진행중
            $sql_search .= "AND ( cam_status IN ('{$stx}') AND '{$today}' > cam_recruit_start_dt )";
            break;
		case ( $sfl == 'cam.com_idx' or $sfl == 'cam.pdo_idx' or $sfl == 'cam_status') :
            $sql_search .= "AND ( {$sfl} = '{$stx}' )";
            break;
		case ( $sfl == 'com_name' or $sfl == 'com_tel') :
            $sql_search .= "AND ( {$sfl} LIKE '%{$stx}%' )";
            break;
		case ( $sfl == 'cam_idx') :
            $sql_search .= "AND ( {$sfl} = '{$stx}' )";
            break;
        default :
            $sql_search .= "AND ( {$sfl} LIKE '%{$stx}%' )";
            break;
    }
}

$sql_search .= ($cam_nct == '1')? "AND ( cam_nct = '{$cam_nct}') " : "";


// 조인은 속도가 WHERE 절에 회원명으로 검색.
if( $stx && preg_match("/mem_s\./", $sfl ) ) {
	switch ($sfl) {
		case 'mem_s.mb_hp' :
			$stx = hyphen_hp_number($stx);
			$sql_member .= " ({$sfl} LIKE '%{$stx}%') ";
			break;
		default :
			$sql_member .= " ({$sfl} LIKE '{$stx}%') ";
			break;
	}
	
	$sql_mem = sql_fetch(" SELECT GROUP_CONCAT( CONCAT('\'',mb_id,'\'') ) AS saler_mb_ids FROM {$g5['member_table']} AS mem_s WHERE {$sql_member} ",1);
	
	if(!$sql_mem['saler_mb_ids']) $sql_mem['saler_mb_ids'] = "'-'";
	$sql_search_com = " AND mb_id_saler IN (".$sql_mem['saler_mb_ids'].") ";
}

if( $stx && preg_match("/mem_c\./", $sfl) ) {
	switch ($sfl) {		
		default :
			$sql_member .= " ({$sfl} LIKE '{$stx}%') ";
			break;
	}
	
	$sql_mem = sql_fetch(" SELECT GROUP_CONCAT( CONCAT('\'',mb_id,'\'') ) AS company_mb_ids FROM {$g5['member_table']} AS mem_c WHERE {$sql_member} ",1);
	
	if(!$sql_mem['company_mb_ids']) $sql_mem['company_mb_ids'] = "'-'";
	$sql_search_com = " AND mb_id_company IN (".$sql_mem['company_mb_ids'].") ";
}

if( strlen($sql_mem['saler_mb_ids']) >= 1024 || strlen($sql_mem['company_mb_ids']) >= 1024 ) {
	alert('검색된 업체수가 너무 많습니다. 검색어를 다시 지정해 주세요.');
}

if( $type ){
	$sql_type = " AND cam_type = '".$type."' ";
}

if (!$sst) {
    $sst = $sst?$sst:"cam_idx_parent";
    $sod = "DESC";
}
$sql_order = " ORDER BY {$sst} {$sod}, cam_prd_time, cam_prd_retime ";

$rows = $config['cf_page_rows'];
if (!$page) $page = 1; // 페이지가 없으면 첫 페이지 (1 페이지)
$from_record = ($page - 1) * $rows; // 시작 열을 구함

$sql  = " SELECT SQL_CALC_FOUND_ROWS *
			,(SELECT CONCAT( 'prd_idx=', CAST(prd_idx AS CHAR), ',pdo_pay_status=', CAST(pdo_pay_status AS CHAR) ) FROM {$g5['product_order_table']} WHERE pdo_idx = cam.pdo_idx ) AS pdo_info
			,(SELECT CONCAT( 'cma_idx_count=', CAST(count(cam_idx) AS CHAR), ',cma_idx_chosen_count=', CAST(sum( CASE WHEN cma_status = 'chosen' THEN 1 ELSE 0 END ) AS CHAR)) 
				FROM {$g5['campaign_apply_table']} 
				WHERE cam_idx = cam.cam_idx AND cma_status NOT IN ('trash') ) AS cma_info
			,(SELECT CONCAT( 'rev_idx_count=', CAST(count(rev_idx) AS CHAR), ',rev_idx_best_count=', CAST(sum( CASE WHEN rev_best_dt != '0000-00-00 00:00:00' THEN 1 ELSE 0 END ) AS CHAR))
				FROM {$g5['review_table']} 
				WHERE cam_idx = cam.cam_idx AND rev_status NOT IN ('hide','trash') ) AS rev_info
			,( SELECT GROUP_CONCAT( CAST(trm_idx AS CHAR) ORDER BY tmr_sort) FROM {$g5['term_relation_table']} 
				WHERE tmr_db_table = 'campaign' AND tmr_db_key = 'channel' AND tmr_db_id = cam.cam_idx ) AS cam_channels
			,(SELECT CONCAT( 'mb_info_level=', CAST(mb_level AS CHAR), ',mb_info_id=', mb_id, ',mb_info_name=', mb_name ) 
				FROM {$g5['member_table']} WHERE mb_id = cam.mb_id_info ) AS mb_info
			,( SELECT GROUP_CONCAT(CONCAT(mta_key, '=', COALESCE(mta_value, 'NULL'))) FROM {$g5['meta_table']} 
				WHERE mta_db_table = 'member/4' AND mta_db_id = cam.mb_id_company ) AS mb_metas
			{$sql_common}
			{$sql_search}
			{$sql_type}
			{$sql_search_com}
			{$sql_sns}
			{$sql_status}
			{$sql_order} 
		LIMIT {$from_record}, {$rows} 
		";
$result = sql_query($sql,1);
//echo $sql;

$count = sql_fetch_array( sql_query(" SELECT FOUND_ROWS() as total ") ); 
$total_count = $count['total'];
$total_page  = ceil($total_count / $rows);  // 전체 페이지 계산

// 대기 건수 추출
$pen = sql_fetch(" SELECT count(cam_idx) AS cnt FROM {$g5['campaign_table']} WHERE cam_status IN ('pending') ");
//echo $pen['pending_count'];

// 진행대기중 건수 추출
$ing_pending = sql_fetch(" SELECT count(cam_idx) AS cnt FROM {$g5['campaign_table']} WHERE cam_status IN ('ing') AND '{$today}' < cam_recruit_start_dt ");

// 진행중 건수 추출
$ing = sql_fetch(" SELECT count(cam_idx) AS cnt FROM {$g5['campaign_table']} WHERE cam_status IN ('ing') AND '{$today}' > cam_recruit_start_dt ");

// 완료 건수 추출
$ok = sql_fetch(" SELECT count(cam_idx) AS cnt FROM {$g5['campaign_table']} WHERE cam_status IN ('ok') ");

// 취소 건수 추출
$cancel = sql_fetch(" SELECT count(cam_idx) AS cnt FROM {$g5['campaign_table']} WHERE cam_status IN ('cancel') ");

// 넘겨줄 변수가 많아서 qstr 별도 설정 ser_trm_idx_cat1
$qstr = $qstr."&amp;sfl_date=$sfl_date&amp;st_date=$st_date&amp;en_date=$en_date"
	."&amp;sfl_date2=$sfl_date2&amp;st_date2=$st_date2&amp;en_date2=$en_date2"
	."&amp;ser_trm_cat1=$ser_trm_cat1&amp;ser_trm_cat2=$ser_trm_cat2&amp;ser_trm_cat3=$ser_trm_cat3"
	."&amp;ser_trm_salesarea=$ser_trm_salesarea&amp;ser_trm_idx_cat1=$ser_trm_idx_cat1&amp;ser_trm_idx_cat2=$ser_trm_idx_cat2&amp;ser_trm_idx_cat3=$ser_trm_idx_cat3"
	."&amp;sns_trm_idxs=$sns_trm_idxs&amp;ser_trm_idx_salesarea=$ser_trm_idx_salesarea"
	."&amp;cam_status_make_url=$cam_status_make_url&amp;type=$type&amp;cam_nct=$cam_nct";
//echo $qstr;

$listall = '<a href="'.$_SERVER['SCRIPT_NAME'].'" class="ov_listall">전체목록</a>';

// add_stylesheet('css 구문', 출력순서); 숫자가 작을 수록 먼저 출력됨
if(is_file(G5_USER_PATH.'/css/campaign.css'))
	add_stylesheet('<link rel="stylesheet" href="'.G5_USER_URL.'/css/campaign.css">', 1);
?>

<div class="local_ov01 local_ov">
    <span>
		<?php echo $listall; ?>  
		총 <?php echo number_format($total_count); ?>개
		<!--
		/ <a href="?sfl=cam_status&stx=pending" class="">대기중: <?//=number_format($pen['cnt'])?>건</a>	
		/ <a href="?sfl=cam_status1&stx=ing" class="">진행대기 : <?//=number_format($ing_pending['cnt'])?>건</a>	
		/ <a href="?sfl=cam_status2&stx=ing" class="">진행중: <?//=number_format($ing['cnt'])?>건</a>	
		/ <a href="?sfl=cam_status&stx=ok" class="">완료: <?//=number_format($ok['cnt'])?>건</a>	
		/ <a href="?sfl=cam_status&stx=cancel" class="">취소: <?//=number_format($cancel['cnt'])?>건</a>	
		-->
	</span>
	<a href="./campaign_form.php" class="global_btn" style="float:right;margin-top:-5px;">캠페인등록</a>
	<!--<a href="<?//=G5_URL?>/_u/m/campaign_list.php?device=mobile&cam_ok=ok" target="_blank" style="float:right; background: #395294; color: #fff; width: 100px; text-align: center; line-height: 25px; border-radius: 3px; margin-top: -5px; margin-right: 5px;">리스트 미리보기</a>-->
	<a href="<?=G5_URL?>/_u/k/shop_list.php?list_order=recommend&list_before=ok" target="_blank" style="float:right; background: #395294; color: #fff; width: 100px; text-align: center; line-height: 25px; border-radius: 3px; margin-top: -5px; margin-right: 5px;">리스트 미리보기</a>
</div>

<!--검색부분-->
<form id="fsearch" name="fsearch" class="local_sch01 local_sch" method="get">
	<table>
		<tr class="cp_m_w">
			<td class="cp_value" >
				<div class="cp_find1" style="margin-bottom:5px;">
					<select name="ser_trm_idx_cat1" id="ser_trm_idx_cat1" class="cp_field" style="width:140px;">
						<option value=''>
                             전체</option>
						<?=$category_select_options?>
					</select>
					<script>$('select[name=ser_trm_idx_cat1]').val('<?=$ser_trm_idx_cat1?>').attr('selected','selected');</script>
					
					<select name="ser_trm_idx_cat2" id="ser_trm_idx_cat2" class="cp_field" style="width:140px;">
						<option value=''>카테고리2 전체</option>
						<?=$category_select_options?>
					</select>
					<script>$('select[name=ser_trm_idx_cat2]').val('<?=$ser_trm_idx_cat2?>').attr('selected','selected');</script>
					
					<select name="ser_trm_idx_cat3" id="ser_trm_idx_cat3" class="cp_field" style="width:140px;">
						<option value=''>카테고리3 전체</option>
						<?=$category_select_options?>
					</select>
					<script>$('select[name=ser_trm_idx_cat3]').val('<?=$ser_trm_idx_cat3?>').attr('selected','selected');</script>

					&nbsp;&nbsp; <b>SNS채널:</b><?=$cam_sns_checkboxs?>
					
		            &nbsp;&nbsp;<b>상태:</b>
					<label for="cam_status1" >
						<input type="checkbox" name="cam_status[]" value="pending" id="cam_status1" <?php if(isset($cam_status)){ echo in_array("pending",$cam_status) ? 'checked' : '';} ?> >접수중&nbsp;
					</label>
					<label for="cam_status2" >
						<input type="checkbox" name="cam_status[]" value="reject" id="cam_status2" <?php if(isset($cam_status)){ echo in_array("reject",$cam_status) ? 'checked' : '';} ?> >반려&nbsp;
					</label>
					<label for="cam_status3" >	
						<input type="checkbox" name="cam_status[]" value="re_pending" id="cam_status3" <?php if(isset($cam_status)){ echo in_array("re_pending",$cam_status) ? 'checked' : '';} ?> >재접수&nbsp;
					</label>
					<label for="cam_status4_1" >
						<input type="checkbox" name="cam_status[]" value="ing2" id="cam_status4_1" <?php if(isset($cam_status)){ echo in_array("ing2",$cam_status) ? 'checked' : '';} ?> >진행대기&nbsp;
					</label>
					<label for="cam_status4" >
						<input type="checkbox" name="cam_status[]" value="ing" id="cam_status4" <?php if(isset($cam_status)){ echo in_array("ing",$cam_status) ? 'checked' : '';} ?> >진행중&nbsp;
					</label>
					<label for="cam_status5" >
						<input type="checkbox" name="cam_status[]" value="ok" id="cam_status5" <?php if(isset($cam_status)){ echo in_array("ok",$cam_status) ? 'checked' : '';} ?> >승인&nbsp;
					</label>
					<label for="cam_status6" >
						<input type="checkbox" name="cam_status[]" value="cancel" id="cam_status6" <?php if(isset($cam_status)){ echo in_array("cancel",$cam_status) ? 'checked' : '';} ?> >취소&nbsp;
					</label>
					<label for="cam_status7" >
						<input type="checkbox" name="cam_status[]" value="trash" id="cam_status7" <?php if(isset($cam_status)){ echo in_array("trash",$cam_status) ? 'checked' : '';} ?> >삭제
					</label>
					<label for="cam_nct" >
						<input type="checkbox" name="cam_nct" value="1" id="cam_nct" <?php echo ($cam_nct == '1') ? 'checked' : ''; ?> >사내캠페인
					</label>
				</div>

				<select name="ser_trm_idx_salesarea" id="ser_trm_idx_salesarea" class="cp_field" style="width:170px;">
					<option value="">상권전체</option>
					<?=$salesarea_select_options?>
				</select>
				<script>$('select[name=ser_trm_idx_salesarea]').val('<?=$ser_trm_idx_salesarea?>').attr('selected','selected');</script>

				<!--날짜검색-->
				<label for="sfl_date" class="sound_only">날짜검색</label>
				<select name="sfl_date" id="sfl_date" style="width:120px;">
					<option value=''>날짜 항목 선택</option>
					<option value="cam_reg_dt"<?php echo get_selected($_GET['sfl_date'], "cam_reg_dt"); ?>>등록일</option>
					<option value="cam_info_reg_dt"<?php echo get_selected($_GET['sfl_date'], "cam_info_reg_dt"); ?>>접수일</option>
					<option value="cam_recruit_start_dt"<?php echo get_selected($_GET['sfl_date'], "cam_recruit_start_dt"); ?>>리뷰어모집시작일</option>
					<option value="cam_recruit_end_dt"<?php echo get_selected($_GET['sfl_date'], "cam_recruit_end_dt"); ?>>리뷰어모집종료일</option>
					<option value="cam_notice_dt"<?php echo get_selected($_GET['sfl_date'], "cam_notice_dt"); ?>>리뷰어발표일</option>
					<option value="cam_review_start_dt"<?php echo get_selected($_GET['sfl_date'], "cam_review_start_dt"); ?>>리뷰어등록시작일</option>
					<option value="cam_review_end_dt"<?php echo get_selected($_GET['sfl_date'], "cam_review_end_dt"); ?>>리뷰어등록종료일</option>
					<option value="cam_best_select_dt"<?php echo get_selected($_GET['sfl_date'], "cam_best_select_dt"); ?>>베스트발표일</option>
				</select>	
				<input type="text" name="st_date" value="<?php echo $st_date ?>" id="st_date" class="frm_input" style="width:70px;"> ~
				<input type="text" name="en_date" value="<?php echo $en_date ?>" id="en_date" class="frm_input" style="width:70px;">
				<select name="sfl_date2" id="sfl_date2" style="width:120px;">
					<option value=''>날짜 항목 선택</option>
					<option value="cam_reg_dt"<?php echo get_selected($_GET['sfl_date2'], "cam_reg_dt"); ?>>등록일</option>
					<option value="cam_info_reg_dt"<?php echo get_selected($_GET['sfl_date2'], "cam_info_reg_dt"); ?>>접수일</option>
					<option value="cam_recruit_start_dt"<?php echo get_selected($_GET['sfl_date2'], "cam_recruit_start_dt"); ?>>리뷰어모집시작일</option>
					<option value="cam_recruit_end_dt"<?php echo get_selected($_GET['sfl_date2'], "cam_recruit_end_dt"); ?>>리뷰어모집종료일</option>
					<option value="cam_notice_dt"<?php echo get_selected($_GET['sfl_date2'], "cam_notice_dt"); ?>>리뷰어발표일</option>
					<option value="cam_review_start_dt"<?php echo get_selected($_GET['sfl_date2'], "cam_review_start_dt"); ?>>리뷰어등록시작일</option>
					<option value="cam_review_end_dt"<?php echo get_selected($_GET['sfl_date2'], "cam_review_end_dt"); ?>>리뷰어등록종료일</option>
					<option value="cam_best_select_dt"<?php echo get_selected($_GET['sfl_date2'], "cam_best_select_dt"); ?>>베스트발표일</option>
				</select>	
				<input type="text" name="st_date2" value="<?php echo $st_date2 ?>" id="st_date2" class="frm_input" style="width:70px;"> ~
				<input type="text" name="en_date2" value="<?php echo $en_date2 ?>" id="en_date2" class="frm_input" style="width:70px;">
				
				<select name="sfl" id="sfl" style="width:110px;">
					<option value=''>검색 항목 선택</option>
					<option value="cam_idx"<?php echo get_selected($_GET['sfl'], "cam_idx"); ?>>캠페인번호</option>
					<option value="cam_name"<?php echo get_selected($_GET['sfl'], "cam_name"); ?>>캠페인명</option>					
					<option value="com_name"<?php echo get_selected($_GET['sfl'], "com_name"); ?>>업체명</option>
					<option value="com_president"<?php echo get_selected($_GET['sfl'], "com_president"); ?>>대표자명</option>
					<option value="com_tel"<?php echo get_selected($_GET['sfl'], "com_tel"); ?>>대표전화</option>										
					<option value="cam_mb_saler"<?php echo get_selected($_GET['sfl'], "cam_mb_saler"); ?>>담당자명</option>
					<option value="mem_s.mb_hp"<?php echo get_selected($_GET['sfl'], "mem_s.mb_hp"); ?>>담당자HP</option>
					<option value="mem_s.mb_email"<?php echo get_selected($_GET['sfl'], "mem_s.mb_email"); ?>>담당자메일</option>
										
					<option value="mem_c.mb_id"<?php echo get_selected($_GET['sfl'], "mem_c.mb_id"); ?>>업체회원ID</option>
					<option value="mem_c.mb_name"<?php echo get_selected($_GET['sfl'], "mem_c.mb_name"); ?>>업체회원명</option>
					<option value="mem_c.mb_email"<?php echo get_selected($_GET['sfl'], "mem_c.mb_email"); ?>>업체회원메일</option>
					<option value="cam.com_idx"<?php echo get_selected($_GET['sfl'], "cam.com_idx"); ?>>업체고유번호</option>
					
					<option value="cam_mb_name"<?php echo get_selected($_GET['sfl'], "cam_mb_name"); ?>>신청자</option>
					<option value="cam.pdo_idx"<?php echo get_selected($_GET['sfl'], "cam.pdo_idx"); ?>>신청번호</option>
					<option value="mb_id_info"<?php echo get_selected($_GET['sfl'], "mb_id_info"); ?>>정보등록자ID</option>
															
					<option value="com_manager"<?php echo get_selected($_GET['sfl'], "com_manager"); ?>>업체담당자명</option>
					<option value="cam_prd_name"<?php echo get_selected($_GET['sfl'], "cam_prd_name"); ?>>상품명</option>					
					<option value="cam_mb_tel"<?php echo get_selected($_GET['sfl'], "cam_mb_tel"); ?>>신청인 연락처</option>
					<option value="cam_mb_email"<?php echo get_selected($_GET['sfl'], "cam_mb_email"); ?>>신청인 이메일</option>
					<!--
					<option value="cam_status"<?php// echo get_selected($_GET['sfl'], "cam_status"); ?>>캠페인상태</option>
					-->
				</select>
				<input type="text" name="stx" value="<?php echo $stx ?>" id="stx" class="frm_input">
				<select name="type" id="type" style="width:70px;">
					<option value=''>타입</option>
					<option value="visite"<?php echo get_selected($_GET['type'], "visite"); ?>>방문형</option>
					<option value="delivery"<?php echo get_selected($_GET['type'], "delivery"); ?>>배송형</option>
					<option value="PressCorps"<?php echo get_selected($_GET['type'], "PressCorps"); ?>>기자단</option>					
				</select>
				<input type="submit" value="검색" class="cp_submit" id="cp_submit">
				
			</td>
		</tr>
	</table>
</form>

<form style="margin-top: 10px;" name="fsearch" action="" method="post">
<div class="tbl_head02 tbl_wrap">
	<table>    
	<thead>
	<tr>
		<th scope="col" style="width:6%;"><?php echo subject_sort_link("cam_sort", $qstr, 1); ?>정렬</a></th>
		<th scope="col" style="" colspan="1">캠페인/업체</th>
		<th scope="col" style="width:15%;">등록/자료접수</th>
		<th scope="col" style="width:16%;">리뷰어 모집/발표/선정</th>
		<th scope="col" style="width:15%;">리뷰 등록</th>
		<th scope="col" style="width:12%;"><?php echo subject_sort_link("cam_best_select_dt", $qstr, 1); ?>Best 발표</a></th>
		<th scope="col" style="width:5%;" colspan="1">관리</th>		
	</tr>
	</thead>
	<tbody class="tbl_body">
	<?php
	for ($i=0; $row=sql_fetch_array($result); $i++)
	{
		// 상품 주문 정보
		$pieces = explode(',', $row['pdo_info']);
		foreach ($pieces as $piece) {
			list($key, $value) = explode('=', $piece);
			$row[$key] = $value;
		}

		// 캠페인 신청 카운터 정보 분리
		$pieces = explode(',', $row['cma_info']);
		foreach ($pieces as $piece) {
			list($key, $value) = explode('=', $piece);
			$row[$key] = $value;
        }
        /*$pieces = explode(',', $row['cam_nct_cnt']);
		foreach ($pieces as $piece) {
			list($key, $value) = explode('=', $piece);
			$row[$key] = $value;
        }*/
     
        // print_r2($pieces);
		// 리뷰 카운터 정보 분리
		$pieces = explode(',', $row['rev_info']);
		foreach ($pieces as $piece) {
			list($key, $value) = explode('=', $piece);
			$row[$key] = $value;
		}    
		// 회원(신청회원)메타 분리
		$pieces = explode(',', $row['mb_metas']);
		foreach ($pieces as $piece) {
			list($key, $value) = explode('=', $piece);
			$row[$key] = $value;
		}

		// 접수 등록자
		$pieces = explode(',', $row['mb_info']);
		foreach ($pieces as $piece) {
			list($key, $value) = explode('=', $piece);
			$row[$key] = $value;
		}
		
		// 상품결제상태
		$row['pdo_pay_status_text'] = ($row['pdo_pay_status'] != 'payall') ? 
										'<span style="color:darkorange;">'.$g5['set_pdo_pay_status_value'][$row['pdo_pay_status']].'</span>'
											:$g5['set_pdo_pay_status_value'][$row['pdo_pay_status']];;
		
		// 자료사용동의
		$row['com_data_agree_dt_text'] = ($row['com_data_agree_dt'] && $row['com_data_agree_dt'] != '0000-00-00 00:00:00') ? substr($row['com_data_agree_dt'],2,8):'동의전';

		// 수정 및 삭제 버튼
		//if($row['cam_status'] == 'pending')
		$s_mod = '<a href="./campaign_form.php?device=pc&amp;'.$qstr.'&amp;w=u&amp;cam_idx='.$row['cam_idx'].'&pdo_idx='.$row['pdo_idx'].'&mb_id='.$row['mb_id'].' ">수정</a>';
	
		// tr 색상 표현
		$row['cam_status_class']	= " tr_".$row['cam_status'];

		$bg = 'bg'.($i%2); //css 색상 구문 class값
		
		//다시회차구분하는 bg.
		if($row['cam_prd_retime'] != '0' ){
			$row['cam_prd_retime_style'] = 'style="background: #feffd0;"';
		}
		
		//사내회원 리뷰신청 카운트 추출하기 (일반 루트로 리뷰등록한 lv6 회원하고 사내캠으로 등록한 lv6하고 구분해야함). 
		$nct_rev = sql_fetch( "	SELECT count(rev_idx) AS cnt FROM {$g5['review_table']} AS rev
									LEFT JOIN {$g5['member_table']} AS mem ON mem.mb_id = rev.mb_id
									LEFT JOIN {$g5['campaign_apply_table']} AS cma ON cma.cma_idx = rev.cma_idx
								WHERE rev.cam_idx = '{$row['cam_idx']}' AND rev.rev_status = 'ok' AND mem.mb_level = '6' AND isnull(cma.cma_status)" );	
	?>	
	<tr class="<?php echo $bg; ?> <?=$row['cam_status_class']?>" <?=$row['cam_prd_retime_style']?>>
		<td style="vertical-align: middle;">
			<?php
			if($row['cam_prd_retime'] != '0' ){
				echo '<div style="padding: 2px 0px"><img src="'.G5_THEME_IMG_URL.'/next.png"  style="width:26px" /></div>';
			}
			?>
			<div style='margin-bottom:3px;'><?=$row['cam_sort']?></div>
			<a href="<?=G5_URL?>/_u/m/campaign_view.php?device=mobile&cam_idx=<?=$row['cam_idx']?>" target="_blank" style="background: #3b5998;color:#fff;padding: 2px 2px;border-radius: 3px;}">미리보기</a>
		</td>
		<td class="td_company">
			<b>[ <?=$row['cam_idx']?> ]  <?=cut_str($row['cam_name'],30)?></b>
			<?php
			//오늘
			$today = date("Y-m-d 23:59:59", mktime(00,00,00,date("m")  , date("d"), date("Y"))); 
			//캄페인 상태값.
			if($row['cam_status'] == 'ing'){
				if( $today > $row['cam_recruit_start_dt']){
					echo "(<span style='color:dodgerblue'>".$g5['set_cam_status'][$row['cam_status']]."</span>)";
				}
				else{
					echo '(<span style="color:dodgerblue">진행대기</span>)';
				}
			}
			else{
				echo "(<span style='color:dodgerblue'>".$g5['set_cam_status'][$row['cam_status']]."</span>)";
			}
			
			//사내캠페인 표현.
			/*if( $row['cam_nct_only'] == '1'|| $row['cam_nct'] == '1' ){
				echo '<div class="cam_nct_on">사캠 : '.$row['cam_nct_cnt'].' </div>';
            }*/
             
            /*if($row['cam_reviewer_yn'] == '1') {
                // echo '모집:'.$row['cam_recruit_count'].'명'; 
                if($row['cam_recruit_count'])
                echo '<div class="cam_nct_on">남은인원:',$row['cam_recruit_count']-$row['cma_idx_count'],'명</div>';  
            }*/
            /*if($row['cam_reviewer_yn'] == '1') {	// 모집 일자 표현
				
				echo '모집:'.$row['cam_recruit_count'].'명';  
				
				if(!$row['cma_idx_count'])
					echo '<span style="color:darkgray">신청자 없음</span>';
				else {
					echo '<a href="./campaign_apply_list.php?sfl=cma.cam_idx&stx='.$row['cam_idx'].'" target="_blank">';
					echo '신청:<b>'.$row['cma_idx_count'].'</b>';
					echo '</a>';
				}
				
			}
			else {
				echo '<span style="color:darkgray">비모집: 누구나 참여가능</span>';
			}*/
			
			// print_r2($row['cam_reviewer_yn']);
			?>
			
			<br>
			<b>상품</b>:
				<a href="./product_order_form.php?w=u&pdo_idx=<?=$row['pdo_idx']?>" target="_blank"><?=$product_name[$row['prd_idx']];?> (<?=$row['pdo_pay_status_text']?>)</a>
				-  
				<?php
				if( $row['cam_prd_retime'] == '0'){
					echo '<a href="./campaign_list.php?sfl=cam.pdo_idx&stx='.$row['pdo_idx'].'"><b>'.$row['cam_prd_time'].'</b>/'.$product_times[$row['prd_idx']].'회</a>';
				}else{
					echo '<a href="./campaign_list.php?sfl=cam.pdo_idx&stx='.$row['pdo_idx'].'"><b>'.$row['cam_prd_time'].'-'.$row['cam_prd_retime'].'</b>/'.$product_times[$row['prd_idx']].'회</a>';
				}
				?>
			<br>
			<b>업체명</b>:<a href="./company_form.php?w=u&com_idx=<?=$row['com_idx']?>" target="_blank"><?=$row['com_name'];?></a>
				<span>(<b>담당자</b>:<?=$row['cam_mb_saler'];?>)</span>
				<br>
			자료사용동의: <span style="color:darkgray"><?=$row['com_data_agree_dt_text']?></span>
			
			<!-- 결과 보고서 -->
			<?php
			if( $row['rev_idx_count'] ){
				echo  '<a href="./report_list.php?cam_idx='.$row['cam_idx'].'" target="_blank"> <div class="cam_report"><i class="fa fa-file-text-o" aria-hidden="true"></i> 결과보고서</div> </a>';
			}
			?>
			
			<!--
			<br>
			회원ID: <?//=$row['mb_info_id'];?> / 회원명: <?//=$row['mb_info_name'];?>
			-->
		</td>
		<td class="td_reg_dt_info_reg_dt">
			<input type="hidden" name="it_id[<?php echo $i; ?>]" value="<?php echo $cam_reg_dt; ?>">
			캠페인등록일 : <span style="color:darkgray"><?=substr($row['cam_reg_dt'],2,8)?></span>
			<br>		
			접수 <?= $row['mb_info_id'] == 'super' ?'' : '(<span style="color:darkgray">'.$g5['set_mb_level_value'][$row['mb_info_level']].'</span>)';?> : <?=cut_str($row['mb_info_name'],9,'..')?>
			<br>
			접수일 : <?=($row['cam_info_reg_dt']!='0000-00-00 00:00:00')?substr($row['cam_info_reg_dt'],2,8):'-';?>
		</td>
		<td>
			<?php 
			// 리뷰어 모집 형태(0:비모집, 1:모집)
			if($row['cam_reviewer_yn'] == '1') {	// 모집 일자 표현
				echo '기간:';
				echo ($row['cam_recruit_start_dt']=='0000-00-00 00:00:00') ? '<span style="color:lightgray">'.substr($row['cam_recruit_start_dt'],2,8).'</span>':substr($row['cam_recruit_start_dt'],2,8);
				echo '~';
				echo ($row['cam_recruit_end_dt']=='0000-00-00 00:00:00') ? '<span style="color:lightgray">'.substr($row['cam_recruit_end_dt'],2,8).'</span>':substr($row['cam_recruit_end_dt'],2,8);
                echo '<br>';
                echo '<span style="color:#1e90ff;font-weight:900">모집:'.$row['cam_recruit_count'].'명</span>'; 
                echo '<br>';
				echo '<span style="font-weight:900">남은인원:',$row['cam_recruit_count']-$row['cma_idx_count'],'명</span>';  
				echo ' (';
				if(!$row['cma_idx_count'])
					echo '<span style="color:darkgray">신청자 없음</span>';
				else {
					echo '<a href="./campaign_apply_list.php?sfl=cma.cam_idx&stx='.$row['cam_idx'].'" target="_blank">';
					echo '신청:<b>'.$row['cma_idx_count'].'</b>';
					echo '/선정:<b>'.$row['cma_idx_chosen_count'].'</b>';
					echo '</a>';
				}
				echo ')<br>';
				echo '발표일: ';
				echo ($row['cam_notice_dt']=='0000-00-00 00:00:00') ? '<span style="color:lightgray">'.substr($row['cam_notice_dt'],2,8).'</span>':substr($row['cam_notice_dt'],2,8);
				echo '<br>';
				echo '발표상태: '.$g5['set_cam_notice_status'][$row['cam_notice_status']];
			}
			else {
				echo '<span style="color:darkgray">비모집: 누구나 참여가능</span>';
			}
			
			if($row['cam_prd_retime'] == '0' ){
				//다시회차
				echo ' <span class="cam_copy cam_retime">다시회차</span>';
				echo ' <input type="hidden" class="cam_idx_copy" value="'.$row['cam_idx'].'"> ';
				echo ' <input type="hidden" class="cam_recruit_count" value="'.$row['cam_recruit_count'].'"> ';
				echo ' <input type="hidden" class="pdo_prd_times" value="'.$product_times[$row['prd_idx']].'"> ';
			}		
			?>
		</td>
		<td>
			SNS:
			<?php 
			if($row['cam_channels']) {
				$row['cam_channels_array'] = explode(",",$row['cam_channels']);
				sort($row['cam_channels_array']);
				foreach ($row['cam_channels_array'] as $key) {
					echo '<img src="'.G5_THEME_IMG_URL.'/sns_channel_'.$key.'.png" title="'.$g5['sns_channel'][$key].'" style="width:15px;margin-right:3px;" />';
				}
			}
			?>
			<br>
			기간:
			<?php
				echo ($row['cam_review_start_dt']=='0000-00-00 00:00:00') ? '<span style="color:lightgray">'.substr($row['cam_review_start_dt'],2,8).'</span>':substr($row['cam_review_start_dt'],2,8);
				echo '~';
				echo ($row['cam_review_end_dt']=='0000-00-00 00:00:00') ? '<span style="color:lightgray">'.substr($row['cam_review_end_dt'],2,8).'</span>':substr($row['cam_review_end_dt'],2,8);
			?>
			<br>
			상태:
			<?php				
			if($row['cam_review_start_dt'] > G5_TIME_YMDHIS)	// 등록 전
				echo '-';
			// 등록기간 만료 (하지만 등록을 않안사람이 있을경우는 등록 않안사람 표시해 줌)
			else if($row['cam_review_end_dt'] < G5_TIME_YMDHIS) {
				$cma = sql_fetch(" 	SELECT count(cma_idx) AS cma_idx_delay_count, max(cma_reg_end_dt) AS cma_reg_end_dt_max
										FROM {$g5['campaign_apply_table']} 
										WHERE cam_idx = ".$row['cam_idx']." 
											AND cma_status IN ('chosen')
											AND cma_reg_end_dt > '".G5_TIME_YMDHIS."'
										GROUP BY cam_idx ");
				if($cma['cma_idx_delay_count'])
					echo '<span style="color:darkorange">미등록 '.$cma['cma_idx_delay_count'].'명:~'.substr($cma['cma_reg_end_dt_max'],2,8).'까지</span>';
				else 
					echo '완료';
			}	
			else 
				echo '<span style="color:dodgerblue">등록진행중</span>';
			?>
			<br>
			리뷰수:
			<?php
			echo (!$row['rev_idx_count']) ? '-':'<a href="./review_list.php?sfl=rev.cam_idx&stx='.$row['cam_idx'].'" target="_blank">'.number_format($row['rev_idx_count']-$nct_rev['cnt']).' / 사캠: <b>'.$nct_rev['cnt'].'</b> 개  </a>';
			?>
		</td>
		<td>
		발표일 : <?=($row['cam_best_select_dt']=='0000-00-00 00:00:00') ? '<span style="color:lightgray">'.substr($row['cam_best_select_dt'],2,8).'</span>':substr($row['cam_best_select_dt'],2,8)?>
		<br>
		베스트리뷰:
		<?php
		echo (!$row['rev_idx_best_count']) ? '-':'<a href="./review_list.php?sst=rev_best_dt&sod=desc&sfl=rev.cam_idx&stx='.$row['cam_idx'].'" target="_blank">'.number_format($row['rev_idx_best_count']).'개</a>';
		?>
		</td>
		<td style="text-align:center;">
			<?=$s_mod?>
			<br>
			<a href="./campaign_apply_list.php?sfl=cma.cam_idx&stx=<?=$row['cam_idx']?>" target="_blank">신청보기</a>
			<br>
			<a href="./review_list.php?sfl=rev.cam_idx&stx=<?=$row['cam_idx']?>" target="_blank">리뷰보기</a>
			<?php						
			// *** 상품신청 (구매) 상품이 있는지 체크 ***
			$pdo = sql_query(" SELECT pdo.pdo_idx, pdo_recruit_count, pdo_prd_times, cam_prd_time
								,( SELECT prd_times FROM {$g5['product_table']} WHERE prd_idx = pdo.prd_idx ) AS prd_times
								,( SELECT count(cam_idx) FROM {$g5['campaign_table']} WHERE pdo_idx = pdo.pdo_idx AND cam_prd_retime = '0' AND cam_status IN ('pending','ing','ok') ) AS cam_count
							FROM {$g5['product_order_table']} AS pdo
								LEFT JOIN {$g5['campaign_table']} AS cam ON cam.pdo_idx = pdo.pdo_idx							
							WHERE pdo_pay_status = 'payall' AND mb_id = '{$row['mb_id']}' ");
							//WHERE pdo_pay_status = 'payall' AND mb_id = '{$row['mb_id']}' AND cam_idx = '{$row['cam_idx']}' ");
			
			for ($j=0; $row2=sql_fetch_array($pdo); $j++) {
				//echo $row2['pdo_prd_times'].' / '.$row2['cam_count'].'<br>';
				if($row2['pdo_prd_times'] > $row2['cam_count']){
					$a++;
				}
			}
			
			//복사버튼
			//캠페인 등록할수있는 상품이 있으면 보여주기.
			if( $a>0 ){
				echo ' <div class="cam_copy">복사</div> ';
				echo ' <input type="hidden" class="cam_idx_copy" value="'.$row['cam_idx'].'"> ';
				echo ' <input type="hidden" class="pro_mb_id" value="'.$row['mb_id'].'"> ';
			}
			unset($a);
			?>
		</td>
	</tr>
    <?php
    }
    if (!$i)
        echo '<tr><td colspan="8" class="empty_table"><span>자료가 없습니다.</span></td></tr>';
    ?>
    </tbody>
    </table>
	
	<div class="btn_list01 btn_list">
		<a href="./campaign_list_excel.php?sfl_date=<?=$sfl_date?>&st_date=<?=$st_date?>&en_date=<?=$en_date?>&sfl_date2=<?=$sfl_date2?>&st_date2=<?=$st_date2?>&en_date2=<?=$en_date2?>&ser_trm_cat1=<?=$ser_trm_cat1?>&ser_trm_cat2=<?=$ser_trm_cat2?>&ser_trm_cat3=<?=$ser_trm_cat3?>&ser_trm_salesarea=<?=$ser_trm_salesarea?>&sns_trm_idxs=<?=$sns_trm_idxs?>&page=<?=$page?>&ser_trm_idx_salesarea=<?=$ser_trm_idx_salesarea?>&ser_trm_idx_cat1=<?=$ser_trm_idx_cat1?>&ser_trm_idx_cat2=<?=$ser_trm_idx_cat2?>&ser_trm_idx_cat3=<?=$ser_trm_idx_cat3?> " class='btn btn-success btn-sm'>엑셀다운</a>
	</div>
	
	<!--
	<div class="cp_d_submit">
		<div class="cp_d_su_chek">			
			<input type="button" name="" value="SMS 발송" id=""  class="cp_b_but" >
			<input type="button" name="" value="메일 발송" id=""  class="cp_b_but" >
			<input type="button" name="" value="코인 지급" id=""  class="cp_b_but" > 
		</div>
	</div>
	-->
</div>

</form>

<?php echo get_paging(G5_IS_MOBILE ? $config['cf_mobile_pages'] : $config['cf_write_pages'], $page, $total_page, '?device=pc&amp;'.$qstr.'&amp;page='); ?>

<script>
$(function() {
    $("#st_date,#en_date,#st_date2,#en_date2").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: "yy-mm-dd",
        showButtonPanel: true,
        yearRange: "c-99:c+99",
        //maxDate: "+0d"
    });	 
	
	// 특정날짜들 배열
	disabledDays = [<?= $setting['set_campaign_holidays']; ?>];
	var set_campaign_holiday_include_yn = <?= $setting['set_campaign_holiday_include_yn']; ?>;
	var set_weekend_holidays_yn = <?= $setting['set_weekend_holidays_yn']; ?>;
	//캠페인 복사 달력.
	$("#cam_copy_day").datepicker({
		changeMonth: true,
		changeYear: true,
		dateFormat: "yy-mm-dd",
		showButtonPanel: true,
		yearRange: "c-99:c+99",
		beforeShowDay: function(date){
				//주말(토, 일요일) 선택 막기
				var day = date.getDay();
				
				// 특정일 선택막기				
				var m = date.getMonth(), d = date.getDate(), y = date.getFullYear();
				for (i = 0; i < disabledDays.length; i++) {
					if($.inArray(y + '-' +(m+1) + '-' + d,disabledDays) != -1) {
						return [false];
					}
				}
										
				//주말 포함하여 계산
				if( set_campaign_holiday_include_yn == 0){
					if( set_weekend_holidays_yn == 0){
						return [true],[(day != 0)]; //일 주말 설정
					}
					else{
						return [true],[(day != 0 && day != 6)]; //토 / 일 주말 설정 
					}
				}
				//주말 건너뛰고 계산
				else{
					return [true];
				}
			}
		//,maxDate: "+1d"
		//,minDate: "+1d"
	});
	
	// 캠페인 복사 모달.
	$(document).off('click','.cam_copy').on('click','.cam_copy',function(e){
		//이전에 모집인원 html 만든게 있으면 지우기.
		$(".cam_recruit_count_wrap").detach();
		
		//캠페인 idx 값.
		var cam_idx_copy = $(this).next().val();
		//모집인원, 회원아이디 값.
		var pro_mb_id = $(this).next().next().val();
		//캠페인 진행 상품회차.
		var pdo_prd_times = $(this).next().next().next().val();

		//다시회차,복사 구분방법.
		var text_device = $(this).html();
		
		if( text_device == '다시회차'){
			var text_device_val = 're';
			//복사에서 사용하는 기능 숨기기.
			$(".pro_copy_wrap").hide();
			$(".pro_copy_wrap").before(
				'<div class="cam_recruit_count_wrap">'
					+'<span class="cam_recruit_count_title">모집인원 : </span>'
					+'<input type="text" name="cam_recruit_count" value="'+pro_mb_id+'" class="cam_recruit_count_input" >'
				+'</div>');
			//submit 이름 변경하기.
			$("#cam_copy_submit").val("진행");
		}else{
			//다시회차 에서 숨긴 상품선택 보이게하기.
			$(".pro_copy_wrap").show();			
			var text_device_val = 'cp';
			//submit 이름 변경하기.
			$("#cam_copy_submit").val("복사");
		}
		
		
		$(".modal_title").text('캠페인 '+text_device);
		
		// 모달 창 오픈
		$('#modal09').bPopup(function(){
			
			if( text_device_val == 'cp'){				
				//ajax로 상품선택 내용 만들기.
				$.ajax({
					url:g5_url+'/_u/ajax/ajax_cam_copy.php', type:'get',
					data:{"mod":"list","cam_idx":cam_idx_copy,"mb_id":pro_mb_id}, 
					dataType:'json', timeout:40000,
					async:false,
					success:function(res){
						//console.log(res.sql2);
						//alert(res.mb_id);
						//옵션 입력하기.
						$("#goods_check2").html(res.op_list);
					}
				});
			}
			
			//submit 클릭!
			$(document).off('click','#cam_copy_submit').on('click','#cam_copy_submit',function(e){						
				
				if( text_device_val == 'cp'){
					//상품선택 빈값 확인.
					if ( $('#goods_check2').val().length < 1) {
						alert("상품을 선택해주세요.");
						$('#goods_check2').focus();
						return false;
					};
				}
				
				//다시회차
				if( text_device_val == 're'){
					//모집인원 빈값 확인.
					if ( $('input[name=cam_recruit_count]').val().length < 1) {
						alert("모집인원을 입력해주세요.");
						$('input[name=cam_recruit_count]').focus();
						return false;
					};
				}
				
				//날짜 빈값확인.
				if ( $('#cam_copy_day').val().length < 1) {
					alert("날짜를 입력해주세요.");
					$('#cam_copy_day').focus();
					return false;
				};

				document.getElementById("cam_copy_submit").disabled = "disabled";

				//값 가져오기.
				var goods_check2 = $('#goods_check2').val();
				var start_day = $('#cam_copy_day').val();
				var cam_recruit_count = $('input[name=cam_recruit_count]').val();
				
				//ajax 작업.
				$.ajax({
					url:g5_url+'/_u/ajax/ajax_cam_copy.php', type:'get',
					data:{"mod":"in","cam_idx":cam_idx_copy,"start_day":start_day,"goods_check2":goods_check2,"text_device_val":text_device_val,"cam_recruit_count":cam_recruit_count,"pdo_prd_times":pdo_prd_times}, 
					dataType:'json', timeout:40000,
					async:false,
					success:function(res){
						console.log(res.start_day);
						console.log(res.sql);
						//console.log(res.cam_prd_time_make);
						//console.log(res.pdo_prd_times);
						
						alert( res.msg );
						location.reload();
					}
				});			
			});		
		});
		
	});

});
</script>

<?php
include_once (G5_ADMIN_PATH.'/admin.tail.php');
?>
