<?php
	include_once('./_common.php');
	include_once(G5_EDITOR_LIB);

	//if (!$is_member) {
	//	alert('**** 죄송합니다 **** \n먼저 로그인해 주세요.', G5_USER_URL.'/k/login.php');
	//}
	if($member['mb_level'] < 4){
		alert('**** 죄송합니다 **** \n담당자,업체전용 관리시스템 입니다.', G5_URL.'/index.php' );
	}

	if($w == 'u'){
		$g5['title'] = '캠페인 수정';
	}else{
		$g5['title'] = '캠페인 등록';		
	}
	include_once('./_head.php');

	// 불법접근을 막도록 토큰생성
	$token = md5(uniqid(rand(), true));
	set_session("ss_token", $token);
	set_session("ss_cert_no",   "");
	set_session("ss_cert_hash", "");
	set_session("ss_cert_type", "");

	$pdo_idx = $_GET['pdo_idx'];
	
	$today = date("Y-m-d 23:59:59", mktime(00,00,00,date("m")  , date("d"), date("Y")));

	//블로그상품 환경설정 값 배열로 만들기.
	$set_naver_product_array = explode(',',$setting['set_naver_product']);

//alert('죄송합니다. 2016.11.08 ( 9:30 ~ 2:00 )까지 점검중입니다.');
	
//업데이트
if($w == 'u'){	
	//메일 링크로 접속시 이미지난 캠페인이 수정페이지로 들어 올수 없도록 하기.
	$mail_confirm = sql_fetch(" SELECT * FROM {$g5['campaign_table']} WHERE cam_idx = '{$cam_idx}' ");		
	
	//상태값 ing 중에 오늘날짜 기준으로 지난날만 ing 하기.
	if($mail_confirm['cam_status'] == 'ing'){
		if( $today < $mail_confirm['cam_recruit_start_dt']){
			$ing_cam_status = 'pending';
		}else{
			$ing_cam_status = 'ing';
		}
	}else{
		$ing_cam_status = 'pending';
	}
	
	if( $ing_cam_status == 'ing' or $mail_confirm['cam_status'] == 'ok' or $mail_confirm['cam_status'] == 'cancel' or $mail_confirm['cam_status'] == 'trash'){
		alert('이미 진행된 캠페인 입니다. \\n캠페인정보 페이지로 이동합니다.',G5_USER_URL."/k/campaign_form2.php?cam_idx=".$cam_idx."");
	}
	
	//업데이트할때 정보 추출하기.
	$sql = " SELECT cam.* 
					, com.com_name,com.com_addr1 ,com.com_addr2 ,com.com_latitude ,com.com_longitude ,com.trm_idx_salesarea ,com.mb_id ,com_manager_hp ,com_email
					, ( SELECT pdo_prd_name FROM {$g5['product_order_table']} WHERE pdo_idx = cam.pdo_idx ) AS pdo_prd_name	
				FROM {$g5['campaign_table']} AS cam
					LEFT JOIN {$g5['company_table']} AS com ON com.com_idx = cam.com_idx
				WHERE cam_idx = '{$cam_idx}' ";
	$cam = sql_fetch($sql,1);
	
	
	
	//블로그상품 확인 변수 (있을때만 1) , 블로그상품 확인변수 = $cam['pdo_prd_name'];
	$blog_check = in_array($cam['pdo_prd_name'],$set_naver_product_array);
	
	// SNS 채널 추출 (term_relation)
	$cam_channel = sql_fetch(" SELECT GROUP_CONCAT( CAST(trm_idx AS CHAR) ORDER BY tmr_sort) AS cam_channels 
								FROM {$g5['term_relation_table']} 
								WHERE tmr_db_table = 'campaign' AND tmr_db_key = 'channel' AND tmr_db_id = '".$cam['cam_idx']."' ");
		
	//sns 채널 키 추출해서 배열로 만들기.
	$cam['cam_channels_array'] = explode(",",$cam_channel['cam_channels']);
}
//신규 
else{
	$sql = " SELECT * FROM {$g5['product_order_table']} WHERE pdo_idx = '{$pdo_idx}' ";
	$pdo = sql_fetch($sql,1);
			
	//블로그상품 확인 변수 (있을때만 1) , 블로그상품 확인변수 = $cam['pdo_prd_name'];
	$blog_check = in_array($pdo['pdo_prd_name'],$set_naver_product_array);
			
	//관리페이지에 체널 사용 온,오프 만들기.
}

//***[업체선택] 업체명 추출하기 ***
//업체로 로그인 했을떄.
if($member['mb_level'] == '4'){
	$sql1 = " SELECT * FROM {$g5['company_table']} WHERE mb_id = '{$member['mb_id']}' ";
	$sql2 = " SELECT * FROM {$g5['company_table']} WHERE mb_id = '{$member['mb_id']}' AND com_status = 'ok' ";
	$sql3 = " SELECT * FROM {$g5['company_table']} WHERE mb_id = '{$member['mb_id']}' AND com_status = 'ok' ORDER BY com_data_agree_dt desc ";	
	//업체선택에 사용됨.
	$sql4 = " SELECT * FROM {$g5['company_table']} WHERE mb_id = '{$member['mb_id']}' AND com_status = 'ok' AND com_data_agree_dt != '0000-00-00 00:00:00' ";
	
	//업체,담당자가 캠페인 등록 할때 업체가 등록되어있지 안거나, 상태값 이 승인완료[ok] 아니면 업체관리 페이지로 이동해라. 
	$resul1_cnt = sql_fetch($sql1,1);	
	$data_agree = sql_fetch($sql3,1);
	
	
	if( $w == '' && $data_agree['com_data_agree_dt'] == '0000-00-00 00:00:00'){
		alert('자료사용 동의서를 동의 후 진행해주세요.',G5_USER_URL."/k/company_list.php?sfl=mb_id&stx=".$mb_id."");
	}
	if( $w == '' && $resul1_cnt['com_idx'] == ''){
		alert('등록된 업체가 없습니다. \\n업체를 등록해주세요.',G5_USER_URL."/k/company_list.php?sfl=mb_id&stx=".$mb_id."");
	}

}
//담당자로 로그인 했을때.
if($member['mb_level'] >= '6'){
	$sql2 = " SELECT * FROM {$g5['company_table']} AS com 
					LEFT JOIN {$g5['company_member_table']} AS comm on comm.com_idx = com.com_idx
				WHERE com.mb_id = '{$mb_id}' AND comm.mb_id = '{$member['mb_id']}' AND com.com_status = 'ok' 
				GROUP BY com.com_idx 
				ORDER BY com_reg_dt DESC;
			";
			
	//업체선택에 사용됨.
	$sql4 = " SELECT * FROM {$g5['company_table']} WHERE mb_id = '{$mb_id}' AND com_status = 'ok' AND com_data_agree_dt != '0000-00-00 00:00:00' ";	
}
$status = sql_fetch($sql2,1);

if( $w == '' && $status['com_data_agree_dt'] == '0000-00-00 00:00:00'){
	alert('자료사용 동의서를 동의 후 진행해주세요.',G5_USER_URL."/k/company_list.php?sfl=mb_id&stx=".$mb_id."");
}

//if( $w == '' && $status['com_idx'] == '' && $status['com_data_agree_dt'] != '0000-00-00 00:00:00'){
//	alert('등록한 업체 상태값이 정상(승인완료)인지 확인해주세요.',G5_USER_URL."/k/company_list.php?sfl=mb_id&stx=".$mb_id."");
//}

//업체선택에 사용됨.
$resul2 = sql_query($sql4,1);
	
// *** 상품신청 (구매) 상품이 있는지 체크 START ***
$pdo = sql_query(" SELECT pdo_idx, pdo_prd_times, pdo_recruit_count
					,( SELECT prd_times FROM {$g5['product_table']} WHERE prd_idx = pdo.prd_idx ) AS prd_times
					,( SELECT count(cam_idx) FROM {$g5['campaign_table']} WHERE pdo_idx = pdo.pdo_idx AND cam_status IN ('pending','ing','ok') ) AS cam_count
				FROM {$g5['product_order_table']} AS pdo 
				WHERE pdo_pay_status = 'payall' AND mb_id = '{$member['mb_id']}' ");

for ($i=0; $row=sql_fetch_array($pdo); $i++) {
	//echo $row['prd_times'].' / '.$row['cam_count'].' / '.$row['pdo_recruit_count'].'<br>';
	//echo $row['pdo_prd_times'].'<br>';
	//echo $row['prd_times'].'<br>';
	//if($row['prd_times'] > $row['cam_count']){
	
	if($row['pdo_prd_times'] > $row['cam_count']){
		$j++;
	}
}

if($w != 'u' && $member['mb_level'] == '4'){
	// 하나도 없으면 빠진다.
	if($j<=0)
		alert('신청(구매)된 상품이 없습니다.\n상품을 구매해 주세요', G5_USER_URL."/k/goods.php?j=".$j."");			
		//goto_url( G5_USER_URL."/k/goods.php?j=".$j."" );			
}

//상품명,상품회차 추출하기.
if(isset($pdo_idx)){
	$sql = "SELECT *
			,( SELECT count(cam_idx) FROM {$g5['campaign_table']} WHERE pdo_idx = pdo.pdo_idx AND cam_status IN ('pending','ing','ok') ) AS cam_count
			,( SELECT mb_name FROM {$g5['member_table']} WHERE mb_id = pdo.mb_id_saler ) AS mb_name
			FROM {$g5['product_order_table']} AS pdo WHERE pdo_idx = '{$pdo_idx}' ";
	$proo = sql_fetch($sql,1);
}	

// *** 상품신청 (구매) 상품이 있는지 체크 END ****



// 관련 파일(post_file) 추출
if($cam['cam_idx']){
	
	$sql = "SELECT * FROM {$g5['file_table']} 
			WHERE fle_db_table = 'campaign' AND fle_db_id = '".$cam['cam_idx']."' ORDER BY fle_sort, fle_reg_dt DESC ";
	$rs = sql_query($sql,1);
	//echo $sql;
	
	$fle_type1 = "campaign_img";
	
	for($i=0;$row=sql_fetch_array($rs);$i++) {
		$cam[$row['fle_type']][$row['fle_sort']]['file'] = (is_file(G5_PATH.$row['fle_path'].'/'.$row['fle_name'])) ? 
							'&nbsp;&nbsp;<a href="'.G5_USER_URL.'/lib/download.php?file_fullpath='.urlencode(G5_PATH.$row['fle_path'].'/'.$row['fle_name']).'&file_name_orig='.$row['fle_name_orig'].'">파일다운로드</a>'
							.'&nbsp;&nbsp;<input type="checkbox" name="'.$row['fle_type'].'_del['.$row['fle_sort'].']" value="1"> 삭제 &nbsp;&nbsp;'.$row['fle_name'].''
							:'';
		$cam[$row['fle_type']][$row['fle_sort']]['fle_name'] = (is_file(G5_PATH.$row['fle_path'].'/'.$row['fle_name'])) ? 
							$row['fle_name'] : '' ;
		$cam[$row['fle_type']][$row['fle_sort']]['fle_path'] = (is_file(G5_PATH.$row['fle_path'].'/'.$row['fle_name'])) ? 
							$row['fle_path'] : '' ;
		$cam[$row['fle_type']][$row['fle_sort']]['exists'] = (is_file(G5_PATH.$row['fle_path'].'/'.$row['fle_name'])) ? 
							1 : 0 ;
		
		//썸내일부분.
		if($cam[$fle_type1][$i]['fle_name']) {			
			$cam[$fle_type1][$i]['thumbnail'] = thumbnail($cam[$fle_type1][$i]['fle_name'], 
							G5_PATH.$cam[$fle_type1][$i]['fle_path'], G5_PATH.$cam[$fle_type1][$i]['fle_path'],
							400, 300, 
							false, true, 'center', true, $um_value='80/0.5/3');	// is_create, is_crop, crop_mode
		}	
		else {			
			//기본이미지 보여주시
			$cam[$fle_type1][$i]['thumbnail'] = 'default.png';
			$cam[$fle_type1][$i]['fle_path'] = '/data/'.$fle_type1;
		}

		if($cam[$fle_type1][$i]['exists'])
		$cam[$fle_type1][$i]['img'] = '<div style="margin-top:10px;"><img src="'.G5_URL.$cam[$fle_type1][$i]['fle_path'].'/'.$cam[$fle_type1][$i]['fle_name'].'" style="width:130px;"></div>';		
		//$cam[$fle_type1][$i]['thumbnail_img'] = '<img src="'.G5_URL.$cam[$fle_type1][$i]['fle_path'].'/'.$cam[$fle_type1][$i]['thumbnail'].'" width="200">';	
	}
	
	
	
	//campaign_form.skin.php 이미지 부분에서 사용됨.
	$sql = "SELECT * FROM {$g5['file_table']} 
			WHERE fle_db_table = 'campaign' AND fle_db_id = '".$cam['cam_idx']."' ORDER BY fle_sort, fle_reg_dt DESC ";
	$rs1 = sql_query($sql,1);
	
	//등록된 파일 cnt
	$file_cnt = sql_fetch( "SELECT count(fle_idx) AS cnt FROM {$g5['file_table']} 
			WHERE fle_db_table = 'campaign' AND fle_db_id = '".$cam['cam_idx']."' " ,1);		
}
	
	$readonly = ($w=='u') ? 'readonly' : '';
	$register_action_url = G5_URL.'/_u/k/campaign_form_update.php';
?>

	<script src="<?php echo G5_JS_URL ?>/jquery.register_form.js"></script>
<?php if($config['cf_cert_use'] && ($config['cf_cert_ipin'] || $config['cf_cert_hp'])) { ?>
	<script src="<?php echo G5_JS_URL ?>/certify.js"></script>
<?php	
	}
	
include_once($kafain_skin_path.'/campaign_form.skin.php');

include_once('./_tail.php');
?>
