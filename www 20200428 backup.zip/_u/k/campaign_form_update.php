<?php
include_once('./_common.php');
//include_once(G5_CAPTCHA_PATH.'/captcha.lib.php');
include_once(G5_LIB_PATH.'/register.lib.php');
include_once(G5_LIB_PATH.'/thumbnail.lib.php');
include_once(G5_LIB_PATH.'/mailer.lib.php');
include_once(G5_LIB_PATH.'/pclzip.lib.php');


// error_reporting(E_ALL);
// 
// ini_set("display_errors", 1);

if (!function_exists('rm_rf')) {
function rm_rf($file) {
    if (file_exists($file)) {
        if (is_dir($file)) {
            $handle = opendir($file);
            while($filename = readdir($handle)) {
                if ($filename != '.' && $filename != '..')
                    rm_rf($file.'/'.$filename);
            }
            closedir($handle);

            @chmod($file, G5_DIR_PERMISSION);
            @rmdir($file);
        } else {
            @chmod($file, G5_FILE_PERMISSION);
            @unlink($file);
        }
    }
}
}

if (!function_exists('zip_dir')) {
function zip_dir($dir) {
    $allowed_ext = "/jpg|jpeg|png|bmp|gif/i";
    if (is_dir($dir)) {
        $handle = opendir($dir);
        while ($file = readdir($handle)) {
            if ($file != "." && $file != "..") {
                $file_info = pathinfo($file);
                preg_match($allowed_ext, $file_info['extension'], $matches);
                if (count($matches) <= 0) {
                    if (is_dir($dir."/".$file)) {
                        rm_rf($dir.'/'.$file);
                    } else {
                        @unlink($dir."/".$file);
                    }
                }
                
                if (preg_match("/[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]/", $file)) {
                    $new_name = md5($file_info['filename']).'.'.$file_info['extension'];
                    @rename($dir.'/'.$file, $dir.'/'.$new_name);
                }
            }
        }
    }
}
}

/*
if (!chk_captcha()) {
    alert('자동등록방지 숫자가 틀렸습니다.');
}
*/

//구매상품선택해서 입력된 정보들.
// pdo_idx ,cam_name ,mb_id_saler ,cam_count+1 값을 같이 담아와서 콤마로 구분하기	
$goods_check = explode(',',$_POST['goods_check']);
$pdo_idx2  = $goods_check[0];
$cam_prd_name2 = $goods_check[1]; //상품명
$mb_id_saler2 = $goods_check[2]; //영업담당자ID
$cam_prd_time2 = $goods_check[3]; //상품회차
$cam_recruit_count2 = $goods_check[4]; //모집체험단수
$cam_mb_saler2 = $goods_check[5]; //영업담당자NAME
$pdo_prd_times2 = $goods_check[6]; //pdo_prd_times 테이블에 구매캠페인횟수.

$cam_prd_time			= ( $cam_prd_time2 != '' )				? $cam_prd_time2					: $_POST['cam_prd_time'];
$cam_prd_name 		 	= ( $_POST['cam_prd_name'] != '' )		? $_POST['cam_prd_name']			: $cam_prd_name2;
$pdo_idx 				= ( $_POST['pdo_idx'] != '' )			? $_POST['pdo_idx']					: $pdo_idx2;
$mb_id_saler 			= ( $mb_id_saler != '' )				? $mb_id_saler		    			: $mb_id_saler2;
$cam_reviewer_yn 		= trim($_POST['cam_reviewer_yn']);
$cam_name 				= isset($_POST['cam_name'])				? $_POST['cam_name'] 				: "";
$cam_brief 				= isset($_POST['cam_brief'])			? $_POST['cam_brief']				: "";
$cam_recruit_count 		= ( $cam_recruit_count != '' )			? $cam_recruit_count				: $cam_recruit_count2; //모집체험단수
$mb_id_company 			= isset($_POST['mb_id_company'])		? $_POST['mb_id_company']			: $_POST['mb_id_company2']; //업체ID
$cam_mb_saler 			= ( $cam_mb_saler != '' )				? $cam_mb_saler						: $cam_mb_saler2; //영업담당자NAME
$pdo_prd_times 			= ( $_POST['pdo_prd_times'] != '' )		? $_POST['pdo_prd_times']			: $pdo_prd_times2; //pdo_prd_times 테이블에 구매캠페인횟수.

//업체명 , 담당자전화번호, 담당자이메일 분리작업. (신청인연락처 에 com_manager_hp 입력됨. 캠페인 상태 변경시 문자발송 전화번호로 사용됨. )
$com_idx = explode(',',$_POST['com_idx']);
$com_idx2 = $com_idx[0];
$com_manager_hp = $com_idx[1];
$com_email = $com_idx[2];
$com_name2 = $com_idx[3];

$cam_mb_tel				= ($_POST['cam_mb_tel'] != '')		? $_POST['cam_mb_tel']			: $com_manager_hp;
$cam_mb_email			= ($_POST['cam_mb_email'] != '')	? $_POST['cam_mb_email']		: $com_email;

// 카테고리
$trm_idx_cat1 			= trim($_POST['cat1_trm_idxs']);
$trm_idx_cat2 			= trim($_POST['cat2_trm_idxs']);
$trm_idx_cat3 			= trim($_POST['cat3_trm_idxs']);
$trm_idx_salesarea 		= trim($_POST['trm_idx_salesarea']);

//*********************
// Campaign - Term relation SNS 정보 업데이트
for($i=0;$i<sizeof($sns_channel);$i++) {		
	// cam_channels 정보 설정
	$cam_channels_make .= ',^'.$sns_channel[$i].'^';
}
//앞에 붙은 , 제거하기.
$cam_channels =substr($cam_channels_make,1);


//SNS. 캠페인테이블에 마지막 생성된 cam_idx 값 가져오기.
//$sns_ar = array($cam_review_k,$cam_review_f,$cam_review_i,$cam_review_p);

//// 선택된 SNS 를 cam_channels 입력할 내용 만들기
//foreach(array_filter($sns_ar) as $sns){
//	//-- 기존 디비 삭제를 위해 배열 미리 생성 --//
//	$sns_channel_array[] = $sns;
//	// cam_channels 정보 설정
//	$cam_channels_a .= ',^'.$sns.'^';
//}
////앞에 붙은 , 제거하기.
//$cam_channels = substr($cam_channels_a,1);

//**********************

$cam_recruit_start_dt 	= isset($_POST['cam_recruit_start_dt'])	? trim($_POST['cam_recruit_start_dt'])	: "";
$cam_recruit_end_dt 	= isset($_POST['cam_recruit_end_dt'])	? trim($_POST['cam_recruit_end_dt'])	: "";
$cam_notice_dt 			= isset($_POST['cam_notice_dt'])		? trim($_POST['cam_notice_dt'])			: "";
$cam_review_start_dt 	= isset($_POST['cam_review_start_dt']) 	? trim($_POST['cam_review_start_dt'])	: "";
$cam_review_end_dt 		= isset($_POST['cam_review_end_dt'])	? trim($_POST['cam_review_end_dt'])		: "";
$cam_best_select_dt 	= isset($_POST['cam_best_select_dt'])	? trim($_POST['cam_best_select_dt'])	: "";
$cam_point_type 		= trim($_POST['cam_point_type']);
$cam_best_use_yn 		= isset($_POST['cam_best_use_yn'])		? trim($_POST['cam_best_use_yn'])		: "";
$cam_head_content 		= isset($_POST['cam_head_content'])		? trim($_POST['cam_head_content'])		: "";

//내용
if( $cam_type == 'visite' ){
	$cam_content =  $cam_content;
}
if( $cam_type == 'delivery' ){
	$cam_content =  $cam_content1;
}
if( $cam_type == 'PressCorps' ){
	$cam_content =  $cam_content2;
}
if( $cam_type == 'receipt' ){
	$cam_content =  $cam_content3;
}
if( $cam_type == 'reservation' ){
	$cam_content =  $cam_content4;
}
//if ($_POST['cam_content'] != '' ) {
//    $cam_content = substr(trim($_POST['cam_content']),0,65536);
//    $cam_content = preg_replace("#[\\\]+$#", "", $cam_content);
//}

$cam_zip				= isset($_POST['cam_zip'])				? trim($_POST['cam_zip'])				: "";
$cam_addr1 				= isset($_POST['cam_addr1'])			? trim($_POST['cam_addr1'])				: "";
$cam_addr2 				= isset($_POST['cam_addr2'])			? trim($_POST['cam_addr2'])				: "";
$cam_reg_dt 			= isset($_POST['cam_reg_dt'])			? trim($_POST['cam_reg_dt'])			: "";
$cam_hit 				= isset($_POST['cam_hit'])				? trim($_POST['cam_hit'])				: "";
$cam_latitude 			= isset($_POST['cam_latitude'])			? trim($_POST['cam_latitude'])			: "";
$cam_longitude 			= isset($_POST['cam_longitude'])		? trim($_POST['cam_longitude']) 		: "";

/*
if($w == 'u')
    $mb_id = isset($_SESSION['ss_mb_id']) ? trim($_SESSION['ss_mb_id']) : '';
else if($w == '')
    $mb_id = trim($_POST['mb_id']);
else
    alert('잘못된 접근입니다', G5_URL);

$mb_name        = clean_xss_tags($mb_name);
$mb_email       = get_email_address($mb_email);
$mb_homepage    = clean_xss_tags($mb_homepage);
$mb_tel         = clean_xss_tags($mb_tel);
$mb_zip1        = preg_replace('/[^0-9]/', '', $mb_zip1);
$mb_zip2        = preg_replace('/[^0-9]/', '', $mb_zip2);
$mb_addr1       = clean_xss_tags($mb_addr1);
$mb_addr2       = clean_xss_tags($mb_addr2);
$mb_addr3       = clean_xss_tags($mb_addr3);
$mb_addr_jibeon = preg_match("/^(N|R)$/", $mb_addr_jibeon) ? $mb_addr_jibeon : '';
*/

// 사용자 코드 실행
@include_once($member_skin_path.'/register_form_update.head.skin.php');

//===============================================================
// '".G5_TIME_YMDHIS."': 현재시간 초단위
// '".G5_TIME_YMD."' : 현재 년월일


//신규일때.
if ($w == '') {
	//echo $cam_prd_time.'<br>'; //진행중인 회차
	//echo 'pdo_prd_times 테이블 = '.$pdo_prd_times.'<br>'; //진행해야할 회차
	//echo '자동진행여부 = '.$cam_auto_make_yn.'<br>';
	
	//캠페인 자동등록 할때.
	if($cam_auto_make_yn == '1'){
		for($i = $cam_prd_time ; $i <= $pdo_prd_times ; $i++){						
			//처음 입력되는 값들.
			if( $i == $cam_prd_time ){
				$cam_period = " cam_recruit_start_dt = '{$cam_recruit_start_dt}',
								cam_recruit_end_dt = '{$cam_recruit_end_dt}',
								cam_notice_dt = '{$cam_notice_dt}',
								cam_notice_status = 'pending',	
								cam_review_start_dt = '{$cam_review_start_dt}',
								cam_review_end_dt = '{$cam_review_end_dt}',
								cam_best_select_dt = '{$cam_best_select_dt}' ";
			}
			//자동등록으로 입력되는 값들.
			else{
				$cam_row = sql_fetch( "SELECT * FROM {$g5['campaign_table']} ORDER BY cam_idx DESC" ,1);
				
				//자동등록에 시작할 날짜 설정하기. (베스트사용)
				if($cam_best_use_yn == '1'){					
					$start_day = $cam_row['cam_best_select_dt'];
				}
				//베스트 미사용.
				else{
					$start_day = $cam_row['cam_review_end_dt'];
				}
				
				//함수로 자동날짜 만들기.
				$cam_period = cam_day_auto($start_day);
				$cam_period .= ", cam_notice_status = 'pending' ";
			}		
			
			$in_sql = " INSERT INTO  {$g5['campaign_table']}
						SET pdo_idx = '{$pdo_idx}',
							cam_type = '{$cam_type}',
							cam_reviewer_yn = '{$cam_reviewer_yn}',
							mb_id_company = '{$mb_id_company}',
							com_idx = '{$com_idx2}',
							cam_prd_name = '{$cam_prd_name}',
							mb_id_saler = '{$mb_id_saler}',
							cam_mb_saler = '{$cam_mb_saler}',
							trm_idx_cat1 = '{$trm_idx_cat1}',
							trm_idx_cat2 = '{$trm_idx_cat2}',
							trm_idx_cat3 = '{$trm_idx_cat3}',
							trm_idx_salesarea = '{$trm_idx_salesarea}',
							cam_auto_make_yn = '{$cam_auto_make_yn}',
							cam_channels = '{$cam_channels}',
							cam_prd_time = '{$i}',
							cam_mb_name = '{$cam_mb_name}',
							cam_mb_tel = '{$cam_mb_tel}',
							cam_mb_email = '{$cam_mb_email}',
							cam_name = '{$cam_name}',
                            com_naver_place_url = '{$com_naver_place_url}',
							cam_brief = '{$cam_brief}',
							cam_recruit_count = '{$cam_recruit_count}',
							mb_id_info = '{$member['mb_id']}',
							cam_info_reg_dt = '".G5_TIME_YMDHIS."',
							".$cam_period.",						
							cam_point_type = '{$cam_point_type}',
							cam_best_use_yn = '{$cam_best_use_yn}',
							cam_reviewer_point = '{$cam_reviewer_point}',
							cam_best_point = '{$cam_best_point}',
							cam_head_content = '{$cam_head_content}',
							cam_tags = '{$cam_tags}',
							cam_content = '{$cam_content}',
							cam_reg_dt = '".G5_TIME_YMDHIS."',
							cam_status = '{$cam_status}' ";
			
			sql_query($in_sql); 	
			$cam_idx = sql_insert_id();//table 마지막 생성된 id 값 가져오기 
			
			//campaign_table에 다시회차 사용할 cam_idx_parent에 자기자신 아이디값으로 업데이트하기.
			$sql2 = " UPDATE {$g5['campaign_table']} SET  cam_idx_parent = '{$cam_idx}' WHERE cam_idx = '{$cam_idx}' ";
			sql_query($sql2);
			
			unset($start_day); unset($cam_period);
			
			// Campaign - Term relation SNS 정보 업데이트 S
			if( sizeof($sns_channel) ) {
				for($j=0;$j<sizeof($sns_channel);$j++) {
					//echo $sns_channel[$j].'/'.$cam_idx.'<br>';
					//-- 기존 디비 삭제를 위해 배열 미리 생성 --//
					$sns_channel_array[] = $sns_channel[$j];
					
					// term_relation 정보 업데이트 (있으면 수정, 없으면 추가)
					term_relation_update(array('tmr_db_table'=>'campaign'
													,'tmr_db_key'=>'channel'
													,'trm_idx'=>$sns_channel[$j]
													,"tmr_db_id"=>$cam_idx
													,"dup_permit"=>1
					));
				}
			
				// 삭제(해제)된 항목들을 관련 디비 전부 제거함
				$del_where = (sizeof($sns_channel_array))? " AND trm_idx NOT IN (".implode(",",$sns_channel_array).") ":"";
				$de_sql = " DELETE FROM {$g5['term_relation_table']} WHERE tmr_db_id='{$cam_idx}' ".$del_where." ";
				sql_query($de_sql);
			}			
			//Campaign - Term relation SNS 정보 업데이트 E			
			
			//자동등록 파일 처리 (파일 타입이 여러개면 일련번호 붙여서 확장해 주세요.) 등록한 파일수 만큼 돌아라~! ----------------
			$fle_type1 = "campaign_img";			
			//print_r2( $_FILES[$fle_type1.'_file'] );			
			//echo count( array_filter($_FILES[$fle_type1.'_file']['name']) ).'<br>';			
			for($j=0;$j<count( array_filter($_FILES[$fle_type1.'_file']['name']) );$j++) {
				
				// 자동등록 시 맨 처음 캠페인?
				if($i == $cam_prd_time){
					// 파일 등록
					$uploaded[] = upload_jt_file(array("fle_idx"=>$fle_idx
										,"mb_id"=>$member['mb_id']
										,"fle_src_file"=>$_FILES[$fle_type1.'_file']['tmp_name'][$j] //파일이름.
										,"fle_orig_file"=>$_FILES[$fle_type1.'_file']['name'][$j] //원본 파일명.
										,"fle_mime_type"=>$_FILES[$fle_type1.'_file']['type'][$j] //이미지 타입정보.
										,"fle_content"=>$fle_content
										,"fle_path"=>'/data/campaign_img/'.$cam_idx		//<---- 저장 디렉토리
										,"fle_db_table"=>"campaign"
										,"fle_db_id"=>$cam_idx
										,"fle_type"=>$fle_type1
										,"fle_sort"=>$j
                    ));
                    // 압축파일 해제 pkw
					if ($_FILES[$fle_type1.'_file']['name'][4]) {
						
						$zip_info = pathinfo($_FILES[$fle_type1.'_file']['name'][4]);
						$extract_dir = G5_DATA_PATH.'/campaign_img/'.$cam_idx.'/'.$zip_info['filename'];
						
						$archive = new PclZip(G5_DATA_PATH.'/campaign_img/'.$cam_idx.'/'.$_FILES[$fle_type1.'_file']['name'][4]);
						$archive->extract(PCLZIP_OPT_PATH, $extract_dir);
						@chmod($extract_dir, G5_DIR_PERMISSION);
						
					}
                    

				}
				// 자동등록 시 맨 처음 아닌 경우
				else {					
					//처음등록된 캠페인번호 저정하기. 복사할떄 사용해야함.
					 $first_id = sql_fetch(" SELECT * FROM {$g5['campaign_table']} WHERE cam_name = '{$cam_name}' AND mb_id_info = '{$member['mb_id']}' AND cam_idx = cam_idx_parent AND cam_prd_time = '1' ");

					//print_r2($uploaded[$j]).'<br>';
					//디렉토리 생성 (퍼미션도 변경! = 폴더 사용권한 open)
					@mkdir(G5_PATH.'/data/campaign_img/'.$cam_idx, G5_DIR_PERMISSION);
					@chmod(G5_PATH.'/data/campaign_img/'.$cam_idx, G5_DIR_PERMISSION);

					//디렉토리 설정
					$dir = G5_PATH.'/data/campaign_img/'.$cam_idx;
					//원본 파일 경로
					$dir2 = G5_PATH.'/data/campaign_img/'.$first_id['cam_idx'];

					//echo '---- 복사시작 ----<br>';
					//echo '메인: '.$first_id['cam_idx'].'<br>';
					//echo '복사: '.$cam_idx.'<br>';
					//echo $dir2.'<br>';
					//echo '11111111111111111111111111<br>';
					//echo '원본경로: '.$dir2.'/'.$uploaded[$j]['upfile_name'].'<br>';
					//echo '복사경로: '.$dir.'/'.$uploaded[$j]['upfile_name'].'<br>';
					//echo '파일_IDX: '.$uploaded[$j]['upfile_fle_idx'].'<br>';


					//처음 등록된 파일 가져와서 . 기준으로 자른 후 특정번호로 만들기. (저장 방벙을 폴더별로 분리하고나서 필요없어짐.)
					//$file_split = explode(".",$uploaded[$j]['upfile_name']);
					//$file_name = $file_split[0].'_'.$i.$j.'.'.$file_split[1];
					//echo '카피할 고유 파일명: '.$file_split[0].'_'.$i.$j.'.'.$file_split[1].'<br>';

					//copy 서버에 파일생성. (원본,복사)
					copy( $dir2.'/'.$uploaded[$j]['upfile_name'],$dir.'/'.$uploaded[$j]['upfile_name'] );

					// 업로드 한후 ,퍼미션을 변경함 (폴더 사용권한 close)
					@chmod($dir2.'/'.$uploaded[$j]['upfile_name'], G5_FILE_PERMISSION);

					//if( file_exists( $dir2.'/'.$uploaded[$j]['upfile_name']) ){
					//	echo '원본 파일있음<br>';
					//	
					//	if( file_exists($dir2.'/'.$uploaded[$j]['upfile_name']) ){
					//		echo '복사성공<br>';
					//	}else{
					//		echo '복사실패<br>';
					//	}
					//}else{
					//	echo '원본 파일없음<br>';
					//}
					
					//0번째 입력된 파일정보 추출하기.
					$file0 = sql_fetch( "SELECT * FROM {$g5['file_table']} WHERE mb_id = '{$member['mb_id']}' AND fle_db_id = '{$first_id['cam_idx']}' AND fle_name_orig = '{$_FILES[$fle_type1.'_file']['name'][$j]}' AND fle_sort = '{$j}' ");
					
					//DB에 입력하기.
					$fle_sql = " INSERT INTO {$g5['file_table']} SET
									mb_id='".$file0['mb_id']."'
									, fle_db_table='".$file0['fle_db_table']."'
									, fle_db_id='".$cam_idx."'
									, fle_type='".$file0['fle_type']."'
									, fle_host='".$file0['fle_host']."'
									, fle_path='/data/campaign_img/{$cam_idx}'
									, fle_name='".$file0['fle_name']."'
									, fle_name_orig='".$file0['fle_name_orig']."'
									, fle_width='".$file0['fle_width']."'
									, fle_height='".$file0['fle_height']."'
									, fle_content='".$file0['fle_content']."'
									, fle_password='".$file0['fle_password']."'
									, fle_down_level='".$file0['fle_down_level']."'
									, fle_down_max='".$file0['fle_down_max']."'
									, fle_expire_date='".$file0['fle_expire_date']."'
									, fle_sort='".$file0['fle_sort']."'
									, fle_mime_type='".$file0['fle_mime_type']."'
									, fle_filesize='".$file0['fle_filesize']."'
									, fle_token='".$file0['fle_token']."'
									, fle_status='".$file0['fle_status']."' 
									, fle_reg_dt='".G5_TIME_YMDHIS."'
							";
					sql_query($fle_sql);					
				}
			};
			
			// 태그 수정 & 입력 START ******************
			$tag_text = $cam_idx.'_kafain';  
			
			if($tag_text != ''){
				echo 'tag_text = '.$tag_text. '<br>';
				$tag_text_array = explode("#",$tag_text); // 테그입력 #으로 분할
				
				foreach(array_filter($tag_text_array) as $tag) {
					$trm1 = sql_fetch(" SELECT trm_idx,trm_name FROM {$g5['term_table']} WHERE trm_taxonomy = 'campaign_tag' AND trm_name = '".trim($tag)."' ");
					$tag_split = trim($tag);
					
					// 삭제를 위해서 배열을 생성
					//echo $trm1['trm_idx'].'-'.$trm1['trm_name'].'<br>';
					$trm_exist_array .= ','.$trm1['trm_idx'];
							
					if(!$trm1['trm_idx']) {	//term 없으면 입력.
						//echo $trm1['trm_idx'].''.$tag_split.'aaa <br>';
						if(ISSET($tag_split)){
							$sql = "INSERT INTO  {$g5['term_table']} SET trm_idx_parent = '0', trm_country = 'ko_KR', trm_name = '{$tag_split}', trm_taxonomy = 'campaign_tag', trm_status = 'ok', trm_reg_dt = '".G5_TIME_YMDHIS."' ";						
							sql_query($sql);
							
							$trm_idx2 = sql_insert_id();
							
							$sql2 = " INSERT INTO  {$g5['term_relation_table']} SET trm_idx = '{$trm_idx2}', tmr_db_table = 'campaign', tmr_db_key = 'campaign_tag', tmr_db_id = '{$cam_idx}', tmr_reg_dt = '".G5_TIME_YMDHIS."' ";
							sql_query($sql2);
						}
					}
					//term 있으면 입력.
					else {
						if(ISSET($tag_split)){
							//echo $trm1['trm_idx'].''.$tag_split.''.$cam_idx.'bbb <br>';
							$trm2 = sql_fetch(" SELECT trm_idx FROM {$g5['term_relation_table']} WHERE tmr_db_key = 'campaign_tag' AND trm_idx = '{$trm1['trm_idx']}' AND tmr_db_id = '{$cam_idx}' ");
							
							if(!$trm2['trm_idx']){ 	//term_relation 없으면 입력.
								$sql3 = " INSERT INTO  {$g5['term_relation_table']} SET trm_idx = '{$trm1['trm_idx']}', tmr_db_table = 'campaign', tmr_db_key = 'campaign_tag', tmr_db_id = '{$cam_idx}', tmr_reg_dt = '".G5_TIME_YMDHIS."' ";
								sql_query($sql3);
							}
						}
					}
				}
							
				// 기존에는 있었는데 삭제된 태그들 제거
				//echo substr($trm_exist_array,1);
				if(substr($trm_exist_array,1)) {
					sql_query(" DELETE FROM {$g5['term_relation_table']} 
								WHERE tmr_db_table = 'campaign' 
									AND tmr_db_key = 'campaign_tag'
									AND tmr_db_id = '".$cam_idx."'
									AND trm_idx NOT IN (".substr($trm_exist_array,1).") ");
				}
			}
			// 태그 수정 & 입력 END ******************
			
		};//배열 끝	
	};
	//캠페인 1개등록 할때.
	if($cam_auto_make_yn == '0'){
		$sql = " insert into {$g5['campaign_table']}
					set pdo_idx = '{$pdo_idx}',
						cam_type = '{$cam_type}',
						cam_reviewer_yn = '{$cam_reviewer_yn}',
						mb_id_company = '{$mb_id_company}',
						com_idx = '{$com_idx2}',
						cam_prd_name = '{$cam_prd_name}',
						mb_id_saler = '{$mb_id_saler}',
						cam_mb_saler = '{$cam_mb_saler}',
						trm_idx_cat1 = '{$trm_idx_cat1}',
						trm_idx_cat2 = '{$trm_idx_cat2}',
						trm_idx_cat3 = '{$trm_idx_cat3}',
						trm_idx_salesarea = '{$trm_idx_salesarea}',
						cam_auto_make_yn = '{$cam_auto_make_yn}',
						cam_channels = '{$cam_channels}',
						cam_prd_time = '{$cam_prd_time}',
						cam_mb_name = '{$cam_mb_name}',
						cam_mb_tel = '{$cam_mb_tel}',
						cam_mb_email = '{$cam_mb_email}',
                        cam_name = '{$cam_name}',
                        com_naver_place_url = '{$com_naver_place_url}',
						cam_brief = '{$cam_brief}',
						cam_recruit_count = '{$cam_recruit_count}',
						mb_id_info = '{$member['mb_id']}',
						cam_info_reg_dt = '".G5_TIME_YMDHIS."',
						cam_recruit_start_dt = '{$cam_recruit_start_dt}',
						cam_recruit_end_dt = '{$cam_recruit_end_dt}',
						cam_notice_dt = '{$cam_notice_dt}',
						cam_review_start_dt = '{$cam_review_start_dt}',
						cam_review_end_dt = '{$cam_review_end_dt}',
						cam_best_select_dt = '{$cam_best_select_dt}',
						cam_notice_status = 'pending',
						cam_point_type = '{$cam_point_type}',
						cam_best_use_yn = '{$cam_best_use_yn}',
						cam_reviewer_point = '{$cam_reviewer_point}',
						cam_best_point = '{$cam_best_point}',
						cam_head_content = '{$cam_head_content}',
						cam_tags = '{$cam_tags}',
						cam_content = '{$cam_content}',
						cam_reg_dt = '".G5_TIME_YMDHIS."',
						cam_status = '{$cam_status}' ";
						
		sql_query($sql); 	
		$cam_idx = sql_insert_id();//table 마지막 생성된 id 값 가져오기 
		
		//campaign_table에 다시회차 사용할 cam_idx_parent에 자기자신 아이디값으로 업데이트하기.
		$sql2 = " UPDATE {$g5['campaign_table']} SET  cam_idx_parent = '{$cam_idx}' WHERE cam_idx = '{$cam_idx}' ";
		sql_query($sql2);
					
		$tag_text = $cam_idx.'_kafain'; 
				
		// Campaign - Term relation SNS 정보 업데이트 S
		if( sizeof($sns_channel) ) {
			for($j=0;$j<sizeof($sns_channel);$j++) {
				//echo $sns_channel[$j].'/'.$cam_idx.'<br>';
				//-- 기존 디비 삭제를 위해 배열 미리 생성 --//
				$sns_channel_array[] = $sns_channel[$j];
				
				// term_relation 정보 업데이트 (있으면 수정, 없으면 추가)
				term_relation_update(array('tmr_db_table'=>'campaign'
												,'tmr_db_key'=>'channel'
												,'trm_idx'=>$sns_channel[$j]
												,"tmr_db_id"=>$cam_idx
												,"dup_permit"=>1
				));
			}
		
			// 삭제(해제)된 항목들을 관련 디비 전부 제거함
			$del_where = (sizeof($sns_channel_array))? " AND trm_idx NOT IN (".implode(",",$sns_channel_array).") ":"";
			$sql = " DELETE FROM {$g5['term_relation_table']} WHERE tmr_db_id='{$cam_idx}' ".$del_where." ";
			sql_query($sql);
		}
		// Campaign - Term relation SNS 정보 업데이트 E	
		
	};
    
	
	//메일발송
	if($cam_status == 'pending'){
		
		$cam_prd_time_auto = $cam_prd_time.' ~ '.$pdo_prd_times;
		
		//캠페인 자동등록 할때.
		if($cam_auto_make_yn == '1'){
			$subject = $setting['set_auto_campaign_pending_email_subject'];
			$subject = preg_replace("/{회차}/", $cam_prd_time_auto, $subject);
		}else{
			$subject = $setting['set_campaign_pending_email_subject'];
			$subject = preg_replace("/{회차}/", $cam_prd_time, $subject);
		}
				
		$subject = preg_replace("/{상품명}/", $cam_prd_name, $subject);
		$subject = preg_replace("/{캠페인명}/", $cam_name, $subject);
		$subject = preg_replace("/{캠페인번호}/", $cam_idx, $subject);
		$subject = preg_replace("/{신청모집일}/", substr($cam_recruit_start_dt,0,10), $subject);
		$subject = preg_replace("/{업체아이디}/", $mb_id_company, $subject);
		$subject = preg_replace("/{이메일}/", $cam_mb_email, $subject);
		$subject = preg_replace("/{업체명}/", $com_name2, $subject);
		$subject2 = $subject;
		
		//캠페인 자동등록 할때.
		if($cam_auto_make_yn == '1'){
			$content = $setting['set_auto_campaign_pending_email_content'];
			$content = preg_replace("/{회차}/", $cam_prd_time_auto, $content);
		}else{
			$content = $setting['set_campaign_pending_email_content'];
			$content = preg_replace("/{회차}/", $cam_prd_time, $content);
		}
		
		$content = preg_replace("/{상품명}/", $cam_prd_name, $content);
		$content = preg_replace("/{업체명}/", $com_name2, $content);
		$content = preg_replace("/{담당자}/", $mb_id_saler, $content);
		$content = preg_replace("/{캠페인명}/", $cam_name, $content);
		$content = preg_replace("/{캠페인번호}/", $cam_idx, $content);
		$content = preg_replace("/{신청모집일}/", substr($cam_recruit_start_dt,0,10), $content);
		$content = preg_replace("/{업체아이디}/", $mb_id_company, $content);
		$content = preg_replace("/{이메일}/", $cam_mb_email, $content);
		$content = preg_replace("/{HOME_URL}/", '<a href="'.G5_URL.'">'.G5_URL.'</a>', $content);
		$content = preg_replace("/{DATA_READ_URL}/", '<a href="'.G5_USER_URL.'/k/campaign_form.php?w=u&cam_idx='.$cam_idx.'&pdo_idx='.$pdo_idx.'" style="color:white;">캠페인보기</a>', $content);		
		$content2 = $content;
		
		//(관리자)
		if( strpos($subject, '{관리자}') !== false ){
			$subject = preg_replace("/{관리자}/", '', $subject);
			$subject = preg_replace("/{담당자}/", '', $subject);
			mailer($config['cf_admin_email_name'], $config['cf_admin_email'], 'kafain2016@naver.com', $subject, $content, 1);
		}
		//담당자(영업자)
		if( $mb_email_saler != '' && strpos($subject2, '{담당자}') !== false ){	
			$subject2 = preg_replace("/{담당자}/", '', $subject2);
			$subject2 = preg_replace("/{관리자}/", '', $subject2);
			mailer($config['cf_admin_email_name'], $config['cf_admin_email'], $cam_mb_email, $subject2, $content2, 2);
		}
	}

}
else if ($w == 'u') {
		
	$cam_period = " cam_recruit_start_dt = '{$cam_recruit_start_dt}',
							cam_recruit_end_dt = '{$cam_recruit_end_dt}',
							cam_notice_dt = '{$cam_notice_dt}',
							cam_review_start_dt = '{$cam_review_start_dt}',
							cam_review_end_dt = '{$cam_review_end_dt}',
							cam_best_select_dt = '{$cam_best_select_dt}' ";
		
	//term_relation 선택된 cam_idx 삭제 
	//mb_id_info = '{$member['mb_id']}' => 나중에 mb_id_info 정보가 term_relation 남겨서 히스토리남기는 방법으로 변경됨. - doya -
	//$sql1 = " DELETE FROM  {$g5['term_relation_table']} WHERE tmr_db_table='campaign' AND tmr_db_key='channel' AND tmr_db_id = '{$cam_idx}' ";	
	//sql_query($sql1);	
	
    $sql = " update {$g5['campaign_table']}
                set	cam_type = '{$cam_type}',
                    cam_reviewer_yn = '{$cam_reviewer_yn}',
					com_idx = '{$com_idx2}',
					mb_id_company = '{$mb_id_company}',
                    cam_prd_name = '{$cam_prd_name}',
                    mb_id_saler = '{$mb_id_saler}',
                    cam_mb_saler = '{$cam_mb_saler}',
					trm_idx_cat1 = '{$trm_idx_cat1}',
					trm_idx_cat2 = '{$trm_idx_cat2}',
					trm_idx_cat3 = '{$trm_idx_cat3}',
					trm_idx_salesarea = '{$trm_idx_salesarea}',
					cam_auto_make_yn = '{$cam_auto_make_yn}',
					cam_channels = '{$cam_channels}',
					cam_mb_name = '{$cam_mb_name}',
					cam_mb_tel = '{$cam_mb_tel}',
					cam_mb_email = '{$cam_mb_email}',
                    cam_name = '{$cam_name}',
                    com_naver_place_url = '{$com_naver_place_url}',
					cam_brief = '{$cam_brief}',
					cam_recruit_count = '{$cam_recruit_count}',
					mb_id_info = '{$member['mb_id']}',
					cam_info_reg_dt = '".G5_TIME_YMDHIS."',
					".$cam_period."	,
					cam_point_type = '{$cam_point_type}',
					cam_best_use_yn = '{$cam_best_use_yn}',
					cam_reviewer_point = '{$cam_reviewer_point}',
					cam_best_point = '{$cam_best_point}',
					cam_head_content = '{$cam_head_content}',
					cam_tags = '{$cam_tags}',
					cam_content = '{$cam_content}',
					cam_status = '{$cam_status}'
              where cam_idx = '$cam_idx' ";	
	sql_query($sql,1);
	//echo $sql;
	//exit;
	
	
	// Campaign - Term relation SNS 정보 업데이트 S
	if( sizeof($sns_channel) ) {
		for($j=0;$j<sizeof($sns_channel);$j++) {
			//echo $sns_channel[$j].'/'.$cam_idx.'<br>';
			//-- 기존 디비 삭제를 위해 배열 미리 생성 --//
			$sns_channel_array[] = $sns_channel[$j];
			
			// term_relation 정보 업데이트 (있으면 수정, 없으면 추가)
			term_relation_update(array('tmr_db_table'=>'campaign'
											,'tmr_db_key'=>'channel'
											,'trm_idx'=>$sns_channel[$j]
											,"tmr_db_id"=>$cam_idx
											,"dup_permit"=>1
			));
		}
	
		// 삭제(해제)된 항목들을 관련 디비 전부 제거함
		$del_where = (sizeof($sns_channel_array))? " AND trm_idx NOT IN (".implode(",",$sns_channel_array).") ":"";
		$sql = " DELETE FROM {$g5['term_relation_table']} WHERE tmr_db_id='{$cam_idx}' ".$del_where." ";
		sql_query($sql);
	}
	// Campaign - Term relation SNS 정보 업데이트 E	
	
	//------sns 체널 입력 미사용------.
	//foreach(array_filter($sns_ar) as $sns){
	//	//echo "sns: ".$sns."</br>";
	//	if(ISSET($sns)){
	//		$sql2 = "INSERT INTO  {$g5['term_relation_table']} set trm_idx='{$sns}', tmr_db_table='campaign', tmr_db_key='channel', tmr_db_id = '{$cam_idx}', tmr_reg_dt = '".G5_TIME_YMDHIS."' ";
	//	}
	//	sql_query($sql2);
	//}

	//일괄수정
	if(	$cam_auto == '1' ) {	
		//처음값은 위에서 +1한 값으로 루프돌리기.
		$cam_prd_time_p = $cam_prd_time + 1;
		
		//echo $cam_prd_time.'<br>';
		//echo $pdo_prd_times.'<br>';
		
		for($i = $cam_prd_time_p ; $i <= $pdo_prd_times ; $i++){			
			//등록할 캠페인 추출하기.
			$cam = sql_fetch(" SELECT * FROM {$g5['campaign_table']} WHERE pdo_idx = '".$pdo_idx."' AND cam_prd_time = '".number_format($i-1)."' ");
			
			//echo $cam_prd_time_p.'<br>';			
			//echo " SELECT * FROM {$g5['campaign_table']} WHERE pdo_idx = '".$pdo_idx."' AND cam_prd_time = '".number_format($i-1)."' <br>";			
				
			//자동등록에 시작할 날짜 설정하기. (베스트사용)
			if($cam['cam_best_use_yn'] == '1'){
				//처음 루프는 지금입력한 캠페인 시작기준은
				if( $cam_prd_time_p == $i ){
					$start_day2 = $cam_best_select_dt;
				}else{
					$start_day2 = $cam['cam_best_select_dt'];
				}
			}
			//베스트 미사용.
			else{
				//처음 루프는 지금입력한 캠페인 시작기준은
				if($cam_prd_time_p == $i){
					$start_day2 = $cam_review_end_dt;
				}else{
					$start_day2 = $cam['cam_review_end_dt'];
				}
			}
			
			//echo $start_day2.'<br>';
			
			//함수로 자동날짜 만들기.
			$cam_period2 = cam_day_auto($start_day2);
			
			//업데이트할 캠페인 추출하기.
			$cam2 = sql_fetch(" SELECT * FROM {$g5['campaign_table']} WHERE pdo_idx = '".$pdo_idx."' AND cam_prd_time = '".$i."' ");
			
			//업데이트하기.
			$sql2 = " UPDATE {$g5['campaign_table']} SET ".$cam_period2." WHERE cam_idx = '".$cam2['cam_idx']."' ";
			sql_query($sql2,1);
			
			//echo $sql2.'<br>';
		}
	}
	
	//메일발송	
	//재접수 (관라자만 받음.)
	if($cam_status == 're_pending'){
	
		$subject = $setting['set_cam_status_re_pending_email_subject'];
		$subject = preg_replace("/{회차}/", $cam_prd_time, $subject);
		$subject = preg_replace("/{상품명}/", $cam_prd_name, $subject);
		$subject = preg_replace("/{캠페인명}/", $cam_name, $subject);
		$subject = preg_replace("/{신청모집일}/", substr($cam_recruit_start_dt,0,10), $subject);
		$subject = preg_replace("/{업체아이디}/", $mb_id_company, $subject);
		$subject = preg_replace("/{이메일}/", $cam_mb_email, $subject);
		$subject2 = $subject;
		
		$content = $setting['set_cam_status_re_pending_email_content'];
		$content = preg_replace("/{회차}/", $cam_prd_time, $content);
		$content = preg_replace("/{상품명}/", $cam_prd_name, $content);
		$content = preg_replace("/{캠페인명}/", $cam_name, $content);
		$content = preg_replace("/{신청모집일}/", substr($cam_recruit_start_dt,0,10), $content);
		$content = preg_replace("/{업체아이디}/", $mb_id_company, $content);
		$content = preg_replace("/{이메일}/", $cam_mb_email, $content);	
		$content = preg_replace("/{HOME_URL}/", '<a href="'.G5_URL.'">'.G5_URL.'</a>', $content);
		$content2 = $content;
		
		//(관리자)
		if( strpos($subject, '{관리자}') !== false ){
			$subject = preg_replace("/{관리자}/", '', $subject);
			$subject = preg_replace("/{담당자}/", '', $subject);
			mailer($config['cf_admin_email_name'], $config['cf_admin_email'], 'kafain2016@naver.com', $subject, $content, 1);
		}
		//담당자(영업자)
		if( $mb_email_saler != '' && strpos($subject2, '{담당자}') !== false ){
			$subject2 = preg_replace("/{담당자}/", '', $subject2);
			$subject2 = preg_replace("/{관리자}/", '', $subject2);
			mailer($config['cf_admin_email_name'], $config['cf_admin_email'], $cam_mb_email, $subject2, $content2, 2);
		}
	}
	
//exit;
}

//캠페인 1개만 등록할때 / 수정할때.
if($cam_auto_make_yn == '0' || $w == 'u'){
	// 파일 처리1 (파일 타입이 여러개면 일련번호 붙여서 확장해 주세요.) ----------------	
	$fle_type1 = "campaign_img";
	for($i=0;$i<count($_FILES[$fle_type1.'_file']['name']);$i++) {
		// 삭제인 경우
		if (${$fle_type1.'_del'}[$i] == 1) {
			if($mb_id) {
				delete_jt_file(array("fle_db_table"=>"campaign", "fle_db_id"=>$cam_idx, "fle_type"=>$fle_type1, "fle_sort"=>$i, "fle_delete"=>1));
			}
			else {
				// fle_db_id를 던져서 바로 삭제할 수도 있고 $fle_db_table, $fle_db_id, $fle_token 를 던져서 삭제할 수도 있음
				delete_jt_file(array("fle_db_table"=>"campaign"
									,"fle_db_id"=>$cam_idx
									,"fle_type"=>$fle_type1
									,"fle_sort"=>$i
									,"fle_delete"=>1
				));
			}
		}
		// 파일 등록
		if ($_FILES[$fle_type1.'_file']['name'][$i]) {
			$upfile_info = upload_jt_file(array("fle_idx"=>$fle_idx
								,"mb_id"=>$member['mb_id']
								,"fle_src_file"=>$_FILES[$fle_type1.'_file']['tmp_name'][$i] //파일이름.
								,"fle_orig_file"=>$_FILES[$fle_type1.'_file']['name'][$i] //원본 파일명.
								,"fle_mime_type"=>$_FILES[$fle_type1.'_file']['type'][$i] //이미지 타입정보.
								,"fle_content"=>$fle_content
								,"fle_path"=>'/data/campaign_img/'.$cam_idx		//<---- 저장 디렉토리
								,"fle_db_table"=>"campaign"
								,"fle_db_id"=>$cam_idx
								,"fle_type"=>$fle_type1
								,"fle_sort"=>$i
							));
			//print_r2($upfile_info);
		}
	}
    // 압축파일 해제(수정) pkw
	if ($_FILES[$fle_type1.'_file']['name'][4]) {
		
		$zip_info = pathinfo($_FILES[$fle_type1.'_file']['name'][4]);
		$extract_dir = G5_DATA_PATH.'/campaign_img/'.$cam_idx.'/'.$zip_info['filename'];
		
		$archive = new PclZip(G5_DATA_PATH.'/campaign_img/'.$cam_idx.'/'.$_FILES[$fle_type1.'_file']['name'][4]);
		$archive->extract(PCLZIP_OPT_PATH, $extract_dir);
		@chmod($extract_dir, G5_DIR_PERMISSION);
		
		zip_dir($extract_dir);
	}

	// 태그 수정 & 입력 START ******************	
	$tag_text_array = explode("#",$tag_text); // 테그입력 #으로 분할

	foreach(array_filter($tag_text_array) as $tag) {
		$trm1 = sql_fetch(" SELECT trm_idx,trm_name FROM {$g5['term_table']} WHERE trm_taxonomy = 'campaign_tag' AND trm_name = '".trim($tag)."' ");
		$tag_split = trim($tag);
		
		// 삭제를 위해서 배열을 생성
		//echo $trm1['trm_idx'].'-'.$trm1['trm_name'].'<br>';
		$trm_exist_array .= ','.$trm1['trm_idx'];
				
		if(!$trm1['trm_idx']) {	//term 없으면 입력.
			//echo $trm1['trm_idx'].''.$tag_split.'aaa <br>';
			if(ISSET($tag_split)){
				$sql = "INSERT INTO  {$g5['term_table']} SET trm_idx_parent = '0', trm_country = 'ko_KR', trm_name = '{$tag_split}', trm_taxonomy = 'campaign_tag', trm_status = 'ok', trm_reg_dt = '".G5_TIME_YMDHIS."' ";						
				sql_query($sql);
				
				$trm_idx2 = sql_insert_id();
				
				$sql2 = " INSERT INTO  {$g5['term_relation_table']} SET trm_idx = '{$trm_idx2}', tmr_db_table = 'campaign', tmr_db_key = 'campaign_tag', tmr_db_id = '{$cam_idx}', tmr_reg_dt = '".G5_TIME_YMDHIS."' ";
				sql_query($sql2);
			}
		}
		//term 있으면 입력.
		else {
			if(ISSET($tag_split)){
				//echo $trm1['trm_idx'].''.$tag_split.''.$cam_idx.'bbb <br>';
				$trm2 = sql_fetch(" SELECT trm_idx FROM {$g5['term_relation_table']} WHERE tmr_db_key = 'campaign_tag' AND trm_idx = '{$trm1['trm_idx']}' AND tmr_db_id = '{$cam_idx}' ");
				
				if(!$trm2['trm_idx']){ 	//term_relation 없으면 입력.
					$sql3 = " INSERT INTO  {$g5['term_relation_table']} SET trm_idx = '{$trm1['trm_idx']}', tmr_db_table = 'campaign', tmr_db_key = 'campaign_tag', tmr_db_id = '{$cam_idx}', tmr_reg_dt = '".G5_TIME_YMDHIS."' ";
					sql_query($sql3);
				}
			}
		}
	}
				
	// 기존에는 있었는데 삭제된 태그들 제거
	//echo substr($trm_exist_array,1);
	if(substr($trm_exist_array,1)) {
		sql_query(" DELETE FROM {$g5['term_relation_table']} 
					WHERE tmr_db_table = 'campaign' 
						AND tmr_db_key = 'campaign_tag'
						AND tmr_db_id = '".$cam_idx."'
						AND trm_idx NOT IN (".substr($trm_exist_array,1).") ");
	}
	// 태그 수정 & 입력 END ******************
}

	
// 사용자 코드 실행
@include_once ($member_skin_path.'/register_form_update.tail.skin.php');
/*
unset($_SESSION['ss_cert_hash']);
unset($_SESSION['ss_cert_birth']);
unset($_SESSION['ss_cert_adult']);
*/

//내용 변수 삭제.
unset($cam_content);

if ($w == '') {	
	goto_url( G5_USER_URL."/k/campaign_list.php" );
}
else{
	echo '<script> alert("회원 정보가 수정 되었습니다.")</script>';
	goto_url( G5_USER_URL."/k/campaign_form.php?w=u&cam_review_k={$cam_review_k}&cam_review_f={$cam_review_f}&cam_review_i={$cam_review_i}&cam_review_p={$cam_review_p}&cam_idx={$cam_idx}&pdo_idx={$pdo_idx}&mb_id={$mb_id_company}" );	
}


?>
