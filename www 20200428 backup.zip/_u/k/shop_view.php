<?php
include_once('./_common.php');
// 헤더 부분
include_once(G5_PATH.'/_head.php');

$sql = " SELECT cam.*
			, com.com_name,com.com_addr1 ,com.com_addr2 ,com.com_latitude ,com.com_longitude ,com.trm_idx_salesarea, com.com_manager_hp
			, ( SELECT pdo_prd_name FROM {$g5['product_order_table']} WHERE pdo_idx = cam.pdo_idx ) AS pdo_prd_name
			, ( SELECT GROUP_CONCAT( CAST(trm_idx AS CHAR) ORDER BY tmr_sort) FROM {$g5['term_relation_table']} 
			WHERE tmr_db_table = 'campaign' AND tmr_db_key = 'channel' AND tmr_db_id = cam.cam_idx ) AS cam_channels
			, ( SELECT GROUP_CONCAT(CONCAT(mta_key, '=', COALESCE(mta_value, 'NULL')) ) FROM {$g5['meta_table']} 
				WHERE mta_db_table = 'campaign' AND mta_db_id = cam.cam_idx ) AS mbr_metas
			, ( SELECT GROUP_CONCAT( CONCAT(
					'fle_type=', fle_type, '^'
					,'fle_sort=', CAST(fle_sort AS CHAR), '^'
					,'fle_path=', fle_path, '^'
					,'fle_name=', fle_name
					) ORDER BY fle_sort, fle_reg_dt DESC ) FROM {$g5['file_table']} 
				WHERE fle_db_table = 'campaign' AND fle_db_id = cam.cam_idx ) AS fle_files
			FROM {$g5['campaign_table']} AS cam
				LEFT JOIN {$g5['company_table']} AS com ON com.com_idx = cam.com_idx
			WHERE cam_idx = '{$cam_idx}' ";
$cam = sql_fetch($sql,1);
//echo $sql;

$readonly = ($w=='u') ? 'readonly' : '';

//campaign_form.skin.php 슬라이드 이미지 부분에서 사용됨.
$sql = "SELECT * FROM {$g5['file_table']} 
		WHERE fle_db_table = 'campaign' AND fle_db_id = '".$cam['cam_idx']."' AND fle_name_orig NOT LIKE('%.zip') ORDER BY fle_sort, fle_reg_dt DESC ";
$rs1 = sql_query($sql,1);





//사내 캠페인. 파일 다운로드 만들기.
if( $cam['cam_nct'] == '1' ){
	// 관련 파일(post_file) 추출
	$sql = "SELECT fle_name_orig, fle_path, fle_name  FROM {$g5['file_table']} WHERE fle_db_table = 'campaign' AND fle_db_id = '{$cam['cam_idx']}' AND fle_sort = 4";
	$cam_file = sql_fetch($sql);
	$receipt_dir = pathinfo($cam_file['fle_name_orig'])['filename'];
	
	$sql = "SELECT cma_receipt FROM {$g5['campaign_apply_table']} WHERE cam_idx = '{$cam['cam_idx']}' AND cma_status = 'chosen'";
	$sql .= ($is_admin == 'super') ? "" : " AND mb_id = '{$member['mb_id']}'";
	$cma_receipt = sql_fetch($sql)['cma_receipt'];
	$receipt_ext = pathinfo($cma_receipt)['extension'];

	$receipt = ($is_admin == 'super') ? 
		G5_PATH.$cam_file['fle_path'].'/'.$cam_file['file_name'] : 
		G5_DATA_PATH.'/campaign_img/'.$cam['cam_idx'].'/'.$receipt_dir.'/'.$cma_receipt;
	$cam['file_dw'] = '&nbsp;<a href="'.G5_USER_URL.'/lib/download.php?file_fullpath='.urlencode($receipt).'&file_name_orig=';
	$cam['file_dw'] .= ($is_admin == 'super') ? $cam_file['file_name'] : 'receipt.'.$receipt_ext;
	$cam['file_dw'] .= '" class="file_dw"><i class="fa fa-download" aria-hidden="true"></i> 영수증 다운로드</a>';
    // $cam['file_dw'] .= '<a href="'.G5_DATA_URL.'/campaign_img/'.$cam['cam_idx'].'/'.$receipt_dir.'/'.$cma_receipt.'" target="_blank">URL로 다운로드</a>';
    
}


//**** 타이틀 메뉴 클릭시 이동하기 만들기 S ****
//메뉴 번호 추출하기. 
$top = $category_up_idx[$cam['trm_idx_cat1']]-1;
//$sub = $category_down_idxs[$cam['trm_idx_cat1']];

//메뉴 이름,번호 분리하기. $category_top_menus => 배열.
sort($category_top_menus);
$top_menu_array = explode("^",$category_top_menus[$top]);

//1차메뉴
//echo $top_menu_array[0].'<br>';
//echo $top_menu_array[1].'<br>';
//2차메뉴
//echo $cam['trm_idx_cat1'].'<br>';
//echo $category_name[$cam['trm_idx_cat1']].'<br>';

//사내 캠페인.
if( $cam_nct == '1' ){
	$title_ck = '#사내페인';
}else{
	$title_ck = trim($top_menu_array[1]).' / '.trim($category_name[$cam['trm_idx_cat1']]);
}

//**** 타이틀 메뉴 클릭시 이동하기 만들기 E ****

$g5['title'] = $title_ck;

// 신청자전체 건수 추출		
$cam_a = sql_fetch("	SELECT count(cam_idx) AS cnt FROM {$g5['campaign_apply_table']}
						WHERE cma_status NOT IN ('trash') AND cam_idx = '".$cam['cam_idx']."' ");

//리뷰 카운트 수 (일반회원)
$rev = sql_fetch("	SELECT count(rev.cam_idx) AS cnt FROM {$g5['review_table']} AS rev 
						LEFT JOIN {$g5['campaign_apply_table']} AS cma ON cma.cma_idx = rev.cma_idx
					WHERE rev.cam_idx = '".$cam['cam_idx']."' AND rev.rev_status IN ('ok') AND cma.cma_status = 'chosen' ");
					
$rev['cnt'] = isset($rev['cnt'])?$rev['cnt']:'0';

//본인빼고 리뷰 카운트 수
$rev3 = sql_fetch("	SELECT *,count(rev_idx) AS cnt  FROM {$g5['review_table']} 
					WHERE rev_status IN ('ok') AND cam_idx = '".$cam['cam_idx']."' AND mb_id != '{$member['mb_id']}' ");		

$rev3['cnt'] = isset($rev3['cnt'])?$rev3['cnt']:'0';

// 나의 리뷰 수정에 사용할 rev_idx 추출히기	
$rev2 = sql_fetch("	SELECT * FROM {$g5['review_table']} 
					WHERE rev_status IN ('ok') AND cam_idx = '".$cam['cam_idx']."' AND mb_id = '{$member['mb_id']}' ");					
			
//캠페인에서 입력한 인스타 #tag 불러오기.
$sql2 = " SELECT trm_idx FROM {$g5['term_relation_table']} WHERE tmr_db_key = 'campaign_tag' AND tmr_db_id = '{$cam['cam_idx']}' ";
$trm1 = sql_query($sql2);					
for ($j=0; $row=sql_fetch_array($trm1); $j++){						
	$trm2 = sql_fetch(" SELECT trm_idx,trm_name FROM {$g5['term_table']} WHERE trm_taxonomy = 'campaign_tag' AND trm_idx = '{$row['trm_idx']}' ");
	$trm['trm_name'] .= $trm2['trm_name']; // 변수 값(문자열) 연결 
}				

//내 관심캠페인.
$cam_wish = sql_fetch(" SELECT * FROM {$g5['campaign_wish_table']} WHERE cam_idx = '{$cam['cam_idx']}' AND mb_id = '{$member['mb_id']}' ");

//등록된 UEL정보 추출하기.
$sql1 = " SELECT * FROM jt_meta WHERE mta_db_table = 'member' AND mta_key like('sns_channel_%') AND mta_value != '' AND mta_db_id != '".$member['mb_id']."' ";
$mt_result = sql_query($sql1);

for ($i=0; $row=sql_fetch_array($mt_result); $i++){ 
	$my_sns_url .= $row['mta_value'].',';
}

echo '<input type="hidden" name="my_sns_url" value="'.$my_sns_url.'">';
unset($my_sns_url);

//리뷰등록 안했으면 $mem['chosen']변수 빈값에서 값 0 으로 변경함 없으면 오류발생됨. (campaign_view_applicant.php 안에 있음)
if(!isset($mem['chosen'])){
	$mem['chosen'] = '0';
} ;
	
//리뷰신청 확인 추출하기 , u_campaign_apply 테이블에 같은 mb_id 값이 있는지 확인 ( 있으면= 1 없으면= 0 )
$apay = sql_fetch( "SELECT count(cma_idx) AS cnt FROM {$g5['campaign_apply_table']} 
						WHERE cam_idx='{$cam_idx}' AND cma_status != 'trash' AND mb_id='{$member['mb_id']}'" );	

if( $cam['cam_nct'] == '1' && $apay['cnt'] == '0' && ($member['mb_level'] == '6' || $my_cam_lv == '4' ) ){
	//사내회원 리뷰신청 카운트 추출하기 (일반 루트로 리뷰등록한 lv6 회원하고 사내캠으로 등록한 lv6하고 구분해야함).    AND isnull(cma.cma_status) => 사캠등록자만 카운트 하려면.
	$nct_rev = sql_fetch( "	SELECT count(rev_idx) AS cnt FROM {$g5['review_table']} AS rev
								LEFT JOIN {$g5['member_table']} AS mem ON mem.mb_id = rev.mb_id
								LEFT JOIN {$g5['campaign_apply_table']} AS cma ON cma.cma_idx = rev.cma_idx
							WHERE rev.cam_idx = '{$cam_idx}' AND rev.rev_status = 'ok' AND mem.mb_level = '6' AND isnull(cma.cma_status) " );				
}

$cam_review_end_dt = date("y.m.d",strtotime($cam['cam_review_end_dt']));
//echo '<br>1 : '.$cam_review_end_dt.'<br>';

//u_campaign_apply 테이블 리뷰어들 리뷰 등록가능한 날짜 추출하기.(로그인해야 보임.)
if( $member['mb_id'] ){
	$cma_reg = sql_fetch("SELECT cma_idx,cma_reg_end_dt,cma_review_yn,cma_status FROM {$g5['campaign_apply_table']} 
			WHERE cam_idx = '{$cam_idx}' AND cma_status != 'trash' AND mb_id = '{$member['mb_id']}' ");	

	$cma_reg_end_dt = date("y.m.d",strtotime($cma_reg['cma_reg_end_dt']));
	//echo '1 : '.$cma_reg_end_dt.'<br>';
	//echo '2 : '.$cma_reg['cma_status'].'<br>';
	//echo '3 : '.$cma_reg['cma_review_yn'].'<br>';
	//echo '4 : '.$cam_review_end_dt.'<br>';

	//u_campaign_apply 테이블 개인별 등록마감일로 변경하기.
	if( $cma_reg['cma_status'] == 'chosen' && $cam_review_end_dt < $cma_reg_end_dt){
		unset($cam_review_end_dt);		
		$cam_review_end_dt = $cma_reg_end_dt;
	}
	//echo '<br>5 : '.$cam_review_end_dt.'<br>';
}

// **** 신청자 S ****
$sql_common = " FROM {$g5['campaign_apply_table']} AS app ";

$sql_search1 = " WHERE cma_status NOT IN ('trash') AND cam_idx = '".$cam['cam_idx']."' AND mb_id != '".$member['mb_id']."' ";
//$sql_search2 = " WHERE cma_status NOT IN ('trash') AND cam_idx = '".$cam['cam_idx']."' AND mb_id = '".$member['mb_id']."' ";
$sql_search2 = " WHERE cma_status NOT IN ('trash') AND cam_idx = '".$cam['cam_idx']."' AND mb_id = '".$member['mb_id']."' ";//test test42
$sql_search3 = " WHERE cma_status NOT IN ('trash') AND cam_idx = '".$cam['cam_idx']."' AND cma_status = 'chosen' ";

//정렬 
if (!$sst) {
    $sst2 = "cma_reg_dt";
    $sod2 = "DESC";
}
$sql_order3 = " order by {$sst2} {$sod2} ";

$rows3 = 10;
if (!$page) $page = 1; // 페이지가 없으면 첫 페이지 (1 페이지)
$from_record3 = ($page - 1) * $rows3; // 시작 열을 구함

//신청자 한마디
$sql  = " SELECT SQL_CALC_FOUND_ROWS *
			,( SELECT CONCAT(mb_id,'^', mb_nick) FROM {$g5['member_table']} WHERE mb_id = app.mb_id ) AS mb_id_name			
        {$sql_common}
		{$sql_search1}
        {$sql_order3} LIMIT {$from_record3}, {$rows3}
		";
$result2 = sql_fetch($sql,1);
//echo $sql;

$count = sql_fetch_array( sql_query(" SELECT FOUND_ROWS() as total ") ); 
$total_count = $count['total'];
$total_page  = ceil($total_count / $rows3);  // 전체 페이지 계산

//나의 신청 한마디
$sql2  = " SELECT SQL_CALC_FOUND_ROWS *
			,( SELECT CONCAT(mb_id,'^', mb_nick) FROM {$g5['member_table']} WHERE mb_id = app.mb_id ) AS mb_id_name
        {$sql_common}
		{$sql_search2}
        {$sql_order3} LIMIT {$from_record3}, {$rows3}
		";
$mysql = sql_query($sql2,1);
$mysql2 = sql_fetch($sql2,1);

//선정된 리뷰어
$sql3  = " SELECT SQL_CALC_FOUND_ROWS *
			,( SELECT CONCAT(mb_id,'^', mb_nick) FROM {$g5['member_table']} WHERE mb_id = app.mb_id ) AS mb_id_name
        {$sql_common}
		{$sql_search3}
        {$sql_order3} LIMIT {$from_record3}, {$rows3}
		";
$pick = sql_query($sql3,1);
$pick2 = sql_fetch($sql3,1);

// **** 신청자 E ****

// **** 리뷰 S ****
//등록할 리뷰 sns 추가버튼 (신청페이지에서 등록할 sns정보 보여주기.)
$rev_sns = sql_fetch("SELECT GROUP_CONCAT( CAST(trm_idx AS CHAR) ORDER BY tmr_sort) AS rev_channels 
					FROM {$g5['term_relation_table']} AS termr
						LEFT JOIN {$g5['campaign_apply_table']}  AS cama ON cama.cma_idx = termr.tmr_db_id
					WHERE tmr_db_table = 'campaign_apply' AND tmr_db_key = 'channel' AND cma_status != 'trash' AND cam_idx = {$cam_idx} AND mb_id = '{$member['mb_id']}'",1);

//나의 리뷰 수정일때.
$sql2 = "SELECT * FROM {$g5['review_table']} AS rev
			LEFT JOIN {$g5['review_url_table']} AS revu ON revu.rev_idx = rev.rev_idx
		WHERE rev.rev_idx = '{$rev2['rev_idx']}' ";
$rev_up = sql_query($sql2,1);

$rev_up2 = sql_fetch("SELECT * FROM {$g5['review_table']} WHERE rev_idx = '{$rev2['rev_idx']}'");
// **** 리뷰 E ****

// 날짜 setting
$today2 = date("Y-m-d 23:59:59", mktime(00,00,00,date("m")  , date("d"), date("Y"))); 
$today = date("y.m.d");
$cam_recruit_start_dt = date("y.m.d",strtotime($cam['cam_recruit_start_dt']));
$cam_recruit_end_dt = date("y.m.d",strtotime($cam['cam_recruit_end_dt']));
$cam_notice_dt = date("y.m.d",strtotime($cam['cam_notice_dt']));
$cam_review_start_dt = date("y.m.d",strtotime($cam['cam_review_start_dt']));
$cam_best_select_dt = date("y.m.d",strtotime($cam['cam_best_select_dt']));	

//블로그 RSS(로컬test는 않됨.)
if( $member['naver_login'] && $_SERVER['HTTP_HOST'] != 'localhost'){
	$cam['naver_title_option'] = naver_blog_list2($member['naver_login']);
}

//한번 신청한 캠페인은 다시회차,다음회차 캠페인에서 신청 안되도록 하기. (선옥 요청함)
if( $member['mb_id'] ){
//	$ap_ck = sql_fetch("SELECT * FROM {$g5['campaign_table']} AS cam
//							LEFT JOIN {$g5['campaign_apply_table']} AS cma ON cma.cam_idx = cam.cam_idx 
//						WHERE cam.pdo_idx = '{$cam['pdo_idx']}' AND cma.mb_id = '{$member['mb_id']}' AND cma.cma_status = 'chosen' AND cam.cam_idx != '{$cam['cam_idx']}' ");	
}

// 스킨 호출 (PC 모바일 분리), 변수 위치 정의는 _common.php 에 있음  ajw4151
include_once(G5_THEME_PATH.'/shop/shop_view.skin.php');

include_once('./_tail.php');
?>
