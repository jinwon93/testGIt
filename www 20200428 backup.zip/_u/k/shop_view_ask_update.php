<?php
include_once('./_common.php');

error_reporting(E_ALL);
ini_set("display_errors", 1);

$sql = "SELECT cam_recruit_count FROM {$g5['campaign_table']} WHERE cam_idx = {$cam_idx}";
$cam_recruit_count = sql_fetch($sql)['cam_recruit_count'];

$sql = "SELECT COUNT(*) as cnt FROM {$g5['campaign_apply_table']} WHERE cam_idx = {$cam_idx} AND cma_status = 'chosen'";
$cam_recruited_count = sql_fetch($sql)['cnt'];

$init_status = ($cam_recruited_count < $cam_recruit_count) ? "chosen" : "pending";
if ($init_status == "chosen") {
	// zip 압축푼거에서 1개 랜덤으로 가져오기
	$sql = "SELECT fle_name_orig FROM {$g5['file_table']} WHERE fle_db_table = 'campaign' AND fle_db_id = '{$cam_idx}' AND fle_sort = 4";
	$receipt_dir = pathinfo(sql_fetch($sql)['fle_name_orig'])['filename'];

	$sql = "SELECT GROUP_CONCAT(',', cma_receipt) as receipt 
			FROM {$g5['campaign_apply_table']} WHERE cam_idx = '".$cam_idx."' AND cma_status = 'chosen'";
	$receipt = sql_fetch($sql)['receipt'];
	$receipt_list = explode(',', $receipt);
	$receipt_list = array_filter($receipt_list);
	$receipt_list = array_unique($receipt_list);
	
	$assignment = null;
	$receipt_path = G5_DATA_PATH.'/campaign_img/'.$cam_idx.'/'.$receipt_dir;
	$handle = opendir($receipt_path);
	while($file = readdir($handle)) {
		if ($file != '.' && $file != '..') {
			if (in_array($file, $receipt_list))
				continue;
			else {
				$assignment = $file;
				break;
			}
		}
	}
	$sql_receipt = ", cma_receipt = '{$assignment}'";
}


//$count = count($_POST['chk']);
//if (!$count)
//	alert($_POST['act_button']." 하나 이상 체크하세요.");

/*
echo 'sns_channel_46 :'.$sns_channel_46.'<br>';
echo 'sns_channel_47 :'.$sns_channel_47.'<br>';
echo 'sns_channel_48 :'.$sns_channel_48.'<br>';
echo 'sns_channel_49 :'.$sns_channel_49.'<br>';

$sns_ar = array($sns_channel_46,$sns_channel_47,$sns_channel_48,$sns_channel_49);
$sns_url = array($sns_channel_46_url,$sns_channel_47_url,$sns_channel_48_url,$sns_channel_49_url);

$sns_ar = array_filter($sns_ar);
$sns_url = array_filter($sns_url);

print_r2($sns_ar);
print_r2($sns_url);

foreach(array_filter($sns_ar) as $sns){	
	if(ISSET($sns)){
		echo 'sns :'.$sns.'<br>';
	}
}
for($i = 0; $i < count($sns_url); $i++){
	if($sns_url[$i]){
		echo 'sns1 :'.$sns_url[$i].'<br>';
	}
}
exit;
*/

//번지 분리작업
$cma_zip1 = substr($_POST['cma_zip'], 0, 3);
$cma_zip2 = substr($_POST['cma_zip'], 3);

//주소 분리작업.
$cma_addr2 = strstr($cma_addr1,'(');

	if( $member['mb_addr1'] == ''){
		$sql = "UPDATE {$g5['member_table']} SET 
					mb_zip1 = '{$cma_zip1}'
					, mb_zip2 = '{$cma_zip2}'
					, mb_addr1 = '{$cma_addr1}'
					, mb_addr2 = '{$cma_addr2}'
					, mb_addr3 = '{$cma_addr3}'
					, mb_addr_jibeon = '{$cma_jibeon}' 
				WHERE mb_id = '{$mb_id}' ";
		sql_query($sql, true);
	}
	
	// cma_reg_end_dt 값은 마지막에 진행 중인 캠페인 cam_status 상태값(ok-완료)을 변경하기위한 기준값 
	// insert
	$sql = "INSERT INTO  {$g5['campaign_apply_table']} set
				cam_idx='{$cam_idx}',
				mb_id='{$mb_id}',
				cma_content='{$cma_content}',
				cma_reg_end_dt='{$cam_review_end_dt}',
				cma_addr1='{$cma_addr1}',
				cma_addr2='{$cma_addr2}',
				cma_addr3='{$cma_addr3}',
				cma_zip1='{$cma_zip1}',
				cma_zip2='{$cma_zip2}',
				cma_jibeon='{$cma_jibeon}',
				cma_status='{$init_status}',
				cma_reg_dt = '".G5_TIME_YMDHIS."'
				{$sql_receipt}";
	//echo $sql;
	sql_query($sql, true);
	$cma_idx = sql_insert_id();//campaign_apply_table 마지막 생성된 id 값 가져오기
	
	//SNS. 캠페인테이블에 마지막 생성된 cma_idx 값 가져오기.
	
	$sns_ar = array($sns_channel_46, $sns_channel_47, $sns_channel_48, $sns_channel_49, $sns_channel_50,$sns_channel_51);
	$sns_url = array($sns_channel_46_url,$sns_channel_47_url,$sns_channel_48_url,$sns_channel_49_url,$sns_channel_50_url,$sns_channel_51_url);

	for($i = 0; $i < count($sns_ar); $i++){
		if($sns_ar[$i]){
			$sql2 = "INSERT INTO  {$g5['term_relation_table']} set trm_idx='{$sns_ar[$i]}', tmr_db_table='campaign_apply', tmr_db_key='channel', tmr_db_id = '{$cma_idx}', tmr_reg_dt = '".G5_TIME_YMDHIS."' ";
			sql_query($sql2);
		}

		if($sns_url[$i]){
			meta_update(array("mta_db_table"=>"member","mta_db_id"=>$mb_id,"mta_key"=>"sns_channel_".$sns_ar[$i]."_url","mta_value"=>$sns_url[$i]));
		}
}



/*if ($_FILES['bf_file']['name'][1]!='') {
$org = $_FILES['bf_file']['name'][1];
$ext = end(explode(".",$org));

if (preg_match("/zip/i", $ext) === 1) {
    // 압축해제할 폴더명은 압축파일에서 .zip를 땐 이름
    $extract_dir = G5_DATA_PATH.'/file/'.$file_table.'/'.preg_replace("/.{$ext}/i", '', $upload[1]['file']);
    if (is_file(G5_DATA_PATH.'/file/'.$file_table.'/'.$upload[1]['file'])) {
        $archive = new PclZip(G5_DATA_PATH.'/file/'.$file_table.'/'.$upload[1]['file']);
        
        //해당 위치에 압축파일을 풀어줌
        $result = $archive->extract(PCLZIP_OPT_PATH, $extract_dir);
        @chmod($extract_dir, G5_DIR_PERMISSION);
        
        // 압축 파일 내용 배열 (이미지 원본 정보들)
        //$archive_list = $archive->listContent();
        //print_r2($archive_list);
        
        // 아래 문자열에 있는 확장자 이외의 파일이 들어있으면 삭제
        $allowed_ext = "/jpg|jpeg|png|bmp|gif/i";
        $matches = array();
        $meta_array = array();
        
        if (is_dir($extract_dir)) {
            $handle = opendir($extract_dir);
            while ($file= readdir($handle)) {
                if ($file != "." && $file != "..") {
                    preg_match($allowed_ext, end(explode(".",$file)), $matches);
                    if (count($matches) > 0) {
                        ;
                    } else {
                        if (is_file($extract_dir."/".$file))
                            @unlink($extract_dir."/".$file);
                        else
                            delTree($extract_dir."/".$file);
                    }
                }
            }
        }
        $result_dir = scandir($extract_dir, 1);
        $result_dir = array_diff($result_dir, [".", ".."]);
        
        // 파일명 한글 & 특수문자 회피 및 혹시모를 허용되지 않은 확장자 처리
        foreach ($result_dir as $file) {
            $file = get_safe_filename($file);
            // 아래의 문자열이 들어간 파일은 -x 를 붙여서 웹경로를 알더라도 실행을 하지 못하도록 함
            $file = preg_replace("/\.(php|pht|phtm|htm|cgi|pl|exe|jsp|asp|inc|cer|cdx|asa|php3|html|htm|war|js|aspx|htaccess)/i", "$0-x", $file);
            
            $chars_array = array_merge(range(0,9), range("a","z"), range("A","Z"));
            shuffle($chars_array);
            $shuffle = implode("", $chars_array);
            
            $new_filename = abs(ip2long($_SERVER['REMOTE_ADDR'])).'_'.substr($shuffle,0,8).'_'.replace_filename($file);
            @rename($extract_dir."/".$file, $extract_dir."/".$new_filename);
            
            $timg = @getimagesize($extract_dir."/".$new_filename);
            // image type
            if ( preg_match("/\.({$config['cf_image_extension']})$/i", $extract_dir."/".$new_filename) ||
                    preg_match("/\.({$config['cf_flash_extension']})$/i", $extract_dir."/".$new_filename) ) {
                if ($timg['2'] < 1 || $timg['2'] > 16) continue;
            }
            array_push($meta_array,$new_filename);
        }			
        $meta_array = array_reverse($meta_array);
        $book_uri = G5_URL.'/data/campaign_img/'.$cam_idx.'/'.preg_replace("/{$ext}/", '', $upload[1]['file']);
        meta_update(array(
            "fle_db_table"=>"campaign"
            "fle_db_id"=>$cam_idx
            "mta_key"=>$cam['file_dw'],
            "mta_value"=>$row['fle_filesize']
        ));
    }
}
} */


// 자동등록 시 맨 처음 캠페인?
if($i == $cam_prd_time){
    // 파일 등록
    $uploaded[] = upload_jt_file(array("fle_idx"=>$fle_idx
                        ,"mb_id"=>$member['mb_id']
                        ,"fle_src_file"=>$_FILES[$fle_type1.'_file']['tmp_name'][$j] //파일이름.
                        ,"fle_orig_file"=>$_FILES[$fle_type1.'_file']['name'][$j] //원본 파일명.
                        ,"fle_mime_type"=>$_FILES[$fle_type1.'_file']['type'][$j] //이미지 타입정보.
                        ,"fle_content"=>$fle_content
                        ,"fle_path"=>'/data/campaign_img/'.$cam_idx		//<---- 저장 디렉토리
                        ,"fle_db_table"=>"campaign"
                        ,"fle_db_id"=>$cam_idx
                        ,"fle_type"=>$fle_type1
                        ,"fle_sort"=>$j
    ));					
}
goto_url('./shop_view.php?cam_idx='.$cam_idx);
?>
