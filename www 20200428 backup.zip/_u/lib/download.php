<?php
include_once('./_common.php');

// clean the output buffer
ob_end_clean();

//-- 파일경로 및 다운로드할 파일명 두개 변수 필요함
// http://file1.ddmc.kr/download.php?file_fullpath=/data/pgroup/3531011152_vXxCy4WP_0124_05.JPG&file_name_orig=0124_05.JPG
if(!$file_fullpath)
	alert('파일 경로가 없습니다.');
        
if(!$file_name_orig)
	alert('파일 이름이 없습니다.');

$filepath = $file_fullpath;
$filepath = addslashes($filepath);
if (!is_file($filepath) || !file_exists($filepath) )
    alert('※※※※※※※이미지 다운로드 안되는 경우※※※※※※※\n 1. 체험신청 안 했을시 \n 2. 모집인원 마감');

//$original = urlencode($file['bf_source']);
$original = iconv('utf-8', 'euc-kr', $file_name_orig); // SIR 잉끼님 제안코드
if(!$original)
	$original = $file_name_orig;

if(preg_match("/msie/i", $_SERVER['HTTP_USER_AGENT']) && preg_match("/5\.5/", $_SERVER['HTTP_USER_AGENT'])) {
    header("content-type: doesn/matter");
    header("content-length: ".filesize("$filepath"));
    header("content-disposition: attachment; filename=\"$original\"");
    header("content-transfer-encoding: binary");
} else {
    header("content-type: file/unknown");
    header("content-length: ".filesize("$filepath"));
    header("content-disposition: attachment; filename=\"$original\"");
    header("content-description: php generated data");
}
header("pragma: no-cache");
header("expires: 0");
flush();

$fp = fopen($filepath, 'rb');

$download_rate = 10;

while(!feof($fp)) {
    print fread($fp, round($download_rate * 1024));
    flush();
    usleep(1000);
}
fclose ($fp);
flush();
?>
