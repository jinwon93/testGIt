<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

//롤링
echo '<script type="text/javascript" src="'.G5_URL.'/js/jquery.vticker-min.js"></script>';
$userAgent = $_SERVER["HTTP_USER_AGENT"];

// 익스플로러
if ( preg_match("/MSIE*/", $userAgent) ) { 	
	//Ex9이하
	if (preg_match('/(?i)msie [2-9]/',$userAgent))
	{
		$explorer_ver = "Ex9"; 
	}
	//Ex10이상
	else
	{
		$explorer_ver = "Ex10"; 
	}	
}else{
	$explorer_ver = '';
}
?>

<div class="cam_main_list_wrap">
	<!-- main_bnr01 시작 { -->
	<div id="main_bnr01_area">
		<?php echo banner200('main_bnr01',0,$explorer_ver); ?><!--//#main_bnr01-->
	</div>
	<!-- } main_bnr01 끝 -->
	
	
	<div class="cam_con" id="main_cam_con">
		<!-- 맞춤 캠페인 시작 { -->
		<div class="cam_con" id="main_cam_con01">
			<?php
            if ($member['mb_level'] >= 6) {
			    $sql_cam01 = " SELECT * FROM {$g5['campaign_table']} WHERE cam_status = 'ing' AND cam_nct = '1' ORDER BY cam_idx DESC LIMIT 8 ";
			    $cam_q01 = sql_query($sql_cam01,1);
			    $cam01 = array();
                
			    for($f=0;$row=sql_fetch_array($cam_q01);$f++){
			    	array_push($cam01,$row);
                }
            }else {
                $sql_cam01 = " SELECT * FROM {$g5['campaign_table']} WHERE cam_status = 'ing' AND cam_nct = '' ORDER BY cam_idx DESC LIMIT 8 ";
                $cam_q01 = sql_query($sql_cam01,1);
                $cam01 = array();
                for($f=0;$row=sql_fetch_array($cam_q01);$f++){
                array_push($cam01,$row);
                }   
            }
			?>
			<div class="title">맞춤 캠페인</div>	
			<?php if(count($cam01) > 0){ ?>
			<div class="cam_device_wrap1">
            
				<?php    
				for($f=0;$f<count($cam01);$f++){ 
				$f_row = "SELECT * FROM {$g5['file_table']} WHERE fle_db_table = 'campaign' AND fle_sort = 0 AND fle_db_id = {$cam01[$f]['cam_idx']}";
				$cam_r = sql_fetch($f_row);
				$cam01[$f]['file_width'] = 400;
				$cam01[$f]['file_height'] = 400;
				
				//print_r2($cam_r);
				if( $cam_r['fle_name'] && is_file(G5_PATH.$cam_r['fle_path'].'/'.$cam_r['fle_name']) ) {
					//경로
					$cam_r['fle_path_make'] = G5_URL.$cam_r['fle_path'];
					//( thumbnai만들기 ) is_create, is_crop, crop_mode.				
					$cam_r['file_thumbnail'] = thumbnail($cam_r['fle_name'], G5_PATH.$cam_r['fle_path'], G5_PATH.$cam_r['fle_path'], $cam01[$f]['file_width'], $cam01[$f]['file_height'], false, true, 'center', true, $um_value='80/0.5/3');					
				}
				else {
					$cam_r['fle_path_make'] = G5_URL.'/data/campaign_img';	// 디폴트 경로 결정해야 합니다.
					$cam_r['file_thumbnail'] = 'default.png';
				}
				
				$cam01[$f]['thumbnail_img'] = '<img src="'.$cam_r['fle_path_make'].'/'.$cam_r['file_thumbnail'].'" width="100%">';
				
				?>
				<div class="cam_device">
					<a href="<?=G5_USER_URL?>/k/shop_view.php?cam_idx=<?=$cam01[$f]['cam_idx']?>&list_order=recommend#hd">
						<div class="cam_img"><?=$cam01[$f]['thumbnail_img']?></div>
						<div class="cam_text_wrap">
							<div class="text_title"><?=$cam01[$f]['cam_name']?></div>
							<div class="text_sub_detail"><?=$cam01[$f]['cam_brief']?></div>
						</div>
					</a>
				</div>
				<?php } ?>
			</div>
			<?php } else { ?>
			<div id="sij_total_empty">준비 중 입니다.</div>
			<?php } ?>
		</div>
        <!-- } 맞춤 캠페인 끝 -->
        
		<!-- 새롭게 오픈한 캠페인 시작 { -->
            <div class="cam_con" id="main_cam_con05">
			<?php
            if ($member['mb_level'] >= 6) {
            // 캠페인 메인페이지에서 최신항목순으로 나열시  LIMIT = 4 --> DESC로 변경
            // cam_nct = '1' 사내회원만 보이도록 설정 
			$sql_cam05 = " SELECT * FROM {$g5['campaign_table']} WHERE cam_option = 'BS' AND cam_status = 'ing' AND cam_nct ='1' ORDER BY com_idx DESC LIMIT 4  ";
            
			$cam_q05 = sql_query($sql_cam05,1);
			$cam05 = array();
			
			for($f=0;$row=sql_fetch_array($cam_q05);$f++){
				array_push($cam05,$row);
            }
            }else { 
                $sql_cam05 = " SELECT * FROM {$g5['campaign_table']} WHERE cam_option = 'BS' AND cam_status = 'ing' AND cam_nct ='' ORDER BY com_idx DESC LIMIT 4  ";
                
                $cam_q05 = sql_query($sql_cam05,1);
                $cam05 = array();
                
                for($f=0;$row=sql_fetch_array($cam_q05);$f++){
                    array_push($cam05,$row);
                }   
            }
            
			?>
			<div class="title">새롭게 오픈한 캠페인<span class="more">+</span></div>
			<?php if(count($cam05) > 0){ ?>
			<div class="cam_device_wrap5">
				<?php
				for($f=0;$f<count($cam05);$f++){ 
				$f_row = "SELECT * FROM {$g5['file_table']} WHERE fle_db_table = 'campaign' AND fle_sort = 0 AND fle_db_id = {$cam05[$f]['cam_idx']}";
				$cam_r = sql_fetch($f_row);
				$cam05[$f]['file_width'] = 400;
				$cam05[$f]['file_height'] = 400;
				
				//print_r2($cam_r);
				if( $cam_r['fle_name'] && is_file(G5_PATH.$cam_r['fle_path'].'/'.$cam_r['fle_name']) ) {
					//경로
					$cam_r['fle_path_make'] = G5_URL.$cam_r['fle_path'];
					//( thumbnai만들기 ) is_create, is_crop, crop_mode.				
					$cam_r['file_thumbnail'] = thumbnail($cam_r['fle_name'], G5_PATH.$cam_r['fle_path'], G5_PATH.$cam_r['fle_path'], $cam05[$f]['file_width'], $cam05[$f]['file_height'], false, true, 'center', true, $um_value='80/0.5/3');					
				}
				else {
					$cam_r['fle_path_make'] = G5_URL.'/data/campaign_img';	// 디폴트 경로 결정해야 합니다.
					$cam_r['file_thumbnail'] = 'default.png';
				}
				
				$cam05[$f]['thumbnail_img'] = '<img src="'.$cam_r['fle_path_make'].'/'.$cam_r['file_thumbnail'].'" width="100%">';
				
				//D-day계산
				$cam_review_start_dt = date("Y-m-d",strtotime($cam05[$f]['cam_review_start_dt'])); //리뷰등록 시작일 
				$nDate = date("Y-m-d",time()); //오늘 날짜를 출력하겠지요?
				$cam_recruit_end_dt = Trim($cam05[$f]['cam_recruit_end_dt']); // 폼에서 POST로 넘어온 value 값('yyyy-mm-dd' 형식)
				$d_day = intval((strtotime($nDate)-strtotime($cam_recruit_end_dt)) / 86400); // 나머지 날짜값이 나옵니다.
				
				unset( $cam_recruit_end_dt );

				if($d_day >= '0'){
					//익스 8이하이면.
					if( $ex_class == "cam_dday_ex8" ){
						$cam_wish_wrap_on = 'cam_wish_wrap_on_ex8';
						$cam_wish_wrap = 'cam_wish_wrap_ex8';
					}else{
						$cam_wish_wrap_on = 'cam_wish_wrap_on';
						$cam_wish_wrap = 'cam_wish_wrap';
					}	
					
					$cam_now_dday = ''; //class
					$d_day = '완료';
				}else{
					//익스 8이하이면.
					if( $ex_class == "cam_dday_ex8" ){
						$cam_now_dday = 'cam_now_dday_ex8'; //class
						$cam_wish_wrap_on = 'cam_wish_wrap_on_ex8';
						$cam_wish_wrap = 'cam_wish_wrap_ex8';
					}else{
						$cam_now_dday = 'cam_now_dday'; //class
						$cam_wish_wrap_on = 'cam_wish_wrap_on';
						$cam_wish_wrap = 'cam_wish_wrap';
					}
					$d_day = 'D'.$d_day;
				}
				
				//비모집,모집 구분하기 및 카운트.
				$cma = sql_fetch( "SELECT count(cam_idx) AS cma_idx_count FROM {$g5['campaign_apply_table']} WHERE cam_idx = {$cam05[$f]['cam_idx']} AND cma_status NOT IN ('trash')" );
				
				if($cam05[$f]['cam_reviewer_yn'] == '1') {
					$cam05[$f]['cma_idx_count'] = $cma['cma_idx_count'] ? $cma['cma_idx_count'] : 0;
					$cam05[$f]['cma_idx_count_make'] = '<span class="recruit_cnt">신청 '.$cma['cma_idx_count'].' / <span>모집 '.$cam05[$f]['cam_recruit_count'].'</span></span>';
				}
				else {
					$cam05[$f]['cma_idx_count_make'] =  '<span class="cam_all">모두참여</span>';
				}
				
				if( $wish['cam_idx'] ){
					$row['cam_wish_wrap_make'] = '<div class="'.$cam_wish_wrap_on.'"><span> 스크랩완료 </span><input type="hidden" name="wish_cam_idx" class="wish_cam_idx" value="'.$row['cam_idx'].'"></div>';
				}else{
					$row['cam_wish_wrap_make'] = '<div class="'.$cam_wish_wrap.'"><span> 스크랩하기 </span><input type="hidden" name="wish_cam_idx" class="wish_cam_idx" value="'.$row['cam_idx'].'"></div>';
				}
				
				?>
                
                <?php if($cam05[$f]['cam_type'] == 'receipt' || $member['mb_level'] >= 6){ 
                    
                    
                }    
                ?>
                <?php 
                // print_r2($cam05[$f]['cam_nct']);
                
                ?>
				<div class="cam_device">
					<a href="<?=G5_USER_URL?>/k/shop_view.php?cam_idx=<?=$cam05[$f]['cam_idx']?>&list_order=recommend#hd">
						<div class="cam_img"><?=$cam05[$f]['thumbnail_img']?></div>
						<div class="cam_text_wrap">
                        
							<div class="text_title"><?=$cam05[$f]['cam_name']?></div>
							<!-- <div class="text_sub_tit"><?=$cam05[$f]['cam_brief']?></div> -->
							<div class="text_sub_detail"><?=$cam05[$f]['cam_brief']?></div>
						</div>
						<div class="cam_text_day">
							<div class="cam_day"><?=$d_day?></div>
							<div class="cam_apply"><?=$cam05[$f]['cma_idx_count_make']?></div>
						</div>
					</a>
					<?php echo $row['cam_wish_wrap_make'] ?>
				</div>
                
				<?php } ?>
			</div>
			<?php } else { ?>
			<div id="sij_total_empty">준비 중 입니다.</div>
			<?php } ?>
		</div>
		<!-- } 새롭게 오픈한 캠페인 끝 -->
		
		<!-- 인기 많은 캠페인 시작 { -->
		<div class="cam_con" id="main_cam_con02">
			<?php
            if ($member['mb_level'] >= 6) {
			    $sql_cam02 = " SELECT * FROM {$g5['campaign_table']} WHERE cam_option = 'POP' AND cam_nct = '1' ORDER BY com_idx DESC LIMIT 4 ";
                
			    $cam_q02 = sql_query($sql_cam02,1);
			    $cam02 = array();
                
			    for($f=0;$row=sql_fetch_array($cam_q02);$f++){
			    	array_push($cam02,$row);
                }
            }else {
                $sql_cam02 = " SELECT * FROM {$g5['campaign_table']} WHERE cam_option = 'POP'AND cam_nct = '' ORDER BY com_idx DESC LIMIT 4 ";
			
                $cam_q02 = sql_query($sql_cam02,1);
                $cam02 = array();
                
                for($f=0;$row=sql_fetch_array($cam_q02);$f++){
                    array_push($cam02,$row);
                }   
            }
			?>
			<div class="title">인기 많은 캠페인<span class="more">+</span></div>
			<?php if(count($cam02) > 0){ ?>
			<div class="cam_device_wrap2">
				<?php
				for($f=0;$f<count($cam02);$f++){ 
				$f_row = "SELECT * FROM {$g5['file_table']} WHERE fle_db_table = 'campaign' AND fle_sort = 0 AND fle_db_id = {$cam02[$f]['cam_idx']}";
				$cam_r = sql_fetch($f_row);
				$cam02[$f]['file_width'] = 400;
				$cam02[$f]['file_height'] = 400;
				
				//print_r2($cam_r);
				if( $cam_r['fle_name'] && is_file(G5_PATH.$cam_r['fle_path'].'/'.$cam_r['fle_name']) ) {
					//경로
					$cam_r['fle_path_make'] = G5_URL.$cam_r['fle_path'];
					//( thumbnai만들기 ) is_create, is_crop, crop_mode.				
					$cam_r['file_thumbnail'] = thumbnail($cam_r['fle_name'], G5_PATH.$cam_r['fle_path'], G5_PATH.$cam_r['fle_path'], $cam02[$f]['file_width'], $cam02[$f]['file_height'], false, true, 'center', true, $um_value='80/0.5/3');					
				}
				else {
					$cam_r['fle_path_make'] = G5_URL.'/data/campaign_img';	// 디폴트 경로 결정해야 합니다.
					$cam_r['file_thumbnail'] = 'default.png';
				}
				
				$cam02[$f]['thumbnail_img'] = '<img src="'.$cam_r['fle_path_make'].'/'.$cam_r['file_thumbnail'].'" width="100%">';
				
				//D-day계산
				$cam_review_start_dt = date("Y-m-d",strtotime($cam02[$f]['cam_review_start_dt'])); //리뷰등록 시작일 
				$nDate = date("Y-m-d",time()); //오늘 날짜를 출력하겠지요?
				$cam_recruit_end_dt = Trim($cam02[$f]['cam_recruit_end_dt']); // 폼에서 POST로 넘어온 value 값('yyyy-mm-dd' 형식)
				$d_day = intval((strtotime($nDate)-strtotime($cam_recruit_end_dt)) / 86400); // 나머지 날짜값이 나옵니다.
				
				unset( $cam_recruit_end_dt );

				if($d_day >= '0'){
					//익스 8이하이면.
					if( $ex_class == "cam_dday_ex8" ){
						$cam_wish_wrap_on = 'cam_wish_wrap_on_ex8';
						$cam_wish_wrap = 'cam_wish_wrap_ex8';
					}else{
						$cam_wish_wrap_on = 'cam_wish_wrap_on';
						$cam_wish_wrap = 'cam_wish_wrap';
					}	
					
					$cam_now_dday = ''; //class
					$d_day = '완료';
				}else{
					//익스 8이하이면.
					if( $ex_class == "cam_dday_ex8" ){
						$cam_now_dday = 'cam_now_dday_ex8'; //class
						$cam_wish_wrap_on = 'cam_wish_wrap_on_ex8';
						$cam_wish_wrap = 'cam_wish_wrap_ex8';
					}else{
						$cam_now_dday = 'cam_now_dday'; //class
						$cam_wish_wrap_on = 'cam_wish_wrap_on';
						$cam_wish_wrap = 'cam_wish_wrap';
					}
					$d_day = 'D'.$d_day;
				}
				
				//비모집,모집 구분하기 및 카운트.
				$cma = sql_fetch( "SELECT count(cam_idx) AS cma_idx_count FROM {$g5['campaign_apply_table']} WHERE cam_idx = {$cam02[$f]['cam_idx']} AND cma_status NOT IN ('trash')" );
				
				if($cam02[$f]['cam_reviewer_yn'] == '1') {
					$cam02[$f]['cma_idx_count'] = $cma['cma_idx_count'] ? $cma['cma_idx_count'] : 0;
					$cam02[$f]['cma_idx_count_make'] = '<span class="recruit_cnt">신청 '.$cma['cma_idx_count'].' / <span>모집 '.$cam02[$f]['cam_recruit_count'].'</span></span>';
				}
				else {
					$cam02[$f]['cma_idx_count_make'] =  '<span class="cam_all">모두참여</span>';
				}
				
				if( $wish['cam_idx'] ){
					$row['cam_wish_wrap_make'] = '<div class="'.$cam_wish_wrap_on.'"><span> 스크랩완료 </span><input type="hidden" name="wish_cam_idx" class="wish_cam_idx" value="'.$row['cam_idx'].'"></div>';
				}else{
					$row['cam_wish_wrap_make'] = '<div class="'.$cam_wish_wrap.'"><span> 스크랩하기 </span><input type="hidden" name="wish_cam_idx" class="wish_cam_idx" value="'.$row['cam_idx'].'"></div>';
				}
				
				?>
                
				<div class="cam_device">
					<a href="<?=G5_USER_URL?>/k/shop_view.php?cam_idx=<?=$cam02[$f]['cam_idx']?>&list_order=recommend#hd">
						<div class="cam_img"><?=$cam02[$f]['thumbnail_img']?></div>
						<div class="cam_text_wrap">
							<div class="text_title"><?=$cam02[$f]['cam_name']?></div>
							<!-- <div class="text_sub_tit"><?=$cam02[$f]['cam_brief']?></div> -->
							<div class="text_sub_detail"><?=$cam02[$f]['cam_brief']?></div>
						</div>
						<div class="cam_text_day">
							<div class="cam_day"><?=$d_day?></div>
							<div class="cam_apply"><?=$cam02[$f]['cma_idx_count_make']?></div>
						</div>
					</a>
					<?php echo $row['cam_wish_wrap_make'] ?>
				</div>
				<?php } ?>
			</div>
			<?php } else { ?>
			<div id="sij_total_empty">준비 중 입니다.</div>
			<?php } ?>
		</div>
		<!-- } 인기 많은 캠페인 끝 -->
		
		<!-- 프리미엄 캠페인 시작 { -->
		<div class="cam_con" id="main_cam_con03">
			<?php
            if ($member['mb_level'] >= 6) {
                
			$sql_cam03 = " SELECT * FROM {$g5['campaign_table']} WHERE cam_option = 'PRE' AND cam_nct='1' ORDER BY com_idx DESC LIMIT 4 ";
			
			$cam_q03 = sql_query($sql_cam03,1);
			$cam03 = array();
			
			for($f=0;$row=sql_fetch_array($cam_q03);$f++){
				array_push($cam03,$row);
			}
            }else {
                $sql_cam03 = " SELECT * FROM {$g5['campaign_table']} WHERE cam_option = 'PRE' AND cam_nct='' ORDER BY com_idx DESC LIMIT 4 ";
			
                $cam_q03 = sql_query($sql_cam03,1);
                $cam03 = array();
                
                for($f=0;$row=sql_fetch_array($cam_q03);$f++){
                    array_push($cam03,$row);
                }   
            }
			?>
            
			<div class="title">프리미엄 캠페인<span class="more">+</span></div>
			<?php if(count($cam03) > 0){ ?>
			<div class="cam_device_wrap3">
				<?php
				for($f=0;$f<count($cam03);$f++){ 
				$f_row = "SELECT * FROM {$g5['file_table']} WHERE fle_db_table = 'campaign' AND fle_sort = 0 AND fle_db_id = {$cam03[$f]['cam_idx']}";
				$cam_r = sql_fetch($f_row);
				$cam03[$f]['file_width'] = 400;
				$cam03[$f]['file_height'] = 400;
				
				//print_r2($cam_r);
				if( $cam_r['fle_name'] && is_file(G5_PATH.$cam_r['fle_path'].'/'.$cam_r['fle_name']) ) {
					//경로
					$cam_r['fle_path_make'] = G5_URL.$cam_r['fle_path'];
					//( thumbnai만들기 ) is_create, is_crop, crop_mode.				
					$cam_r['file_thumbnail'] = thumbnail($cam_r['fle_name'], G5_PATH.$cam_r['fle_path'], G5_PATH.$cam_r['fle_path'], $cam03[$f]['file_width'], $cam03[$f]['file_height'], false, true, 'center', true, $um_value='80/0.5/3');					
				}
				else {
					$cam_r['fle_path_make'] = G5_URL.'/data/campaign_img';	// 디폴트 경로 결정해야 합니다.
					$cam_r['file_thumbnail'] = 'default.png';
				}
				
				$cam03[$f]['thumbnail_img'] = '<img src="'.$cam_r['fle_path_make'].'/'.$cam_r['file_thumbnail'].'" width="100%">';
				
				//D-day계산
				$cam_review_start_dt = date("Y-m-d",strtotime($cam03[$f]['cam_review_start_dt'])); //리뷰등록 시작일 
				$nDate = date("Y-m-d",time()); //오늘 날짜를 출력하겠지요?
				$cam_recruit_end_dt = Trim($cam03[$f]['cam_recruit_end_dt']); // 폼에서 POST로 넘어온 value 값('yyyy-mm-dd' 형식)
				$d_day = intval((strtotime($nDate)-strtotime($cam_recruit_end_dt)) / 86400); // 나머지 날짜값이 나옵니다.
				
				unset( $cam_recruit_end_dt );

				if($d_day > '0'){
					//익스 8이하이면.
					if( $ex_class == "cam_dday_ex8" ){
						$cam_wish_wrap_on = 'cam_wish_wrap_on_ex8';
						$cam_wish_wrap = 'cam_wish_wrap_ex8';
					}else{
						$cam_wish_wrap_on = 'cam_wish_wrap_on';
						$cam_wish_wrap = 'cam_wish_wrap';
					}	
					
					$cam_now_dday = ''; //class
					$d_day = '완료';
				}else{
					//익스 8이하이면.
					if( $ex_class == "cam_dday_ex8" ){
						$cam_now_dday = 'cam_now_dday_ex8'; //class
						$cam_wish_wrap_on = 'cam_wish_wrap_on_ex8';
						$cam_wish_wrap = 'cam_wish_wrap_ex8';
					}else{
						$cam_now_dday = 'cam_now_dday'; //class
						$cam_wish_wrap_on = 'cam_wish_wrap_on';
						$cam_wish_wrap = 'cam_wish_wrap';
					}
					$d_day = 'D'.$d_day;
				}
				
				//비모집,모집 구분하기 및 카운트.
				$cma = sql_fetch( "SELECT count(cam_idx) AS cma_idx_count FROM {$g5['campaign_apply_table']} WHERE cam_idx = {$cam03[$f]['cam_idx']} AND cma_status NOT IN ('trash')" );
				
				if($cam03[$f]['cam_reviewer_yn'] == '1') {
					$cam03[$f]['cma_idx_count'] = $cma['cma_idx_count'] ? $cma['cma_idx_count'] : 0;
					$cam03[$f]['cma_idx_count_make'] = '<span class="recruit_cnt">신청 '.$cma['cma_idx_count'].' / <span>모집 '.$cam03[$f]['cam_recruit_count'].'</span></span>';
				}
				else {
					$cam03[$f]['cma_idx_count_make'] =  '<span class="cam_all">모두참여</span>';
				}
				
				if( $wish['cam_idx'] ){
					$row['cam_wish_wrap_make'] = '<div class="'.$cam_wish_wrap_on.'"><span> 스크랩완료 </span><input type="hidden" name="wish_cam_idx" class="wish_cam_idx" value="'.$row['cam_idx'].'"></div>';
				}else{
					$row['cam_wish_wrap_make'] = '<div class="'.$cam_wish_wrap.'"><span> 스크랩하기 </span><input type="hidden" name="wish_cam_idx" class="wish_cam_idx" value="'.$row['cam_idx'].'"></div>';
				}
				
				?>
				<div class="cam_device">
					<a href="<?=G5_USER_URL?>/k/shop_view.php?cam_idx=<?=$cam03[$f]['cam_idx']?>&list_order=recommend#hd">
						<div class="cam_img"><?=$cam03[$f]['thumbnail_img']?></div>
						<div class="cam_text_wrap">
							<div class="text_title"><?=$cam03[$f]['cam_name']?></div>
							<!-- <div class="text_sub_tit"><?=$cam03[$f]['cam_brief']?></div> -->
							<div class="text_sub_detail"><?=$cam03[$f]['cam_brief']?></div>
						</div>
						<div class="cam_text_day">
							<div class="cam_day"><?=$d_day?></div>
							<div class="cam_apply"><?=$cam03[$f]['cma_idx_count_make']?></div>
						</div>
					</a>
					<?php echo $row['cam_wish_wrap_make'] ?>
				</div>
				<?php } ?>
			</div>
			<?php } else { ?>
			<div id="sij_total_empty">준비 중 입니다.</div>
			<?php } ?>
		</div>
		<!-- } 프리미엄 캠페인 끝 -->
		

		<!-- center_bn 시작 { -->
		<div id="center_bn_area">
			<div id="center_bn01_area" class="center_bn_area">
				<?php echo banner200('center_bn01',0,$explorer_ver); ?><!--//#center_bn01-->
			</div>
			<div id="center_bn02_area" class="center_bn_area">
				<?php echo banner200('center_bn02',0,$explorer_ver); ?><!--//#center_bn02-->
			</div>
		</div>
		<!-- } center_bn 끝 -->


		<!-- MD추천 캠페인 시작 { -->
		<div class="cam_con" id="main_cam_con04">
        
			<?php
            if ($member['mb_level'] >= 6) {
                
			    $sql_cam04 = " SELECT * FROM {$g5['campaign_table']} WHERE cam_option = 'MD' AND cam_nct = '1' ORDER BY com_idx DESC LIMIT 4 ";
                
			    $cam_q04 = sql_query($sql_cam04,1);
			    $cam04 = array();
                
			    for($f=0;$row=sql_fetch_array($cam_q04);$f++){
			    	array_push($cam04,$row);
			    }
            }else {
                $sql_cam04 = " SELECT * FROM {$g5['campaign_table']} WHERE cam_option = 'MD' AND cam_nct = '' ORDER BY com_idx DESC LIMIT 4 ";
			
                $cam_q04 = sql_query($sql_cam04,1);
                $cam04 = array();
                
                for($f=0;$row=sql_fetch_array($cam_q04);$f++){
                    array_push($cam04,$row);
                }   
            }
			?>
			<div class="title">MD추천 캠페인<span class="more">+</span></div>
			<?php if(count($cam04) > 0){ ?>
			<div class="cam_device_wrap4"   >
				<?php
				for($f=0;$f<count($cam04);$f++){ 
				$f_row = "SELECT * FROM {$g5['file_table']} WHERE fle_db_table = 'campaign' AND fle_sort = 0 AND fle_db_id = {$cam04[$f]['cam_idx']}";
				$cam_r = sql_fetch($f_row);
				$cam04[$f]['file_width'] = 400;
				$cam04[$f]['file_height'] = 400;
				
				//print_r2($cam_r);
				if( $cam_r['fle_name'] && is_file(G5_PATH.$cam_r['fle_path'].'/'.$cam_r['fle_name']) ) {
					//경로
					$cam_r['fle_path_make'] = G5_URL.$cam_r['fle_path'];
					//( thumbnai만들기 ) is_create, is_crop, crop_mode.				
					$cam_r['file_thumbnail'] = thumbnail($cam_r['fle_name'], G5_PATH.$cam_r['fle_path'], G5_PATH.$cam_r['fle_path'], $cam04[$f]['file_width'], $cam04[$f]['file_height'], false, true, 'center', true, $um_value='80/0.5/3');					
				}
				else {
					$cam_r['fle_path_make'] = G5_URL.'/data/campaign_img';	// 디폴트 경로 결정해야 합니다.
					$cam_r['file_thumbnail'] = 'default.png';
				}
				
				$cam04[$f]['thumbnail_img'] = '<img src="'.$cam_r['fle_path_make'].'/'.$cam_r['file_thumbnail'].'" width="100%">';
				
				//D-day계산
				$cam_review_start_dt = date("Y-m-d",strtotime($cam04[$f]['cam_review_start_dt'])); //리뷰등록 시작일 
				$nDate = date("Y-m-d",time()); //오늘 날짜를 출력하겠지요?
				$cam_recruit_end_dt = Trim($cam04[$f]['cam_recruit_end_dt']); // 폼에서 POST로 넘어온 value 값('yyyy-mm-dd' 형식)
				$d_day = intval((strtotime($nDate)-strtotime($cam_recruit_end_dt)) / 86400); // 나머지 날짜값이 나옵니다.
				
				unset( $cam_recruit_end_dt );

				if($d_day > '0'){
					//익스 8이하이면.
					if( $ex_class == "cam_dday_ex8" ){
						$cam_wish_wrap_on = 'cam_wish_wrap_on_ex8';
						$cam_wish_wrap = 'cam_wish_wrap_ex8';
					}else{
						$cam_wish_wrap_on = 'cam_wish_wrap_on';
						$cam_wish_wrap = 'cam_wish_wrap';
					}	
					
					$cam_now_dday = ''; //class
					$d_day = '완료';
				}else{
					//익스 8이하이면.
					if( $ex_class == "cam_dday_ex8" ){
						$cam_now_dday = 'cam_now_dday_ex8'; //class
						$cam_wish_wrap_on = 'cam_wish_wrap_on_ex8';
						$cam_wish_wrap = 'cam_wish_wrap_ex8';
					}else{
						$cam_now_dday = 'cam_now_dday'; //class
						$cam_wish_wrap_on = 'cam_wish_wrap_on';
						$cam_wish_wrap = 'cam_wish_wrap';
					}
					$d_day = 'D'.$d_day;
				}
				
				//비모집,모집 구분하기 및 카운트.
				$cma = sql_fetch( "SELECT count(cam_idx) AS cma_idx_count FROM {$g5['campaign_apply_table']} WHERE cam_idx = {$cam04[$f]['cam_idx']} AND cma_status NOT IN ('trash')" );
				
				if($cam04[$f]['cam_reviewer_yn'] == '1') {
					$cam04[$f]['cma_idx_count'] = $cma['cma_idx_count'] ? $cma['cma_idx_count'] : 0;
					$cam04[$f]['cma_idx_count_make'] = '<span class="recruit_cnt">신청 '.$cma['cma_idx_count'].' / <span>모집 '.$cam04[$f]['cam_recruit_count'].'</span></span>';
				}
				else {
					$cam04[$f]['cma_idx_count_make'] =  '<span class="cam_all">모두참여</span>';
				}
				
				if( $wish['cam_idx'] ){
					$row['cam_wish_wrap_make'] = '<div class="'.$cam_wish_wrap_on.'"><span> 스크랩완료 </span><input type="hidden" name="wish_cam_idx" class="wish_cam_idx" value="'.$row['cam_idx'].'"></div>';
				}else{
					$row['cam_wish_wrap_make'] = '<div class="'.$cam_wish_wrap.'"><span> 스크랩하기 </span><input type="hidden" name="wish_cam_idx" class="wish_cam_idx" value="'.$row['cam_idx'].'"></div>';
				}
				
				?>
				<div class="cam_device">
					<a href="<?=G5_USER_URL?>/k/shop_view.php?cam_idx=<?=$cam04[$f]['cam_idx']?>&list_order=recommend#hd">
						<div class="cam_img"><?=$cam04[$f]['thumbnail_img']?></div>
						<div class="cam_text_wrap">
							<div class="text_title"><?=$cam04[$f]['cam_name']?></div>
							<!-- <div class="text_sub_tit"><?=$cam04[$f]['cam_brief']?></div> -->
							<div class="text_sub_detail"><?=$cam04[$f]['cam_brief']?></div>
						</div>
						<div class="cam_text_day">
							<div class="cam_day"><?=$d_day?></div>
							<div class="cam_apply"><?=$cam04[$f]['cma_idx_count_make']?></div>
						</div>
                        
					</a>
					<?php echo $row['cam_wish_wrap_make'] ?>
				</div>
				<?php } ?>
			</div>
			<?php } else { ?>
			<div id="sij_total_empty">준비 중 입니다.</div>
			<?php } ?>
		</div>
        
		<!-- } MD추천 캠페인 끝 -->
	</div>
</div>


<script>
$(function(){	
	//공지 롤링
	$('#dv_rolling').vTicker({   
        // 스크롤 속도(default: 700)  
        speed: 600,  
        // 스크롤 사이의 대기시간(default: 4000)  
        pause: 4000,  
        // 스크롤 애니메이션  
        animation: 'fade',  
        // 마우스 over 일때 멈출 설정  
        mousePause: true,  
        // 한번에 보일 리스트수(default: 2)  
        showItems: 1,  
        // 스크롤 컨테이너 높이(default: 0)  
        height: 40,  
        // 아이템이 움직이는 방향, up/down (default: up)  
        direction: 'up'  
    });	
});
</script>
