<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

// 익스플로러
if ( preg_match("/MSIE*/", $_SERVER["HTTP_USER_AGENT"]) ) { 	
	//Ex8이하
	if (preg_match('/(?i)msie [2-8]/', $_SERVER["HTTP_USER_AGENT"]))
	{
		$explorer_ver_css = "ex8_dw";
		$explorer_ver = 'Ex8';
	}
	//Ex9이상
	else
	{
		$explorer_ver_css = "ex9_up";
		$explorer_ver = 'Ex9';
	}	
}else{
	$explorer_ver_css = '';
}


//이미지관련부분 start
//메타 분리
$pieces = explode(',', $cam['mbr_metas']);
foreach ($pieces as $piece) {
	list($key, $value) = explode('=', $piece);
	$cam[$key] = $value;
}
unset($pieces);unset($piece);

// 파일 정보 분리 
$cam['file_width'] = 400;
$cam['file_height'] = 300;
$pieces = explode(',', $cam['fle_files']);
		
for ($i=0; $i<sizeof($pieces); $i++) {
	
	//파일정보 분리.
	$file_pieces = explode('^', $pieces[$i]);
	foreach ($file_pieces as $file_piece) {
		list($key, $value) = explode('=', $file_piece);
		$cam[$key] = $value;
	}	
	unset($file_pieces);unset($file_piece);
	
	//확장자명 추출하기.
	$cam['file_extension'] = explode('.',$cam['fle_name']);
	//echo $cam['file_extension'][1].'<br>';

	//압축파일은 빼고 보여주기.
	if( $cam['file_extension'][1] != 'zip' ){
		
		if( $cam['fle_name'] && is_file(G5_PATH.$cam['fle_path'].'/'.$cam['fle_name']) ) {
			//경로 만들기.
			$cam['fle_path_make'] = G5_URL.$cam['fle_path'];
			// is_create, is_crop, crop_mode	thumbnai만들기.				
			$cam['file_thumbnail'] = thumbnail($cam['fle_name'], G5_PATH.$cam['fle_path'], G5_PATH.$cam['fle_path'], $cam['file_width'], $cam['file_height'], false, true, 'center', true, $um_value='80/0.5/3');					
		}
		else {
			//경로 만들기.
			$cam['fle_path_make'] = G5_URL.'/data/campaign_img';	// 디폴트 경로 결정해야 합니다.
			$cam['file_thumbnail'] = 'default.png';
		}
		
		$cam['thumbnail_img'][$i] = '<img src="'.$cam['fle_path_make'].'/'.$cam['file_thumbnail'].'" width="100%">';	
	}
}
unset($pieces);
?>
<?php 



?>
<script type="text/javascript">
$(document).ready(function() {
//리뷰어등록일 이후에만 보이기.
if("<?= $today?>" >= "<?= $cam_review_start_dt?>"){
	//인스타 #tag 연결부분
	if("<?= $trm['trm_name']?>" != ''){
		$(".h_tag").css('display','inline-block');
		$(".tag_plus").css('display','block');
		
		$.ajax({
			//kafain 본인거만.
			//url: 'https://api.instagram.com/v1/users/self/media/recent/?access_token=3034550036.79aa3d7.589c7169089945b9a1170126d5fa45c4',			
			url: 'https://api.instagram.com/v1/tags/<?= $trm['trm_name']?>/media/recent?access_token=3034550036.79aa3d7.589c7169089945b9a1170126d5fa45c4&count=32',
			
			//인스타 안에 모든 테그 가져오기.
			//https://api.instagram.com/v1/tags/선풍기?access_token=3034550036.79aa3d7.589c7169089945b9a1170126d5fa45c4
			//kafain 팔로우들 테그 가져오기.
			//https://api.instagram.com/v1/tags/선풍기/media/recent?access_token=3034550036.79aa3d7.589c7169089945b9a1170126d5fa45c4
			//인스타 안에 모든 테그 Like 검색.
			//https://api.instagram.com/v1/tags/search?q=선풍기&access_token=3034550036.79aa3d7.589c7169089945b9a1170126d5fa45c4
			cache: false,
			dataType: 'jsonp'
		}).done(function( msg ) {
			var result = new Array(); 
			var cnt = 3; //index => 0부터 시작
			var cnt1 = 11;
			if (msg.data !== undefined) {
				//처음에 실행되서 4개 보여짐.
				$.each(msg.data, function(index, value) {
					//value에 있는 값을 가공함.
					var link = value.link;
					var imageUrl = value.images.low_resolution.url;
					var instaId = value.id;
					var likes = value.likes.count;
					var comments = value.comments.count;

					//cnt 숫자만큼 보여주기.
					if(index <= cnt) {
						result.push( '<div class="multiple">'
									+'<div class="bg_up"></div>'
									+'<a href="'+link+'" target="_blank">'
									+'<div class="lc_wrap">'
										+'<span class="insta_like"><img border="0" src="'+g5_theme_url+'/img/like_ic.png" width="12%" class="like_img" />'+likes+'</span>'
										+'<span class="insta_comment"><img border="0" src="'+g5_theme_url+'/img/comment_ic.png" width="12%" class="comment_img" />'+comments+'</span></div>'
										+'<img border="0" src="'+imageUrl+'" width="99%" class="insta_img" /></a></div>');
					};

					//더보기 카운트
					index_cnt = index;
				});
				$(".insta_tag").html(result.join(""));// 입력.
				
				if( !index_cnt ){ var index_cnt = 1; }
					
				//인스타 이미지가 처음에 더보기 필요 없으면.
				if( index_cnt < 4){
					$(".tag_plus").hide();
				}else{
					$(".tag_plus").show();
				}
				
				//더보기 클릭시 +4 하기. 
				$(".tag_plus").click(function(){
					$.each(msg.data, function(index, value) {
						var link = value.link;
						var imageUrl = value.images.low_resolution.url;
						var instaId = value.id;
						var likes = value.likes.count;
						var comments = value.comments.count;
						incnt = index; //인스타전체내용 cnt
						
						if(index > cnt && index <= cnt1 ) {
							result.push( '<div class="multiple">'
									+'<div class="bg_up"></div>'
									+'<a href="'+link+'" target="_blank">'
									+'<div class="lc_wrap">'
										+'<span class="insta_like"><img border="0" src="'+g5_theme_url+'/img/like_ic.png" width="12%" class="like_img" />'+likes+'</span>'
										+'<span class="insta_comment"><img border="0" src="'+g5_theme_url+'/img/comment_ic.png" width="12%" class="comment_img" />'+comments+'</span></div>'
										+'<img border="0" src="'+imageUrl+'" width="99%" class="insta_img" /></a></div>');
						};
					});
					
					$(".insta_tag").html(result.join(""));// 입력.
					
					//인스타 이미지가 없으면.(마지막이면 더보기 지우기.)
					if(incnt < cnt1 ){
						$(".tag_plus").detach();
					};
					
					cnt += 8;
					cnt1 += 8;
				});
			}
		});
	}
}

});
////인스타 #tag 연결부분  
</script>

<!-- 날짜 -->
<input type="hidden" name="today" class="today" value="<?=date("y.m.d")?>">
<input type="hidden" name="cam_recruit_start_dt" class="cam_recruit_start_dt" value="<?=date("y.m.d",strtotime($cam['cam_recruit_start_dt']))?>">
<input type="hidden" name="cam_recruit_end_dt" class="cam_recruit_end_dt" value="<?=date("y.m.d",strtotime($cam['cam_recruit_end_dt']))?>">
<input type="hidden" name="cam_notice_dt" class="cam_notice_dt" value="<?=date("y.m.d",strtotime($cam['cam_notice_dt']))?>">
<input type="hidden" name="cam_review_start_dt" class="cam_review_start_dt" value="<?=date("y.m.d",strtotime($cam['cam_review_start_dt']))?>">
<input type="hidden" name="cam_review_end_dt" class="cam_review_end_dt" value="<?=$cam_review_end_dt?>"> <!-- cam_wiew 에서 cma_reg_end_dt 값으로 변경됨.-->
<input type="hidden" name="cam_best_select_dt" class="cam_best_select_dt" value="<?=date("y.m.d",strtotime($cam['cam_best_select_dt']))?>">
<input type="hidden" name="cam_best_use_yn" class="cam_best_use_yn" value="<?=$cam['cam_best_use_yn']?>">

<input type="hidden" name="cam_idx" class="cam_idx" id="cam_idx" value="<?=$cam['cam_idx']?>">
<input type="hidden" name="cam_status" class="cam_status" id="cam_status" value="<?=$cam['cam_status']?>">
<input type="hidden" name="apay_cnt" class="apay_cnt" id="apay_cnt" value="<?=$apay['cnt']?>">
<input type="hidden" name="cama_cnt" class="cama_cnt" id="cama_cnt" value="<?=number_format($cam_a['cnt'])-1?>">
<input type="hidden" name="cam_nct" class="cam_nct" id="cam_nct" value="<?=$cam['cam_nct']?>">
<input type="hidden" name="cam_nct_only" class="cam_nct_only" id="cam_nct_only" value="<?=$cam['cam_nct_only']?>">
<input type="hidden" name="cam_nct_cnt" class="cam_nct_cnt" id="cam_nct_cnt" value="<?= number_format($cam['cam_nct_cnt'])?>">
<input type="hidden" name="rev_cnt" class="rev_cnt" id="rev_cnt" value="<?= number_format($nct_rev['cnt'])?>"> <!--사내회원 리뷰신청 카운트 추출하기-->
<input type="hidden" name="rev_cnt_only" class="rev_cnt_only" id="rev_cnt_only" value="<?= number_format($rev3['cnt'])?>"> <!--본인빼고 리뷰등록 카운트-->
<input type="hidden" name="cam_type" class="cam_type" value="<?=$cam['cam_type']?>">
<input type="hidden" name="explorer_ver" class="explorer_ver" value="<?=$explorer_ver?>">
<input type="hidden" name="cat_idx" class="cat_idx" value="<?=$cat_idx?>">
<input type="hidden" name="com_latitude" class="com_latitude" id="com_latitude" value="<?=$cam['com_latitude']?>">
<input type="hidden" name="com_longitude" class="com_longitude" id="com_longitude" value="<?=$cam['com_longitude']?>">
<input type="hidden" name="cam_channels" class="cam_channels" id="cam_channels" value="<?=$cam['cam_channels']?>">
<!--2020-03-20 수정자 곽진원 -->
<!-- <input type="hidden" name="sns_channel_46_url_make" class="sns_channel_46_url_make" id="sns_channel_46_url_make" value="<?=$member['sns_channel_46_url']?>"> -->
<!-- <input type="hidden" name="sns_channel_47_url_make" class="sns_channel_47_url_make" id="sns_channel_47_url_make" value="<?=$member['sns_channel_47_url']?>"> -->
<!-- 48 / 50 / 51 인스타/블로그/영수증 리뷰 value 값 url이 아닌 login 값으로 변경  -->
<!-- $member  -> key 50['naver_login']  key 51 ['receipt_login']-->
<input type="hidden" name="sns_channel_48_url_make" class="sns_channel_48_url_make" id="sns_channel_48_url_make" value="<?=$member['instagram_login']?>">
<!-- <input type="hidden" name="sns_channel_49_url_make" class="sns_channel_49_url_make" id="sns_channel_49_url_make" value="<?=$member['sns_channel_49_url']?>"> -->
<input type="hidden" name="sns_channel_50_url_make" class="sns_channel_50_url_make" id="sns_channel_50_url_make" value="<?=$member['mb_7']?>">
<input type="hidden" name="sns_channel_51_url_make" class="sns_channel_51_url_make" id="sns_channel_51_url_make" value="<?=$member['mb_nick']?>">
<!-- 리뷰 신청완료 ==> 리뷰 등록시  블로그 값이 아닌 url을 입력할수 있도록 hidden으로 넘김  -->
<input type="hidden" name="naver_login" class="naver_login" id="naver_login" value="<?=$member['mb_7']?>">
<input type="hidden" name="set_sns_url_plus_cnt" class="set_sns_url_plus_cnt" value="<?=$setting['set_sns_url_plus_cnt'] ? $setting['set_sns_url_plus_cnt'] : 1;?>">
	
<!--나의 캠페인에서 업체가 진행하는 본인 캠페인 확인할때 lv.6이 아니기때문에 확인 할수 있게 하기위한 값 -->
<input type="hidden" name="my_cam_lv" class="my_cam_lv" value="<?=$my_cam_lv?>">

<!--로그인 확인 .js파일에서 사용됨.-->
<input type="hidden" name="mem_confirm" class="mem_confirm" value="<?=$member['mb_id']?>">
<!--u_campaign_apply 테이블에 캠페인신청idx 값 추출하기.-->
<input type="hidden" name="cma_idx_ask" class="cma_idx_ask" value="<?=$cma_reg['cma_idx']?>">
<input type="hidden" name="cma_review_yn" class="cma_review_yn" value="<?=$cma_reg['cma_review_yn']?>">


<!-- **** 왼편 **** -->
<div class="cam_view_left_total_wrap">
	<div class="view_divide_t_wrap"> 
		<div class="divide_t_img">		
			<?php
			//css로딩 이미지 보여주기.
			$cam['thumbnail_img_cnt'] = count($cam['thumbnail_img'])-1;
			for( $i=0; $i <= $cam['thumbnail_img_cnt']; $i++){
				echo $cam['thumbnail_img'][$cam['thumbnail_img_cnt']-$i];				
			}
			?>			
		</div>
		
		<?php
		//내 관심캠페인.
		echo '<span class="view_wish_cam">';
		if( isset($cam_wish['cmw_idx']) ){
			echo '<span class="cam_list_start_on">
					<img src="'.G5_THEME_MOBILE_URL.'/img/star_on.png" style="width:33px;">
					<input type="hidden" name="wish_cam_idx" class="wish_cam_idx" value="'.$cam['cam_idx'].'">
				  </span>';
		}
		else{
			echo '<span class="cam_list_start_off">
					<img src="'.G5_THEME_MOBILE_URL.'/img/star_off.png" style="width:33px;">
					<input type="hidden" name="wish_cam_idx" class="wish_cam_idx" value="'.$cam['cam_idx'].'">
				  </span>';
		};
		echo '</span>';
		?>
		
		
		<div class="divide_t_text">
			<div id="view_title_wrap">
				<div class="view_title"><?=mb_strimwidth($cam['cam_name'],'0','70','...','utf-8');?></div>
				<div class="view_title_sub"><?=$cam['cam_brief'];?></div>
			</div>
			
			<?php
			if( $cam['cam_nct_only'] == '1' ){
				echo '<div class="review_w">
						<div class="item_nct_step1 item_index3">
							<div class="item_cnt">01</div>
							<div class="item_title">리뷰어</br>등록</div>
							<div class="item_r_date">'.date("y.m.d",strtotime($cam['cam_review_start_dt'])).' ~ '.substr($cam_review_end_dt,3).'</div>
						</div>';
				if($cam['cam_best_use_yn'] == '1'){
				  echo '<div class="item_nct_step2 item_index4">
							<i class="fa fa-angle-double-right" aria-hidden="true"></i>
							<div class="item_cnt">02</div>
							<div class="item_title">베스트</br>발표</div>
							<div class="item_r_date">'.date("y.m.d",strtotime($cam['cam_best_select_dt'])).'</div>
						</div>';
				}	
			   echo ' </div>';
			}else{				
			?>
				<div class="<?=$cam['cam_best_use_yn'] == '1' || $cam['cam_best_use_yn'] =='0'?'review_w':'review_w_center';?>">
						<div class="item_step item_index1">
							<!--<div class="item_cnt">01</div>-->
							<div class="item_title">리뷰어 신청</div>
							<div class="item_r_date"><?=date("y.m.d",strtotime($cam['cam_recruit_start_dt']))?> ~ <?=date("y.m.d",strtotime($cam['cam_recruit_end_dt']))?></div>
						</div>
						<div class="item_step1 item_index2">
							<!--
							<i class="fa fa-angle-double-right" aria-hidden="true"></i>
							-->
							<!--<div class="item_cnt">02</div>-->
							<div class="item_title">리뷰어 발표</div>
							<div class="item_r_date"><?=date("y.m.d",strtotime($cam['cam_notice_dt']))?></div>
						</div>
						<div class="<?=$cam['cam_best_use_yn'] == '1'?'item_step1':'item_step2';?> item_index3">
							<!--
							<i class="fa fa-angle-double-right" aria-hidden="true"></i>
							-->
							<!--<div class="item_cnt">03</div>-->
							<div class="item_title">리뷰어 등록</div>
							<div class="item_r_date"><?=date("y.m.d",strtotime($cam['cam_review_start_dt']))?> ~ <?=substr($cam_review_end_dt,3)?></div>
                        </div>
                        <div class="item_step1 item_index2">
							<div class="item_title">포인트 제공내역</div>
							<div class="item_r_point" style="color:skyblue;font-size: 1.2em;line-height: 1.7em;font-weight: bold;"><?=$cam['cam_reviewer_point']?></div>
						</div>
                        <?php
						if($cam['cam_best_use_yn'] == '1'){
						?>
						<div class="item_step2 item_index4">
							<!--
							<i class="fa fa-angle-double-right" aria-hidden="true"></i>
							-->
							<!--<div class="item_cnt">04</div>-->
							<div class="item_title">베스트 발표</div>
							<div class="item_r_date"><?=$cam['cam_best_use_yn'] == '1'?date("y.m.d",strtotime($cam['cam_best_select_dt'])):'미사용'; ?></div>
						</div>
						<?php }	?>
				</div>
			<?php }	?>
			
		</div>
	</div>
	
	<div class="view_divide_m_wrap"> 
		<!-- 구분하기 -->
		<ul id="item_ul">
			<?php			
			if($cam['cam_nct_only'] == '1'){
				$cam['cam_nct_ap_cnt'] = isset($nct_rev['cnt'])?$nct_rev['cnt']:'0';
				echo '
				<a href="#"><li id="item_l1" class="item_nct_l1"><b>캠페인상세정보</b></li></a>
				<a href="#"><li id="item_l3" class="item_nct_l3"><b>리뷰 ( '.$cam['cam_nct_ap_cnt'].' )</b></li></a>
				';
			}else{				
			?>
			<a href="#"><li id="item_l1"><b>캠페인 상세정보</b></li></a>
			<a href="#"><li id="item_l2"><b>신청자 (<?php echo isset($cam_a['cnt'])?$cam_a['cnt']:'0'; ?>)</b></li></a>
            <!-- <a href="#"><li id="item_l3"><b>리뷰 ( <?php echo isset($cam_a['cnt'])?$cam_a['cnt']:'0'; ?> )</b></li></a> -->
			<a href="#"><li id="item_l3"><b>리뷰 (<?php echo isset($nct_rev['cnt'])?$nct_rev['cnt']:$rev['cnt']; ?>)</b></li></a>
			<?php }	?>
		</ul>
       

		
		<!-- ********* 캠페인상세정보 ********* -->  
		<div id="cam_campign" class="view_tap_1"> 
			<?php			
				for( $i=0; $i <= count($cam['thumbnail_img'])-1; $i++){
					//기본이미지면 안보임.
					//if( $cam['campaign_img'][$i]['thumbnail'] == 'default.png' ){
					//	echo '<div class="tap1_img">'.$cam['campaign_img'][$i]['thumbnail_img'].'</div>'; 
					//}
					
					echo '<div class="tap1_img">'.$cam['thumbnail_img'][$i].'</div>'; 					
				}				
			?>
			
			<!-- 내용 -->
			<div class="view_content"><?= $cam['cam_content'] ?></div>
			<!-- 복사테그 -->
			<?php
            //사내캠페인 다운로드 버튼.
            // mb_level == 6 ==> >=2로 변경
            // print_r2($cam);
			if( $member['mb_level'] >= '6' && $cam['cam_nct'] == '1' ){				
				/*echo '<div class="helf_dw"> <i class="fa fa-file-text" aria-hidden="true"></i> 파일크기 = <b>'.number_format($cam['file_size']).'KB</b> </div>';*/
				echo '<div class="file_dw_wrap">'.$cam['file_dw'].' </div>';
            } 
            
			// print_r2($cam) ;
			/*if( $cam['cam_tags'] != ''){
				echo '<div class="tags_title"><i class="fa fa-tags" aria-hidden="true"></i> 필수 #태그 <span class="tags_helf">(리뷰 등록 시 복사해서 사용하세요 !)</span>  
						<div class="view_copy view_btn_move"><span class="copy_icon"><i class="fa fa-external-link" aria-hidden="true"></i></span> <span class="copy_text"> 복 사 </span> </div>
					  </div>';
				echo '<div class="cam_line"></div>';
				echo '<textarea id="tags_list2" style="display: block;" readonly>#'.$cam['cam_idx'].'_kafain '.$cam['cam_tags'].'</textarea>';
			}*/
			?>

			<!-- SnS click 바로가기 -->
			<!--
			<div class="cam_sns_like">
				<div class="sns_title"><i class="fa fa-share-alt" aria-hidden="true"></i> 신청 시 필수사항 <span class="tags_helf">( 카페인 공식 SNS를 팔로우 해주세요. 팔로우한 회원들 중 체험단 선정 기회를 드립니다 !!)</span></div>
				<div class="cam_line"></div>
				<div class="sns_text"> ▼ click 바로가기 </div>
				<div class="sns_img_wrap">
				<b>
					<div class="sns_img">
						<a href="https://story.kakao.com/ch/kafain2016" target="_blank">
							<img src="<?//=G5_THEME_MOBILE_URL?>/img/sns_channel3_46.png" style="width: 95%; border-radius: 12px;">
							<div class="sns_img_text">소식받기! </div>
						</a>
					</div>
					<div class="sns_img">
						<a href="https://www.facebook.com/Kafain-1202090719802914" target="_blank">
							<img src="<?//=G5_THEME_MOBILE_URL?>/img/sns_channel3_47.png" style="width: 95%; border-radius: 12px;">
							<div class="sns_img_text">좋아요!</div>
						</a>
					</div>
					<div class="sns_img">
						<a href="https://www.instagram.com/kafain2016/" target="_blank">
							<img src="<?//=G5_THEME_MOBILE_URL?>/img/sns_channel3_48.png" style="width: 95%; border-radius: 12px;">
							<div class="sns_img_text">팔로우!</div>
							</a>
					</div>
					<div class="sns_img">
						<a href="http://www.pholar.co/my/986969/profile" target="_blank">
							<img src="<?//=G5_THEME_MOBILE_URL?>/img/sns_channel3_49.png" style="width: 95%; border-radius: 12px;">
							<div class="sns_img_text">팔로잉!</div>
						</a>
					</div>
				</b>
				</div>
			</div>
			-->
			
			<!-- 다음지도 -->	
			<div class="item_map">
				<div class="map_title"><!--<i class="fa fa-building-o" aria-hidden="true"></i>-->업체정보 </div>
				<div class="cam_line"></div>
				<div class="map_text"><?= $cam['com_addr1'];?> <?= $cam['com_addr3'];?></div>
				
				<div class="com_chk_tel"><a href="tel:<?=$cam['com_manager_hp'];?>"> TEL : <?= $cam['com_manager_hp'];?></a></div>
				
				<div id="map" style="width:100%;height:270px;margin-top:10px;display:none;"></div>
				<!--<p><em>지도를 움직여 주세요!</em></p> -->
				<!--<p id="result"></p>-->
			</div>
		</div>
		
		<!-- ********* 신청자 ********* -->
		<div id="cam_applicant" class="view_tap_2">
			
			<div class="rev_wrap">
				<div id="my_applicant_wrap">
				<?php 
				if( isset($mysql2['cma_idx']) ){
				?>	
					<div class="app_title"><!--<i class="fa fa-flag-checkered" aria-hidden="true" style="padding-right: 2px;font-size: 22px;"></i>-->나의 신청 한마디</div>
					<div class="cam_line"></div>
					<div id="my_rev_pan3" class="rev_pan">
						<?php
						for ($j=0; $my=sql_fetch_array($mysql); $j++)
						{
						?>
						<div class="con_wrap">
							<?php $my['mb_id_name_array'] = explode("^",$my['mb_id_name']);?>
							<div class="con_name">
								<?php
								//sns 이미지 추출.
								$sql2 = " SELECT * FROM {$g5['meta_table']} WHERE mta_db_id = '{$member['mb_id']}' AND mta_key IN ('kakao_img','facebook_img','instagram_img','naver_img')
										ORDER BY FIELD(mta_key,'facebook_img','kakao_img','naver_img','instagram_img') ";
								$meta_re = sql_query($sql2,1);
								
								//sns 이미지 만들기.
								for($j=0; $row2=sql_fetch_array($meta_re); $j++){
									if( $row2['mta_key'] == 'kakao_img' ){
										$row['mta_key_make'] = '<img src="'.$row2['mta_value'].'" style="width: 50px; height: 50px; border-radius: 3px;">';
									}else if( $row2['mta_key'] == 'facebook_img' ){
										$row['mta_key_make'] = '<img src="'.$row2['mta_value'].'" style="width: 50px; height: 50px; border-radius: 3px;">';				
									}else if( $row2['mta_key'] == 'instagram_img'){
										$row['mta_key_make'] = '<img src="'.$row2['mta_value'].'" style="width: 50px; height: 50px; border-radius: 3px;">';				
									}else if($row2['mta_key'] == 'naver_img'){
										$row['mta_key_make'] = '<img src="'.$row2['mta_value'].'" style="width: 50px; height: 50px; border-radius: 3px;">';				
									}
									
									if( $row2['mta_key'] == 'kakao_img' || $row2['mta_key'] == 'facebook_img' || $row2['mta_key'] == 'instagram_img' || $row2['mta_key'] == 'naver_img' ){ $j=4; break; }			
								}
								if( $j == 0 ){ $row['mta_key_make'] = '<img src="'.G5_THEME_MOBILE_URL.'/img/memer_icon01.png" style="width: 40px;">'; }
								
								?>
								<span class="rev_img"><?=$row['mta_key_make']?></span>								
								
							</div>
							<div class="con_list">
								<?php
								//선정이되면 취소안됨.
								if( !$pick2['cma_idx'] ){
									echo '<span class="appli_cancel" > 취소 </span> ';
								}
									echo '<span class="appli_update" > 수정 </span> ';
								
								?>
								<input type="hidden" name="mb_id_name_array" value="<?=$my['mb_id_name_array'][0]//아이디?>" class="mb_id_name_array"> 
								<input type="hidden" name="cam_idx" value="<?=$cam_idx?>">
								
								<div class="rev_view_name">
                                    <!-- -->
									<?=$my['mb_id_name_array'][0]//아이디?> <!--( <?//=$my['mb_id_name_array'][1]//이름?> ) --> 								
									<span class="rev_date"><?=date("Y.m.d",strtotime($my['cma_reg_dt']))?></span>
								</div>
								<div class="rev_view_content">
									<?= mb_strimwidth($my['cma_content'],'0','120',' ...','utf-8') ?>
								</div>
							</div>
						</div>
						<?php
						}
						?>
					</div>
				<?php 
				}
				echo '</div>';
				echo '<div id="chosen_rev_wrap" >';
				//선정되 후 리뷰어 발표 날짜가 같거나 지나면 보임.!!!
				if( isset($pick2['cma_idx']) and $today >= $cam_notice_dt ){
				?>	
					<div class="app_title"><!--<i class="fa fa-flag" aria-hidden="true" style="padding-right: 2px;font-size: 22px;"></i>-->선정된 리뷰어</div>
					<div class="cam_line"></div>
					<div id="at_rev_pan" class="rev_pan">
						<?php
                        // print_r2($pick2);
                        
						for ($k=0; $pi=sql_fetch_array($pick); $k++)
						    {	
							//리뷰 등록 했는지 확인하기.
							if($pi['mb_id'] == $member['mb_id'] ){
								$mem['chosen'] = '1';
							}
							//등록된 리뷰어 확인하기.							
							if($pi['mb_id'] == $member['mb_id'] ){
								$mem['no_mb_chosen'] = '1';
                            }	
						?>
						<div class="con_wrap2">
							<?php $pi['mb_id_name_array'] = explode("^",$pi['mb_id_name']);?>
							<div class="con_name2">
								<?php
								//sns 이미지 추출.
								$sql2 = " SELECT * FROM {$g5['meta_table']} WHERE mta_db_id = '{$pi['mb_id']}' AND mta_key IN ('kakao_img','facebook_img','instagram_img','naver_img')
										ORDER BY FIELD(mta_key,'facebook_img','kakao_img','naver_img','instagram_img') ";
								$meta_re = sql_query($sql2,1);
								
								//sns 이미지 만들기.
								for($j=0; $row2=sql_fetch_array($meta_re); $j++){
									if( $row2['mta_key'] == 'kakao_img' ){
										$pi['mta_key_make'] = '<img src="'.$row2['mta_value'].'" style="width: 50px; height: 50px; border-radius: 50%;">';
									}else if( $row2['mta_key'] == 'facebook_img' ){
										$pi['mta_key_make'] = '<img src="'.$row2['mta_value'].'" style="width: 50px; height: 50px; border-radius: 50%;">';				
									}else if( $row2['mta_key'] == 'instagram_img'){
										$pi['mta_key_make'] = '<img src="'.$row2['mta_value'].'" style="width: 50px; height: 50px; border-radius: 50%;">';				
									}else if($row2['mta_key'] == 'naver_img'){
										$pi['mta_key_make'] = '<img src="'.$row2['mta_value'].'" style="width: 50px; height: 50px; border-radius: 50%;">';				
									}
									
									if( $row2['mta_key'] == 'kakao_img' || $row2['mta_key'] == 'facebook_img' || $row2['mta_key'] == 'instagram_img' || $row2['mta_key'] == 'naver_img' ){ $j=4; break; }			
								}
								if( $j == 0 ){ $pi['mta_key_make'] = '<img src="'.G5_THEME_MOBILE_URL.'/img/memer_icon02.png" style="width: 40px;">'; }
								
								?>
							
								<span class="rev_img"><?=$pi['mta_key_make']?></span>								
							</div>
							<div class="con_list2">
								<div class="rev_view_name">
									<?=$pi['mb_id_name_array'][0]//아이디?> <!--( <?//=$pi['mb_id_name_array'][1]//이름?> )-->
									<span class="rev_date"><?=date("Y.m.d",strtotime($pi['cma_reg_dt']))?></span>
								</div>
							</div>
						</div>
						<?php
						}
						?>
					</div>
				<?php } ?>
				</div>

				<div id="differ_rev_wrap">
				<?php if($result2['cma_idx']){ ?>
					<div class="app_title"><!--<i class="fa fa-flag-o" aria-hidden="true" style="padding-right: 2px;font-size: 22px;"></i>-->신청자 한마디</div>
					<div class="cam_line"></div>
				<?php } ?>
					<div id="ap_rev_pan" class="rev_pan">			
						<div id="my_ap_aj">
							<!-- ajax로 입력됨. -->
						</div>
						<!-- 페이징 -->
						<nav class="pg_wrap" style="display:none;">
							<span class="pg">
							  <span><a href="#">first</a></span>
							  <span><a href="#">prev</a></span>
							  <span><a href="#">1</a></span>
							  <span><a href="#">2</a></span>
							  <span><a href="#">3</a></span>
							  <span><a href="#">4</a></span>
							  <span><a href="#">5</a></span>
							  <span><a href="#">next</a></span>
							  <span><a href="#">last</a></span>
							</span>
						</nav>						
					</div>
				</div>				
			</div> <!-- rev_wrap -->
		</div>
        <?php 
        
        // print_r2($cam);
        
        ?>
		<!-- ********* 리뷰 ********* -->
		<div id="cam_review" class="view_tap_3">						
			<!-- 리뷰등록 후 리뷰등록하기 버튼 보여지는건 u_review테이블에 입력된걸로 판단함. -->
			<div class="rev_wrap">
				<div id="my_rev_wrap">	
					<div class="rev_title"><!--<i class="fa fa-flag-checkered" aria-hidden="true" style="padding-right: 2px;font-size: 22px;"></i>-->나의 리뷰 
						<div class="rev_main_update view_btn_move"><!--<span class="copy_icon"><i class="fa fa-angle-double-down" aria-hidden="true"></i></span>--><span class="copy_text">수정</span> </div>						
					</div>
                    <?//php if ($mem['chosen'] = '1') {?>
					<div class="cam_line"></div>
					<div id="fmy_rev_wrap">
						<div class="my_rev_summary"><?php echo $is_member==''?'로그인 후 등록가능 합니다.':''; ?></div>
						<div class="view_ap_btn_move my_rev_btn2"><!--<span class="copy_ap_icon"><i class="fa fa-pencil" aria-hidden="true"></i></span>--><span class="copy_ap_text">리뷰 등록하기</span> </div>						
					</div>
                    <? //}
                    
                    ?>
					<form name="review_sns" action="" method="post">
						<input type="hidden" name="mb_id" value="<?=$member['mb_id']?>">
						<input type="hidden" name="mb_level" value="<?=$member['mb_level']?>">						
						
						<div id="my_rev_pan2">
							<div class="close_btn_wrap">
								<span class="sns_question"> 리뷰URL등록하는법 ? </span> <span id="close_btn" class="close_btn"> <i class="fa fa-angle-double-up" aria-hidden="true"></i> </span>
							</div>
							<div class="rev_url_panner_wrap">
                                <?php include_once(G5_THEME_PATH.'/shop/
                                .php'); // POP PANNER ?>
							</div>
							
							
							<div class="pan2_text1">1. 등록할 리뷰 SNS를 추가한 후 URL을 기재해주세요.</div>
							<div class="pan2_sns_p">
								<div class="pan2_sns_wrap">
									<?php
									echo '<div class="item_sns_img">';
									
									//사내 캠페인 이면서 회원lv6[회사직원]일때만.
									if( $member['mb_level'] == '6' && $cam['cam_nct'] == '1' ){
										$rev_sns['rev_channels_array'] = explode(",",$cam['cam_channels']);
										$rev_sns['rev_channels_device'] = $cam['cam_channels'];
									}else{
										$rev_sns['rev_channels_array'] = explode(",",$rev_sns['rev_channels']);
										$rev_sns['rev_channels_device'] = $rev_sns['rev_channels'];
									}
									
									if( $rev_sns['rev_channels_device'] ) {
										sort($rev_sns['rev_channels_array']);
										foreach ($rev_sns['rev_channels_array'] as $key) {
											if( $key != '0' ){
												echo '<a href="javascript:snsChannel('.$key.')">';
													echo '<img id="btnAdd" src="'.G5_THEME_MOBILE_URL.'/img/sns_channel3_'.$key.'.png" title="'.$g5['sns_channel'][$key].'" style="width:12%;margin-right:1%;" />';
												echo '</a>';
											}
										}
									}
									echo '</div>';
									?>
								</div>
								
								<!--rev_idx 최종번호를 넘겨줌. (수정완료되면 ajax로 값이 변경됨.) ( 리뷰테이블에 내 리뷰등록 확인할때도 사용함. )-->
								<input type="hidden" name="form_rev_idx" class="form_rev_idx" value="<?=$rev_up2['rev_idx']?>">
								
								<!--sns list 추가되는 부분 -->
								<div class="pan2_list_wrap">
									<ul id="snsList" class="snsList">										
										<?php										
										//수정일때만 적용.
										if( $rev_up2['rev_idx'] ){
											for ($i=0; $row=sql_fetch_array($rev_up); $i++){
												//sns_key => sns key 번호												
												echo '<input type="hidden" name="rvu_url2_'.$i.'" value="'.$row['rvu_url'].'">';
												echo '<input type="hidden" name="rvu_title_'.$i.'" value="'.$row['rvu_title'].'">';
												echo '<input type="hidden" name="rvu_tag_'.$i.'" value="'.$row['rvu_tag'].'">';
												
												//sns 체널 확인배열
												$row['trm_idx_array'] = explode(',',$row['trm_idx']);
												
												$row['rvu_title'] = $row['rvu_title'] ? $row['rvu_title'] : $row['rvu_url'];
												
												//블로그 RSS(로컬test는 않됨.)
												$mta = sql_fetch(" SELECT * FROM {$g5['meta_table']} WHERE mta_db_id = '".$row['mb_id']."' AND mta_key = 'naver_login' ");	//블로그
												if( $mta['mta_value'] && $_SERVER['HTTP_HOST'] != 'localhost'){
													$cam['naver_title_option'] = naver_blog_list2($mta['mta_value']);
												}
												
												echo '<li>';
													if( in_array('50', $row['trm_idx_array']) ){
														/*echo '<img src="'.G5_THEME_MOBILE_URL.'/img/sns_channel2_'.$row['trm_idx'].'.png" style="width:42px;margin-right:7px;" />';								
														echo '<input type="hidden" name="sns_url[]" value="'.$row['rvu_url'].'^'.$row['rvu_title'].'^'.$row['rvu_tag'].'^" class="sns_url_put" id="sns_url_put'.$i.'">';
														 echo '<input type="hidden" name="sns_key[]" value="'.$row['trm_idx'].'">';
														echo '<select name="sns_url[]" id="blog_url_'.$i.'" class="blog_url"> '.$cam['naver_title_option'].' </select>';
                                                        echo '<a class="sns_btn_del"><i class="fa fa-times" aria-hidden="true"></i></a>';*/
                                                        /// 기본 블로그 url 값이 아닌 sns채널 key으로 변경하였기 때문에 기존 구조 남긴후 수정
                                                        echo '<img src="'.G5_THEME_MOBILE_URL.'/img/sns_channel2_'.$row['trm_idx'].'.png" style="width:42px;margin-right:7px;" />';								
														echo '<input type="text" name="sns_url[]" value="'.$row['rvu_url'].'" class="sns_url_put" id="sns_url_put'.$i.'"> <input type="hidden" name="sns_key[]" value="'.$row['trm_idx'].'">';													
														echo '<a class="sns_btn_del"><i class="fa fa-times" aria-hidden="true"></i></a>';	
													}else{
														echo '<img src="'.G5_THEME_MOBILE_URL.'/img/sns_channel2_'.$row['trm_idx'].'.png" style="width:42px;margin-right:7px;" />';								
														echo '<input type="text" name="sns_url[]" value="'.$row['rvu_url'].'" class="sns_url_put" id="sns_url_put'.$i.'"> <input type="hidden" name="sns_key[]" value="'.$row['trm_idx'].'">';													
														echo '<a class="sns_btn_del"><i class="fa fa-times" aria-hidden="true"></i></a>';														
													}																								
												echo '</li>';
											?>
											<script>
											$(function() {
												//블로그 리뷰 선택하기.
												var rvu_url_<?=$i?> = $("input[name='rvu_url2_"+<?=$i?>+"']").val();
												var rvu_title_<?=$i?> = $("input[name='rvu_title_"+<?=$i?>+"']").val();
												var rvu_tag_<?=$i?> = $("input[name='rvu_tag_"+<?=$i?>+"']").val();												
												//console.log(rvu_url_<?=$i?>+"^"+rvu_title_<?=$i?>+"^"+rvu_tag_<?=$i?>);
												
												$("#blog_url_"+<?=$i?>+"").val(rvu_url_<?=$i?>+"^"+rvu_title_<?=$i?>+"^"+rvu_tag_<?=$i?>).prop("selected",true);
											});
											</script>
											<?php
												
											}
											
											//class만들기.
											$row['my_rev_btn_make'] = "rev_update";
										}else{
											//class만들기.
											$row['my_rev_btn_make'] = "my_rev_btn3";
										}
										?>
									</ul>
								</div>
							</div>
							
							<div class="pan2_text1">2. 캠페인에 만족하셨나요 ?</div>
							<div class="pan2_content">
								<textarea name="rev_content" placeholder="50자 이내로 입력해주세요." maxlength="50" ><?=$rev_up2['rev_content']?></textarea>
							</div>
							
							<div class="pan2_text2">
								<div class="text3_title">※ 캠페인 참여시 확인사항</div>
								<div class="text3_list">1. 캠페인에 참여한 리뷰는 홍보나 필요에 의해 사용될 수 있습니다. </div>
								<div class="text3_list">2. 리뷰 태그에 반드시 카페인 해시태그가 삽입되어야 캠페인 참여로 인정됩니다.</div>
								<div class="text3_list">3. 캠페인과 관련없는 글은 통보없이 삭제될 수 있습니다.</div>
							</div>
							<div class="view_ap_btn_move <?=$row['my_rev_btn_make']?>" id="pan2_btn"><!--<span class="copy_ap_icon"><i class="fa fa-pencil" aria-hidden="true"></i></span>--><span class="copy_ap_text">리뷰 등록 </span></div>
							
						</div>
					</form> 
					
					<!----- 나의리뷰 리스트  ----->
					<div id="my_rev_pan4">
						<div class="div_loading_myrev" > <i class="fa fa-refresh fa-spin fa-3x fa-fw"></i> </div>						
						<div id="my_rev_aj">						
                            <!-- ajax로 입력됨. -->

						</div>						
					</div>					
					<!----- //나의리뷰 리스트 ----->
					
				</div>
								
				<!----- 리뷰 리스트  ----->
				
				<?php
				//if( $mem['no_mb_chosen'] == '0' ){				
				?>
				<div id="register_rev_wrap">
					<div class="rev_title"><!--<i class="fa fa-flag-o" aria-hidden="true" style="padding-right: 2px;font-size: 22px;"></i>-->등록된 리뷰어 </div>
					<div class="cam_line"></div>				
					<div id="rev_list_pan">
						<div class="div_loading_rev" > <i class="fa fa-refresh fa-spin fa-3x fa-fw"></i> </div>						
						<div id="rev_list_aj">						
							<!-- ajax로 입력됨. -->
						</div>						
					</div>					
				</div>
				<?php
                //}
                
				?>
				<!----- //리뷰 리스트 ----->
				
			</div>	<!-- rev_wrap -->
		</div> <!-- cam_review -->
		
	</div>
	
	<!-- ********* 인스타 ********* -->
	<div class="view_divide_b_wrap"> 
		<?php
		if( isset($trm['trm_name']) && $today > $cam_review_end_dt ){
			echo '<div class="h_tag">';
				echo '<div class="app_title ">#TAG</div>';
				echo '<div class="cam_line"></div>';
				echo '<div class="insta_tag"></div>';
			echo '</div>';
			echo '<div class="tag_plus"> <div class="view_btn_move"><span class="copy_text">더보기</span> </div> </div>';	
		}	
		?>
	</div>
</div>


<!-- **** 오른편 **** -->
<div class="cam_view_right_total_wrap">
	<div class="item_list_w">
		<div class="item_list_title"> <i class="fa fa-plus-circle fa_title_left" aria-hidden="true"></i> 캠페인 안내 <i class="fa fa-plus-circle fa_title_right" aria-hidden="true"></i> </div>
		<div class="item_t">캠페인 타입</div><div class="item_l">
		<?php
            if ($cam['cam_type'] == 'visite') {
                echo '방문형';
            }elseif( $cam['cam_type'] == 'PressCorps'){
				echo '기자단';
			}elseif ($cam['cam_type'] == 'delivery') {
                echo '배송형';
            }elseif ($cam['cam_type'] == 'receipt') {
                echo '영수증리뷰';
            }elseif ($cam['cam_type'] == 'reservation') {
                echo '예약자리뷰';
            }
		?>
		</div>
		<div class="item_t">캠페인 상권</div><div class="item_l"><?= $salesarea_name[$cam['trm_idx_salesarea']]?></div>
		<div class="item_t">캠페인 방식</div><div class="item_l"><?php echo $cam['cam_reviewer_yn'] == '1'?'리뷰어 모집 캠페인':'리뷰어 비모집 캠페인'; ?></div>
		<div class="item_t"><?= $cam['cam_nct_only'] == '1'? '리뷰등록 기간' : '캠페인 시간'; ?>   </div><div class="item_l2">
			<?php
			if( $cam['cam_nct_only'] == '1' ){
				echo $cam_recruit_start_dt.' ~ '.$cam_review_end_dt;
			}else{
				echo $cam_recruit_start_dt.' ~ '.$cam_review_end_dt;
			}
			?>
		</div>
		
		<div class="item_t"><?= $cam['cam_nct_only'] == '1'? '사내 모집인원' : '모집인원'; ?></div><div class="item_l2">
			<?php 
			if( $cam['cam_nct_only'] == '1' ){
				//사내 캠페인 만 진행
				echo $cam['cam_nct_cnt'].' 명';
			}else{
				//일반,사내 진행 캠페인
				if( ($member['mb_level'] == '6' || $my_cam_lv == '4') && $cam['cam_nct'] == '1' ){
					echo $cam['cam_recruit_count'].' 명 (사내: '.$cam['cam_nct_cnt'].' 명)';
				}else{
					echo $cam['cam_recruit_count'].' 명';
				}
			}
			?>
		</div>
		<div class="item_t">등록가능한 리뷰</div>
		<div class="item_l">
			<?php			
			echo '<div class="cam_sns">';
			if($cam['cam_channels']) {
				$cam['cam_channels_array'] = explode(",",$cam['cam_channels']);
				sort($cam['cam_channels_array']);
				foreach ($cam['cam_channels_array'] as $key) {
					echo '<img src="'.G5_THEME_IMG_URL.'/sns_channel_'.$key.'.png" title="'.$g5['sns_channel'][$key].'" style="width:20px;margin-right:5px;" />';
				}
			}
			echo '</div>';
			?>
		</div>
	</div>
	
	<!-- 캠페인 신청하기. -->
	<?php
		//한번 신청한 캠페인은 다시회차,다음회차 캠페인에서 신청 안되도록 하기.
		if( $ap_ck['cam_idx'] ){
			echo '<div class="not_ap">중복선정 방지</div><div class="not_ap_sub">같은종류의 캠페인을 이전에 신청하셨습니다.</div>';
		}else{
			echo '<div class="view_ap_btn_move view_ap_main"><span class="copy_ap_icon"><i class="fa fa-pencil" aria-hidden="true"></i></span> <span class="copy_ap_text">체험 신청하기</span> </div>';
		}		
	?>
	
	<!-- 캠페인 세로리스트-->
	<div class="cam_list_vertical_wrap">
		<div class="cam_list_vertical_title"> <i class="fa fa-plus-circle fa_title_left" aria-hidden="true"></i> 추천 캠페인 <i class="fa fa-plus-circle fa_title_right" aria-hidden="true"></i> </div>
		<div class="div_loading" > <i class="fa fa-refresh fa-spin fa-3x fa-fw"></i> </div>
		<div class="cam_vertical_device_wrap"><!-- ajax 반복 --></div>
	</div>
	
</div>

<!-- **** 체험신청 페이지 **** -->
<div class="cam_ap_panel_bk_wrap <?=$explorer_ver_css?>">
	<div class="cam_ap_panel_bk_close"><i class="fa fa-angle-double-left" aria-hidden="true"></i></div>
	<div class="cam_ap_panel_wrap">
		<div class="item_menu">  		
			<div class="item_ask1"> <i class="fa fa-plus-circle fa_title_left2" aria-hidden="true"></i> 체험신청 <i class="fa fa-plus-circle fa_title_right2" aria-hidden="true"></i> </div>		
			<form name="review_ask" id="review_ask" action="./shop_view_ask_update.php" method="post">
				<input type="hidden" name="mb_id" value="<?=$member['mb_id']?>">
				<input type="hidden" name="cam_idx" value="<?=$cam_idx?>">
				<input type="hidden" name="cam_review_end_dt" value="<?=$cam_review_end_dt?>">
                <?php 
                
                //print_r2($member);
                
                ?>
				<?php  //delivery visite
				if($cam['cam_type'] == 'delivery'){
				?>
				<div class="item_ask">1. 체크사항</div>
				<textarea readonly class="item_ask_check"><?php echo $setting['set_mobile_check2']; ?></textarea> 
				<span class="item_chk_check"> <input type="checkbox" name="chk" value="" id="item_chk_check"> <label for="item_chk_check">위체크사항을 숙지하였으면 동의합니다.</label></span>
				<?php 
				}else{
				?>
				<div class="item_ask">1. 체크사항</div>
				<textarea readonly class="item_ask_check"><?php echo $setting['set_mobile_check1']; ?></textarea> 
				<span class="item_chk_check"> <input type="checkbox" name="chk" value="" id="item_chk_check"> <label for="item_chk_check">위체크사항을 숙지하였으면 동의합니다.</label></span>
				<?php } ?>
				
				<div class="item_ask">2. 신청사연</div>
				<textarea name="cma_content" placeholder="신청사연을 적지 않으시면 체험단 선정이 어려우니 반드시 적어주세요.(50자 이내)" class="item_ask_textarea" maxlength="50"></textarea>					
				
				<div class="item_ask">
					<?php					
					if( count($cam['cam_channels_array']) == 1 && in_array('50', $cam['cam_channels_array']) ){
						echo "3. 리뷰할 블로그";
					}else{
						echo "3. 리뷰할 SNS 선택";
					}
					?>					
				</div>
				
				<div class="item_sns">
					<?php
                    // print_r2($setting);
					//블로그상품 환경설정 값 배열로 만들기.
					$set_naver_product_array = explode(',',$setting['set_naver_product']);
					
					echo '<input type="hidden" name="cam_channels_length" value="'.$cam['cam_channels'].'" >';
					
					echo '<div class="rev_item_sns_img">';
					if($cam['cam_channels']) {
						$cam['cam_channels_array'] = explode(",",$cam['cam_channels']);
						sort($cam['cam_channels_array']);
						echo '<input type="hidden" name="cam_channel_50_ck" value="'.in_array('50', $cam['cam_channels_array']).'" >';
						
						//sns 신청할수 있는 cnt 추출해서 css %값 만들기.						
						$cam_channels_div_css = 99/count($cam['cam_channels_array']);
						
						foreach ($cam['cam_channels_array'] as $key) {
							///$class2 = ($member['sns_channel_'.$key.'_url']) ? 'sns_url_plus' : '';

							//key값이 블로그(50) 이면서, 블로그상품 배열안에 블로그상품일때만 보여라!
							if( $key == '50' && in_array($cam['pdo_prd_name'], $set_naver_product_array) ){
								echo '<div class="ro_rev_channel_wrap" style="width:'.$cam_channels_div_css.'%">';
								echo '<div class="ro_rev_channel">';
								echo '<img src="'.G5_THEME_MOBILE_URL.'/img/sns_channel2_'.$key.'.png" title="'.$g5['sns_channel'][$key].'" class="item_sns'.$key.'" style="max-width: 100px;" />';
								echo '<input type="hidden" name="sns_channel_'.$key.'" value="'.$key.'"  class="sns_plus">';
								echo '<input type="hidden" name="sns_channel_'.$key.'_url" value="" class="sns_url_plus">';
								echo '</div>';
								echo '</div>';
                            }

                            
                            /*$key = 50 네이버 블로그*/
                            /*key 50 으로 설정되있습 제거후 블로그 페이지 나옴*/
                            /*facebook 사용 X facebook key값 설정후 제거 */
							if( $key != '46' ){
								echo '<div class="ro_rev_channel_wrap" style="width:'.$cam_channels_div_css.'%">';	
								echo '<div class="ro_rev_channel">';	
								echo '<a class="snsBtn" href="javascript:" key='.$key.'>';
								echo '<img src="'.G5_THEME_MOBILE_URL.'/img/sns_channel2_off_'.$key.'.png" title="'.$g5['sns_channel'][$key].'" class="item_sns'.$key.'" style="max-width: 100px;" />';
								echo '<input type="hidden" name="sns_channel_'.$key.'" value="" >';
								echo '<input type="hidden" name="sns_channel_'.$key.'_url" value="" >';
								echo '</a>';
								echo '</div>';
								echo '</div>';
							}
						}
					}
                    echo '</div>';
                    
                    ?>
                    <?php 
                    // print_r2($key);
                    //  print_r2($cam);
                    ?>
					<div class="sns_url_box">
						<div class="sns_url_bg"></div>
						<div class="sns_url_input_box">
							<span id="sns_mypage_ex" class="sns_mypage_ex">마이페이지에서 연동해주세요.</span>							
							<div class="sns_mypage"><div class="sns_mypage_div"></div><a class="sns_mypage_a" href="<?=G5_URL?>/_u/k/shop_mypage.php?kafain_head=public">이동</a></div>
							<a class="sns_url_cancel" href="javascript:" key=""><i class="fa fa-times" aria-hidden="true"></i></a>
						</div>
					</div>
					<!--폴라 정보입력 때문에 사용함.-->
					<div class="sns_url_box2">
						<div class="sns_url_bg"></div>
						<div class="sns_url_input_box">
							<input class="sns_url" type="text" placeholder="">
							<a class="url_question"> ? </a>
							<a class="sns_url_btn" href="javascript:">입력</a>
							<a class="sns_url_cancel" href="javascript:" key="">취소</a>
						</div>
					</div>
					
				</div>

				<div class="item_sns_text">
					<?php
					if( count($cam['cam_channels_array']) == 1 && in_array('50', $cam['cam_channels_array']) ){
						echo " ";
					}else{
						echo "( 중복 선택 시 당첨확률 UP )";
					}
					?>						
				</div>

				<?php				
				//블로그 신청한 캠페인 확인 , 블로그상품 배열안에 블로그상품일때만 보여라 , 네이버 아이디 미입력한 회원만.
				if(  in_array('50', $cam['cam_channels_array']) && in_array($cam['pdo_prd_name'], $set_naver_product_array) && !$member['naver_login']  ){
					echo '<div class="sns_naver_wrap">
							<img id="blog_img" style="width: 40px;" src="'.G5_THEME_MOBILE_IMG_URL.'/sns_channel2_rect_naver.png">						
							<input type="text" name="sns_naver_id" id="sns_naver_id" class="sns_naver_id" value="'.$member['naver_login'].'" placeholder="네이버 로그인 아이디 입력!" >
							<span class="sns_btn_50">저장</span> 
							<div class="item_sns_text sns_btn_50_text"> ( <i class="fa fa-exclamation-triangle" aria-hidden="true"></i> 네이버 아이디 입력해야 블로그 연동이 됩니다. ) </div>
						 </div>';
				}else{
					echo '<input type="hidden" name="sns_naver_id" id="sns_naver_id" class="sns_naver_id" value="'.$member['naver_login'].'" >';
				}
				?>

				<?php  //delivery visite
					if($cam['cam_type'] == 'delivery'){
					//지번만들기.
					$cam['mb_zip'] = $member['mb_zip1'].''.$member['mb_zip2'];
				?>

				<div class="item_ask">4. 주소</div>
				<div class="item_addr_wrap">
					<input type="text" id="address_text" name="cma_addr1" onclick="sample5_execDaumPostcode()" value="<?= $cam['cma_addr1']?$cam['cma_addr1']:$member['mb_addr1'];?>" placeholder="주소 검색으로 이용해 주세요." style="width:45%;height: 30px;" class="frm_input" readonly="readonly">
					<input type="text" id="cma_addr3" name="cma_addr3" value="<?= $cam['cma_addr3']?$cam['cma_addr3']:$member['mb_addr3'];?>" placeholder="나머지 주소 입력해주세요." style="width:30%;height: 30px;" class="frm_input" >
					<input type="button" onclick="sample5_execDaumPostcode()" value="주소검색"  class="btn_frmline"><br>
					<!--
					<div id="wrap" style="display:none;border:1px solid #b9b9b9;width:93%;height:300px;margin:2% 0;position:relative;z-index:1;">
					<img src="//i1.daumcdn.net/localimg/localimages/07/postcode/320/close.png" id="btnFoldWrap" style="cursor:pointer;position:absolute;right:-20px;top:-1px;z-index:1" onclick="foldDaumPostcode()" alt="접기버튼">
					</div>				
					-->
					<input type="hidden" name="cma_zip" id="cma_zip" value="<?= $cam['cma_zip']?$cam['cma_zip']:$cam['mb_zip']; ?>">
					<input type="hidden" name="cma_jibeon" value="<?= $cam['cma_jibeon']?$cam['cma_jibeon']:$member['mb_addr_jibeon']; ?>">
					<!-- 팝업함수 사용하려면 = sample5_execDaumPostcode  -->
				</div>

				<?php
					}
				?>

				<div class="div_loading_ask" > <i class="fa fa-refresh fa-spin fa-3x fa-fw"></i> </div>				
				<div class="view_ap_btn_move ask_btn" id="ask_btn"><span class="copy_ap_icon"><i class="fa fa-paper-plane" aria-hidden="true"></i></span> <span class="copy_ap_text" id="ask_btn_text">체험신청</span></div>
				<!-- <div class="my_rev_btn1"><a id="ask_btn" class="ask_btn">체험신청</a></div> -->
			</form>
			
			<!-- URL 슬라이드 PANNER S-->
			<div class="url_question_wrap" style="display:none;">
				
				<!-- 내용 입력부분 -->
				<div class="pop_q_contents2">
					<!-- 닫기 -->
					<div class="ap_pop_q_close"><i class="fa fa-times" aria-hidden="true"></i></div>
					
					<div class="pop_q_img_wrap">
						<!-- 이미지 입력 부분. -->
						<!-- Swiper -->
						<div class="swiper-container_url">
							<div class="swiper-wrapper">
											
							</div>
							<!-- Add Pagination -->
							<div class="swiper-pagination_url swiper-pagination"></div>
						</div>
					</div>
				</div>
			</div>
			<!-- URL 슬라이드 PANNER E-->
		
		</div> 
	</div>
	
	<input type="hidden" name="mem_chosen" class="mem_chosen" id="mem_chosen" value="<?=$mem['chosen']?>">	
    <input type="hidden" name="no_mb_chosen" class="no_mb_chosen" id="no_mb_chosen" value="<?=$mem['no_mb_chosen']?>">	
    
</div>


<script src="https://spi.maps.daum.net/imap/map_js_init/postcode.v2.js"></script>
<?php if($cam['com_latitude']){ ?>
<script type="text/javascript" src="//dapi.kakao.com/v2/maps/sdk.js?appkey=ea2aeb6ed300193daa994029f92cc170"></script>

<script>
//지도 보여라.
$('#map').css('display','block');

//좌표.
var com_latitude = $('input[name="com_latitude"]').val();
var com_longitude = $('input[name="com_longitude"]').val();
//좌표없으면.
if( !com_latitude ){ com_latitude = 0; }
if( !com_longitude ){ com_longitude = 0; }

var mapContainer  = document.getElementById('map'), //이미지 지도를 표시할 div  
    mapOption = { 
        center: new daum.maps.LatLng(com_latitude, com_longitude), //이미지 지도의 중심좌표
        level: 3, //이미지 지도의 확대 레벨
        //marker: markers //이미지 지도에 표시할 마커 
    };    

// 이미지 지도를 생성합니다
var map = new daum.maps.Map(mapContainer, mapOption);

// 마커가 표시될 위치입니다 
var markerPosition  = new daum.maps.LatLng(com_latitude, com_longitude); 

// 마커를 생성합니다
var marker = new daum.maps.Marker({
    position: markerPosition,
});

// 마커가 지도 위에 표시되도록 설정합니다
marker.setMap(map);

</script>

<!--} 다음 지도-->
<?php  } ?>

<script>
//********* 리뷰 페이지 *********
//리뷰 등록할 sns리스트 추가
function snsChannel(sns_key){
	var n = $("#snsList>li").length;//count
    var naver_title_option = '<?=$cam['naver_title_option']?>';
	var naver_login = $("input[name='naver_login']").val();
	//구조만들기.
	if( sns_key == '50' ){
		if( !naver_login ){
			alert('---- NAVER 아이디 입력해주세요. ----');
			location.replace(g5_user_url+'/k/shop_mypage.php?kafain_head=public'); //이동!
		}else{
            // 기존 블로그 값의 옵션 선택창 --> 다른 sns 채널처럼 구조 변경 
			/*var newRow = '<li><img src="'+g5_theme_url +'/mobile/img/sns_channel2_'+sns_key+'.png" style="width:42px;margin-right:7px;" />' + '<select name="sns_url[]" id="blog_url">'+naver_title_option+'</select> <input type="hidden" name="sns_key[]" id="sns_key_put'+sns_key+'" value="'+sns_key+'"><a class="sns_btn_del"><i class="fa fa-times" aria-hidden="true"></i></a> </li>';*/
            var newRow = '<li><img src="'+g5_theme_url +'/mobile/img/sns_channel2_'+sns_key+'.png" style="width:42px;margin-right:7px;" />'
						+ '<input type="text" name="sns_url[]" class="sns_url_put" id="sns_url_put'+sns_key+'"> <input type="hidden" name="sns_key[]" id="sns_key_put'+sns_key+'" value="'+sns_key+'"><a class="sns_btn_del"><i class="fa fa-times" aria-hidden="true"></i></a> </li>';
		}		
	}else{
		var newRow = '<li><img src="'+g5_theme_url +'/mobile/img/sns_channel2_'+sns_key+'.png" style="width:42px;margin-right:7px;" />'
						+ '<input type="text" name="sns_url[]" class="sns_url_put" id="sns_url_put'+sns_key+'"> <input type="hidden" name="sns_key[]" id="sns_key_put'+sns_key+'" value="'+sns_key+'"><a class="sns_btn_del"><i class="fa fa-times" aria-hidden="true"></i></a> </li>';
	}
	//입력.
	//newRow.insertAfter($("#snsList>li:last"));
	$("#snsList").append(newRow);
};
////********* 리뷰 페이지 *********

//**** 다음 주소 시작 (팝업)****
function sample5_execDaumPostcode() {
	new daum.Postcode({
		oncomplete: function(data) {
			// 각 주소의 노출 규칙에 따라 주소를 조합한다.
			// 내려오는 변수가 값이 없는 경우엔 공백('')값을 가지므로, 이를 참고하여 분기 한다.
			var fullAddr = data.address; // 최종 주소 변수
			var extraAddr = ''; // 조합형 주소 변수
			var zonecode = data.zonecode;
			var addressType = data.addressType;
			
			// 기본 주소가 도로명 타입일때 조합한다.
			if(data.addressType === 'R'){
				//법정동명이 있을 경우 추가한다.
				if(data.bname !== ''){
					extraAddr += data.bname;
				}
				// 건물명이 있을 경우 추가한다.
				if(data.buildingName !== ''){
					extraAddr += (extraAddr !== '' ? ', ' + data.buildingName : data.buildingName);
				}
				// 조합형주소의 유무에 따라 양쪽에 괄호를 추가하여 최종 주소를 만든다.
				fullAddr += (extraAddr !== '' ? ' ('+ extraAddr +')' : '');
			}

			// 주소 정보를 해당 필드에 넣는다.
			document.getElementById("address_text").value = fullAddr;
			document.review_ask.cma_zip.value = zonecode; //cam_zip  new 우편번호
			document.review_ask.cma_jibeon.value = addressType; //cam_zip  new 우편번호
		}
	}).open();
}
//**** 다음 주소 끝 ****
</script>
