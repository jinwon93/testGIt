<?php
if (!defined("_GNUBOARD_")) exit; // 개별 페이지 접근 불가

// add_stylesheet('css 구문', 출력순서); 숫자가 작을 수록 먼저 출력됨
add_stylesheet('<link rel="stylesheet" href="'.$kafain_skin_url.'/style.css">', 0);

// 참고.
// 상품을 신청할때 업체에 연결된 담당자가 선택되면 신청한 상품으로 만들어진 캠페인의 담당자는, 상품신청때 선택된 담당자로 계속 사용된다.
// 캠페인 신청 및 수정시 업체는 변경해도 담당자는 변경되지 안는다.  
?>

<div class="mbskin">
<form id="cp_f" name="cp_f" action="<?php echo $register_action_url ?>" onsubmit="return cp_f_submit1(this);" method="post" enctype="multipart/form-data" autocomplete="off">
    <input type="hidden" name="w" value="<?= $w ?>">
   <!--<input type="hidden" name="cam_mb_name" value="<?//= get_session("ss_mb_id") ?>">-->
    <input type="hidden" name="cam_idx" value="<?= $cam_idx != '' ? $cam_idx : $cam['cam_idx']; ?>">
    <input type="hidden" name="pdo_idx" value="<?= $pdo_idx != '' ? $pdo_idx : $cam['pdo_idx']; ?>">    	
    <input type="hidden" name="cam_mb_name" value="<?= $member['mb_name'] ?>">	
    <input type="hidden" name="cam_mb_tel" value="<?= $w =='u' ? $cam['cam_mb_tel'] : $member['mb_hp'];?>">
    <input type="hidden" name="cam_mb_email" value="<?= $cam['com_email'] ?>">	
    <input type="hidden" name="cam_mb_saler" value="<?= $proo['mb_name'] ?>"> <!-- 담당자명 -->
	<input type="hidden" name="cam_prd_time" value="<?= $cam['cam_prd_time'] != '' ? $cam['cam_prd_time'] : $proo['cam_count']+1 ?>"> <!--상품회차-->
	
	<input type="hidden" name="blog_check" value="<?= $blog_check ?>"><!-- 블로그상품 확인 변수 (있을때만 1) -->
	<input type="hidden" name="set_naver_product" value="<?= $setting['set_naver_product'] ?>"><!-- 블로그상품 환경설정 값 배열-->
	
    <?php if (isset($member['mb_sex'])) {  ?><input type="hidden" name="mb_sex" value="<?php echo $member['mb_sex'] ?>"><?php }  ?>
    <?php if (isset($member['mb_nick_date']) && $member['mb_nick_date'] > date("Y-m-d", G5_SERVER_TIME - ($config['cf_nick_modify'] * 86400))) { // 닉네임수정일이 지나지 않았다면  ?>
    <input type="hidden" name="mb_nick_default" value="<?php echo get_text($member['mb_nick']) ?>">
    <input type="hidden" name="mb_nick" value="<?php echo get_text($member['mb_nick']) ?>">
    <?php } ?>

	<div class="tbl_frm01 tbl_wrap">
		<table>
		<tbody>
		<?php
		//신규일때만 자동등록 가능. ,구매캠페인횟수 == 캠페인 만들어진 수
		if($w == '' && $proo['pdo_prd_times'] != $proo['cam_count']+1 ){
		?>
		<tr>
            <th scope="row"><label for="auto_cam_make">자동캠페인 등록<strong class="sound_only">필수</strong><span class="agree_ck"> 필수 </span></label></th>
            <td>
				<div class="form_help">구매한 상품회차 및 남은회차 만큼 자동등록 됩니다.</div>
				<input type="radio" name="cam_auto_make_yn" value="1" id="cam_auto_make_yn1"  class="cam_auto_make_yn" <?php echo ($cam['cam_auto_make_yn']=='1')?'checked':''; ?> checked="checked" > &nbsp<label for="cam_auto_make_yn1"> 사용 &nbsp </label>
				<input type="radio" name="cam_auto_make_yn" value="0" id="cam_auto_make_yn0"  class="cam_auto_make_yn" <?php echo ($cam['cam_auto_make_yn']=='0')?'checked':''; ?>> &nbsp<label for="cam_auto_make_yn0"> 사용안함 </label>
				<input type="hidden" name="pdo_prd_times" value="<?= $proo['pdo_prd_times'] ?>"> <!--상품회차-->
			</td>
        </tr>
		<?php
		}else{
			echo '<input type="hidden" name="cam_auto_make_yn" value="0">';
			echo '<input type="hidden" name="pdo_prd_times" value="'.$proo['pdo_prd_times'].'">';
		}
		?>
		
		<?php
		//상단에 캠페인 신청 버튼으로 들어 왔을때. 
		if($kfi == '1'){
		?>
		<tr>
            <th scope="row"><label for="goods_check">구매상품선택<strong class="sound_only">필수</strong><span class="agree_ck"> 필수 </span></label></th>
            <td> 
				<?php
					$sql2 = " SELECT pdo_idx, mb_id, mb_id_saler, pdo_pay_status, pdo.prd_idx, pdo_recruit_count, pdo_prd_name AS prd_name, pdo_prd_times AS prd_times							
								,( SELECT count(cam_idx) FROM {$g5['campaign_table']} WHERE pdo_idx = pdo.pdo_idx AND cam_status IN ('pending','reject','re_pending','ing','ok') ) AS cam_count
								,( SELECT mb_name FROM {$g5['member_table']} WHERE mb_id = pdo.mb_id_saler ) AS mb_name
							FROM {$g5['product_order_table']} AS pdo 
							WHERE pdo_pay_status = 'payall' AND pdo_status = 'ok' AND mb_id = '{$member['mb_id']}'
							ORDER BY pdo.pdo_idx DESC
							"; 											 
					$result = sql_query($sql2,1);
					$confirm = sql_fetch($sql2,1);
					//echo $sql2;
				?>				
				<select name="goods_check" class="cp_field" style="width:32%" id="goods_check" onchange="goods_name(this.options[this.selectedIndex].value)">
					<option value=''>구매상품선택</option>
				<?php				
				for ($i=0; $row=sql_fetch_array($result); $i++) {					
					if($row['cam_count'] < $row['prd_times']){
				?>
					<option value='<?=$row['pdo_idx']?>,<?=$row['prd_name']?>,<?=$row['mb_id_saler']?>,<?=$row['cam_count']+1;?>,<?=$row['pdo_recruit_count']?>,<?=$row['mb_name']?>,<?=$row['prd_times']?>' > <?=$row['prd_name'];?> [ <?=$row['prd_times']?>/<?= $row['cam_count']+1;?> 회차 ] </option>
				<?php
					}
				}
				?>
				</select>
            </td>
        </tr>
		<?php
		}
		?>
		<!--
		<tr>
            <th scope="row"><label for="cp_way">캠페인 방식<strong class="sound_only">필수</strong><span class="agree_ck"> 필수 </span></label></th>
            <td>                
                <input type="radio" id="cam_reviewer_yn1" name = "cam_reviewer_yn" value="1" <?php// echo ($cam['cam_reviewer_yn']=='1')?'checked':''; ?> checked="checked"/><label for="cam_reviewer_yn1"><span> 리뷰어 모집 캠페인</span>&nbsp&nbsp&nbsp </label>
				<input type="radio" id="cam_reviewer_yn2" name = "cam_reviewer_yn" value="0" <?php// echo ($cam['cam_reviewer_yn']=='0')?'checked':''; ?> /><label for="cam_reviewer_yn2"><span> 리뷰어 비모집 캠페인</span>&nbsp&nbsp&nbsp </label>
            </td>
		</tr>
		-->
		<input type="hidden" name="cam_reviewer_yn" id="cam_reviewer_yn1"  value="1" />
		
		<?php if($member['mb_level'] >= '6') { ?>
		<tr>
            <th scope="row"><label for="cp_title">업체명<strong class="sound_only">필수</strong><span class="agree_ck"> 필수 </span></label></th>
            <td>
				<div class="form_help">[ 상권,주소 ] 자동 입력 됩니다.</div>
				<input type="hidden" name="mb_id_saler" value='<?= $mb_id_saler != '' ? $mb_id_saler : $cam['mb_id_saler'];?>'>
				<input type="hidden" name="cam_prd_name" value="<?= $cam['cam_prd_name'] != '' ? $cam['cam_prd_name'] : $proo['pdo_prd_name'];?>"> <!--상품명-->
				<input type="hidden" name="mb_id_company" value="<?= $mb_id != '' ? $mb_id : $cam['mb_id_company'] ;?>" placeholder="업체아이디" style="width:10%" class="frm_input" id="mb_id_company">				
				<!--<a href="javascript:" class="global_btn2" id="cam_prd_name_modal"> 업체검색 </a>-->
				
				<select name="com_idx" class="cp_field" id="com_idx">
					<option value=''> 업체선택 </option>					
				<?php for ($i=0; $row2=sql_fetch_array($resul2); $i++) { ?>
					<option value='<?= $row2['com_idx'] ?>,<?= $row2['com_manager_hp'];?>,<?= $row2['com_email'];?>,<?= $row2['com_name'];?>' > <?= $row2['com_name'];?> </option>					
                <?php } ?>				
				</select> 
				<script>$('select[name=com_idx]').val('<?=$cam['com_idx']?>,<?= $cam['com_manager_hp'];?>,<?= $cam['com_email'];?>,<?= $cam['com_name'];?>').attr('selected','selected');</script>
         
			</td>
        </tr>
      
		<?php 
			}
			if($member['mb_level'] == '4'){
		?>
		<tr>
            <th scope="row"><label for="cp_title">업체명<strong class="sound_only">필수</strong><span class="agree_ck"> 필수 </span></label></th>            
			<td>
				<div class="form_help">[ 상권,주소 ] 자동 입력 됩니다.</div>
				<input type="hidden" name="mb_id_company2" class="mb_id_company2" value='<?= $member['mb_id'] ?>'> <!--업체Id-->
				<input type="hidden" name="mb_id_saler" value='<?= $mb_id_saler != '' ? $mb_id_saler : $cam['mb_id_saler'];?>'>
				<input type="hidden" name="cam_prd_name" value="<?= $cam['cam_prd_name'] != '' ? $cam['cam_prd_name'] : $proo['pdo_prd_name'];?>"> <!--상품명-->
				
				<select name="com_idx" class="cp_field" id="com_idx">
					<option value=''> 업체선택 </option>
				<?php for ($i=0; $row2=sql_fetch_array($resul2); $i++) { ?>
					<option value='<?= $row2['com_idx']?>,<?= $row2['com_manager_hp'];?>,<?= $row2['com_email'];?>,<?= $row2['com_name'];?>'> <?= $row2['com_name'];?></option>					
				<?php } ?>				
				</select> 
                <script>$('select[name=com_idx]').val('<?=$cam['com_idx']?>,<?= $cam['com_manager_hp'];?>,<?= $cam['com_email'];?>,<?= $cam['com_name'];?>').attr('selected','selected');</script>
                
			</td>
		</tr>
		<?php }?>
				
		<tr>
            <th scope="row"><label for="cat1_trm_idxs">카테고리1<strong class="sound_only">필수</strong><span class="agree_ck"> 필수 </span></label></th>
            <td>                
				<select name="cat1_trm_idxs" class="cp_field" style="width:32%;color: #C3C3C3;" id="cat1_trm_idxs" >
					<option value=''>업체명 선택 하시면 자동 입력 됩니다.</option>
					<?=$category_select_options?>
                </select>
				<script>$('select[name=cat1_trm_idxs]').val('<?=$cam['trm_idx_cat1']?>').attr('selected','selected');</script>
            </td>
        </tr>
        <?php 
        ?>
		<input type="hidden" id="cat2_trm_idxs" name="cat2_trm_idxs" value="" />
		<input type="hidden" id="cat3_trm_idxs" name="cat3_trm_idxs" value="" />
		<!--
		<tr>
            <th scope="row"><label for="cat2_trm_idxs">카테고리2</label></th>
            <td>                
				<select name="cat2_trm_idxs" class="cp_field" style="width:20%" id="cat2_trm_idxs">
					<option value=''>전체 카테고리2</option>
					<?//=$category_select_options?>
				</select>
				<script>$('select[name=cat2_trm_idxs]').val('<?//=$cam['trm_idx_cat2']?>').attr('selected','selected');</script>
            </td>
        </tr>
		<tr>
            <th scope="row"><label for="cat3_trm_idxs">카테고리3</label></th>
            <td>                
				<select name="cat3_trm_idxs" class="cp_field" style="width:20%" id="cat3_trm_idxs">
					<option value=''>전체 카테고리3</option>
					<?//=$category_select_options?>
				</select>
				<script>$('select[name=cat3_trm_idxs]').val('<?//=$cam['trm_idx_cat3']?>').attr('selected','selected');</script>
            </td>
        </tr>
		-->
		<tr>
            <th scope="row"><label for="trm_idx_salesarea">상권 선택<strong class="sound_only">필수</strong><span class="agree_ck"> 필수 </span></label></th>
            <td>				
				<!-- <div class="form_help">업체명 선택 하시면 자동 입력 됩니다.</div> -->
				<select name="trm_idx_salesarea" class="cp_field" style="width:32%;color: #C3C3C3;" id="trm_idx_salesarea" disabled>
					<option value=''>업체명 선택 하시면 자동 입력 됩니다.</option>
					<?=$salesarea_select_options?>
				</select>
				<script>$('select[name=trm_idx_salesarea]').val('<?=$cam['trm_idx_salesarea']?>').attr('selected','selected');</script>
				<input type="hidden" name="trm_idx_salesarea" value="<?=$cam['trm_idx_salesarea']?>"> 
            </td>
        </tr>
      
		<tr>
            <th scope="row"><label for="cp_name">캠페인명<strong class="sound_only">필수</strong><span class="agree_ck"> 필수 </span></label></th>
            <td>                
               <input type="text" name="cam_name" placeholder="캠페인명을 입력해주세요.(최대 25글자)" value="<?= $cam['cam_name']?>" id="cp_name" class="frm_input" style="width:50%" maxlength="25">
            </td>
        </tr>
		<tr>
            <th scope="row"><label for="cam_brief">간단 설명</label></th>
            <td>                
               <input type="text" name="cam_brief" placeholder="캠페인명과 함께 목록에 노출됩니다. (최대 35글자)" value="<?=$cam['cam_brief']?>" id="cam_brief" class="frm_input" style="width:90%" maxlength="35">
            </td>
        </tr>
		<tr>
            <th scope="row"><label for="cp_number">대표이미지<strong class="sound_only">필수</strong><span class="agree_ck"> 필수 </span></label></th>
            <td >
				<?php
					//수정
					for($i=0;$i<4;$i++) {
						echo '<div style="margin-bottom:4px;">';
						echo '<input type="file" name="campaign_img_file['.$i.']" class="frm_input file_make_img">';
						echo $cam['campaign_img'][$i]['file'];
						echo $cam['campaign_img'][$i]['img'];
						echo '</div>';
					}					
				?>				
            </td>
        </tr>
		<tr>
            <th scope="row"><label for="cp_number">모집인원</label></th>
            <td>
				<?php
					// 모집인원 기본 5명 입니다., 관리자에서 변경 가능
					$cam['cam_recruit_count'] = (!$cam['cam_recruit_count']) ? $proo['pdo_recruit_count'] : $cam['cam_recruit_count'];
				?>
               <input type="hidden" name="cam_recruit_count" value="<?= $cam['cam_recruit_count']?>" id="cp_number" class="frm_input" style="width:10%">
			   <div class="div_recruit_count"> <?=$cam['cam_recruit_count']?> 명</div>
            </td>
        </tr>
		<tr>
            <th scope="row"><label for="cp_register_review">등록 가능 리뷰<strong class="sound_only">필수</strong><span class="agree_ck"> 필수 </span></label></th>
            <td>
			<?=$g5['sns_channel_checkboxs_name']?>
			
			<?
			//print_r2($cam['cam_channels_array']).'<br>';			
			//echo $cam_channel['cam_channels'].'<br>';
			
			if($cam_channel['cam_channels']) {
				foreach ($cam['cam_channels_array'] as $key) {
					//echo $key.'<br>';
					?>
					<script>$('input[name^=sns_channel][value="<?=$key?>"]').attr('checked','checked');</script>
					<?php
				}
			}
			?>			
            </td>
        </tr>
        <tr>
            <th scope="row"><label for="cp_type">캠페인 타입<strong class="sound_only">필수</strong><span class="agree_ck"> 필수 </span></label></th>
            <td>
                <input type="radio" id="cam_type1" name = "cam_type" value="visite" <?php echo ($cam['cam_type']=='visite')?'checked':''; ?>/><label for="cam_type1"> 방문형 &nbsp&nbsp&nbsp </label>
				<input type="radio" id="cam_type2" name = "cam_type" value="delivery" <?php echo ($cam['cam_type']=='delivery')?'checked':''; ?>/><label for="cam_type2"> 배송형 &nbsp&nbsp&nbsp </label>
				<input type="radio" id="cam_type3" name = "cam_type" value="PressCorps" <?php echo ($cam['cam_type']=='PressCorps')?'checked':''; ?>/><label for="cam_type3"> 기자단 &nbsp&nbsp&nbsp </label>
                <input type="radio" id="cam_type4" name = "cam_type" value="receipt" <?php echo ($cam['cam_type']=='receipt')?
                'checked':''; ?>/><label for="cam_type4"> 영수증 리뷰 &nbsp&nbsp&nbsp </label>
                <input type="radio" id="cam_type5" name = "cam_type" value="reservation" <?php echo ($cam['cam_type']=='reservation')?'checked':''; ?>/><label for="cam_type5"> 예약자 리뷰 &nbsp&nbsp&nbsp </label>
            </td>
		</tr>	
		<tr>
            <th scope="row">
				<label for="cp_period" class="cam_period">캠페인 기간 설정<strong class="sound_only">필수</strong><span class="agree_ck"> 필수 </span></label>
				<?php
				//상품 회차중 마지막 등록된 캠페인 회차 추출하기.(캠페인 복사 에서도 사용함.)
				$cam_last = sql_fetch(" SELECT * FROM {$g5['campaign_table']} WHERE pdo_idx = '".$cam['pdo_idx']."' ORDER BY cam_idx DESC ");

				//일괄수정 버튼 마지막상품은 안보임.
				if($w == 'u' && $cam_last['cam_prd_time'] != 1 && $cam['cam_prd_time'] < $proo['pdo_prd_times'] ){
					echo '<input type="button" value="기간 일괄수정" id="btn_submit2" class="btn_submit2" accesskey="s">';
					echo '<input type="hidden" name="cam_auto" value="0" id="cam_auto" class="cam_auto">';			
					echo "<input type='hidden' name='pdo_prd_times' value='".$proo['pdo_prd_times']."'> ";
				}
				?>
			</th>
			<td>
				<div class="cp_period_w">
					<div class="cp_period_t"> 리뷰어 신청 </div>
					<div class="">
						<?//= $setting['set_campaign_recruit_end_dday'];?>
						<input type="text" style="width:20%" name="cam_recruit_start_dt" value="<?php echo ($cam['cam_recruit_start_dt'] && $cam['cam_recruit_start_dt']!='0000-00-00 00:00:00')?date("Y-m-d",strtotime($cam['cam_recruit_start_dt'])):''; ?>" id="cam_recruit_start_dt" class="frm_input" maxlength="10"> &nbsp&nbsp ~ &nbsp&nbsp 			
						<input type="text" style="width:20%" name="cam_recruit_end_dt" value="<?php echo ($cam['cam_recruit_end_dt'] && $cam['cam_recruit_end_dt']!='0000-00-00 00:00:00')?date("Y-m-d",strtotime($cam['cam_recruit_end_dt'])):''; ?>" id="cam_recruit_end_dt" class="frm_input" maxlength="10"> 		
					</div>
				</div>	
				<div class="cp_period_v" style="padding:3px 0";>	
					<div class="cp_period_t"> 리뷰어 발표 </div>
					<div class=""> 							
						<input type="text" style="width:20%" name="cam_notice_dt" value="<?php echo ($cam['cam_notice_dt'] && $cam['cam_notice_dt']!='0000-00-00 00:00:00')?date("Y-m-d",strtotime($cam['cam_notice_dt'])):''; ?>" id="cam_notice_dt" class="frm_input" maxlength="10">
					</div>	
				</div>	
				<div class="cp_period_v" style="padding:3px 0";>
					<div class="cp_period_t"> 리뷰 등록 </div>
					<div class="">  
						<input type="text" style="width:20%" name="cam_notice_dt" value="<?php echo ($cam['cam_review_start_dt'] && $cam['cam_review_start_dt']!='0000-00-00 00:00:00')?date("Y-m-d",strtotime($cam['cam_review_start_dt'])):''; ?>" id="cam_review_start_dt" class="frm_input" maxlength="10"> &nbsp&nbsp ~ &nbsp&nbsp			
						<input type="text" style="width:20%" name="cam_review_end_dt" value="<?php echo ($cam['cam_review_end_dt'] && $cam['cam_review_end_dt']!='0000-00-00 00:00:00')?date("Y-m-d",strtotime($cam['cam_review_end_dt'])):''; ?>" id="cam_review_end_dt" class="frm_input" maxlength="10"> 		
					</div>
				</div>	
				<div class="cp_period_v" style="padding:3px 0";>
					<div class="cp_period_t"> 베스트 발표 </div>
					<div class="">
						<input type="text" style="width:20%" name="cam_best_select_dt" value="<?php echo ($cam['cam_best_select_dt'] && $cam['cam_best_select_dt']!='0000-00-00 00:00:00')?date("Y-m-d",strtotime($cam['cam_best_select_dt'])):''; ?>" id="cam_best_select_dt" class="frm_input" maxlength="10"> &nbsp&nbsp						
						<input type="radio" name="cam_best_use_yn" value="1" id="cam_best_use_yn1"  class="cam_best_use_yn" <?php echo ($cam['cam_best_use_yn']=='1')?'checked':''; ?> checked="checked" > &nbsp<label for="cam_best_use_yn1"> 사용 &nbsp</label>
						<input type="radio" name="cam_best_use_yn" value="0" id="cam_best_use_yn0"  class="cam_best_use_yn" <?php echo ($cam['cam_best_use_yn']=='0')?'checked':''; ?>> &nbsp<label for="cam_best_use_yn0"> 사용안함 </label>
					</div>
				</div>
			</td>	
        </tr>
		<!--<tr>
            <th scope="row">
				<label for="cp_coin">코인 설정</label>
			</th>
            <td>
				<div class="form_help">기본 코인만 지급 가능합니다.</div>
				<div class="cp_coin_rb_n">리뷰어 선정시 지급 코인 &nbsp&nbsp&nbsp <b><?= ($cam['cam_reviewer_point'] == '') ? $setting['set_cam_reviewer_point'] : $cam['cam_reviewer_point'];?> Coin</b>
					<input type="hidden" style="width:10%" name="cam_reviewer_point" value="<?= ($cam['cam_reviewer_point'] == '') ? $setting['set_cam_reviewer_point'] : $cam['cam_reviewer_point'];?>" class="frm_input" maxlength="8">
				</div>
				<div class="cp_coin_rb_n">베스트 선정시 지급 코인 &nbsp&nbsp&nbsp <b><?= ($cam['cam_best_point'] == '') ? $setting['set_cam_best_point'] : $cam['cam_best_point'];?> Coin</b>
					<input type="hidden" style="width:10%" name="cam_best_point" value="<?= ($cam['cam_best_point'] == '') ? $setting['set_cam_best_point'] : $cam['cam_best_point'];?>" class="frm_input" maxlength="8">
				</div>
            </td>
        </tr>-->
		<!--
		<tr>
            <th scope="row">
				<label for="cp_coin">코인 설정</label>
			</th>
            <td>
                <div class="form_help">코인관리 - 적립/소멸/차감 설정에서 일괄설정 사항을 변경할 수 있습니다.</div>
				<input type="radio" name = "cam_point_type" value="group" id="cam_point_type1" <?php// echo ($cam['cam_point_type']=='group')?'checked':''; ?> checked="checked"/> <label for="cam_point_type1">일괄설정 </label>&nbsp&nbsp&nbsp&nbsp
				<input type="radio" name = "cam_point_type" value="each" id="cam_point_type2" <?php// echo ($cam['cam_point_type']=='each')?'checked':''; ?>/> <label for="cam_point_type2">개별지정 </label>
				<div class="cp_coin_rb">리뷰어 선정 시 지급 코인 &nbsp&nbsp&nbsp <input type="text" style="width:10%" name="cam_reviewer_point" value="<?//= $cam['cam_reviewer_point'];?>" id="" class="frm_input" maxlength="8"> Coin </div>
				<div class="cp_coin_rb">베스트 선정 시 지급 코인 &nbsp&nbsp&nbsp <input type="text" style="width:10%" name="cam_best_point" value="<?//= $cam['cam_best_point'];?>" id="" class="frm_input" maxlength="8"> Coin </div>					
            </td>
        </tr>
		-->
		<!--
		<tr>
            <th scope="row">
				<label for="cp_head_ct">상단 글</label>
			</th>
            <td class="cp_head_ct">
				<?//= $cam_head_content;?>
            </td>
        </tr>
		-->
        <tr>
            <th scope="row"><label for="cp_number">영수증 압축파일<strong class="sound_only">필수</strong><span class="agree_ck"> 필수 </span></label></th>
            <td >
              <span style="color:#0000cd;font-weight:800;font-size:13px">압축파일 제목에 특수문자 입력 시  정상적으로 등록되지 않습니다 <p style="color:red;">ex) [2020]_영수증%&압축파일(X) ▶ 2020영수증압축파일</p></span><br>
              <input type="file" name="campaign_img_file[4]" class="frm_input"> <?= $cam['campaign_img'][4]['file']?>			
              <?=('- 압축파일은 ZIP 만 업로드하세요. '); ?>
            </td>
        </tr>
        
        <tr>
            <th scope="row">네이버 플레이스 URL</th>
            <td colspan="3"><input type="text" name="com_naver_place_url" value="<?=$cam['com_naver_place_url'] ?>" id="com_naver_place_url" class="frm_input" style="width:60%"></td>    
        </tr> 
		<tr class="norun">
            <th scope="row"><label for="cp_type">복사테그<strong class="sound_only">필수</strong><span class="agree_ck"> 필수 </span></label></th>
            <td>
                <input type="text" id="cam_tags" name="cam_tags" value="<?=$cam['cam_tags']?>" style="width:99%;"/>
            </td>
		</tr>
		<tr>
            <th scope="row">
				<label for="cp_content">내용<strong class="sound_only">필수</strong><?php echo $w=='u'?'<span class="agree_ck"> 필수 </span>':''; ?></label>				
			</th>
            <td class="cp_content">
				<?php 
					echo '<div class="form_help">- 캠페인 상세 보기 페이지 내용 부분입니다. 모바일웹에서 보여지므로 이미지는 100% 형태로 나타납니다.</div>';
					if($w == 'u'){
						echo '<div class="form_help">- 캠페인 타입 변경후 저장시 기존 내용이 삭제 됩니다.</div>';						
					}				
				
                echo "<div class='cam_content_type_wrap'>";				
                
				if($w == 'u'){
					//echo editor_html("cam_content", get_text($cam['cam_content'], 0));
                    //방문형 - cam_content
					if($cam['cam_type'] == 'visite' ){
						echo "<div class='cam_content_type1'>";
							echo '<div class="form_help">[ 방문형 ]</div>';
							echo editor_html("cam_content", get_text($cam['cam_content'], true));
						echo "</div>";
						
						echo "<div class='cam_content_type2' >";
							echo '<div class="form_help">[ 배송형 ]</div>';
							echo editor_html("cam_content1", get_text($setting['set_cam_content_cam_type2'], true));						
						echo "</div>";
						
						echo "<div class='cam_content_PressCorps'>";
							echo '<div class="form_help">[ 기자단 ]</div>';
                            echo editor_html("cam_content2", get_text($setting['set_cam_content_PressCorps'], true));				
                        echo "</div>";
                        echo "<div class='cam_content_receipt'>";
                            echo '<div class="form_help">[ 영수증 리뷰 ]</div>';
                            echo editor_html("cam_content3", get_text($setting['set_cam_content_cam_receipt'], true));
                        echo "</div>";
                        echo "<div class='cam_content_reservation'>";
                            echo '<div class="form_help">[ 예약자 리뷰 ]</div>';
                            echo editor_html("cam_content4", get_text($setting['set_cam_content_cam_reservation'], true));
                        echo "</div>";
					}
					//배송형 - cam_content1
					if($cam['cam_type'] == 'delivery' ){
						echo "<div class='cam_content_type1' >";
							echo '<div class="form_help">[ 방문형 ]</div>';
							echo editor_html("cam_content", get_text($setting['set_cam_content_cam_type1'], true));
						echo "</div>";
						
						echo "<div class='cam_content_type2'>";
							echo '<div class="form_help">[ 배송형 ]</div>';
							echo editor_html("cam_content1", get_text($cam['cam_content'], true));						
						echo "</div>";
						
						echo "<div class='cam_content_PressCorps'>";
							echo '<div class="form_help">[ 기자단 ]</div>';
                            echo editor_html("cam_content2", get_text($setting['set_cam_content_PressCorps'], true));				
                        echo "</div>";
                        echo "<div class='cam_content_receipt'>";
                        echo '<div class="form_help">[ 영수증 리뷰 ]</div>';
                        echo editor_html("cam_content3", get_text($setting['set_cam_content_cam_receipt'], true));
                            echo "</div>";
                            echo "<div class='cam_content_reservation'>";
                        echo '<div class="form_help">[ 예약자 리뷰 ]</div>';
                        echo editor_html("cam_content4", get_text($setting['set_cam_content_cam_reservation'], true));
                            echo "</div>";
					}
					//기자단 - cam_content2
					if($cam['cam_type'] == 'PressCorps' ){
						echo "<div class='cam_content_type1' >";
							echo '<div class="form_help">[ 방문형 ]</div>';
							echo editor_html("cam_content", get_text($setting['set_cam_content_cam_type1'], true));
						echo "</div>";
						
						echo "<div class='cam_content_type2'>";
							echo '<div class="form_help">[ 배송형 ]</div>';
							echo editor_html("cam_content1", get_text($setting['set_cam_content_cam_type2'], true));						
						echo "</div>";
						echo "<div class='cam_content_PressCorps'>";
							echo '<div class="form_help">[ 기자단 ]</div>';
							echo editor_html("cam_content2", get_text($cam['cam_content'], true));						
                        echo "</div>";

                        echo "<div class='cam_content_receipt'>";
                        echo '<div class="form_help">[ 영수증 리뷰 ]</div>';
                            echo editor_html("cam_content3", get_text($setting['set_cam_content_cam_receipt'], true));
                            echo "</div>";
                            echo "<div class='cam_content_reservation'>";
                        echo '<div class="form_help">[ 예약자 리뷰 ]</div>';
                        echo editor_html("cam_content4", get_text($setting['set_cam_content_cam_reservation'], true));
                            echo "</div>";
                    }
                        // 영수증 리뷰 - cam_content3
                    if($cam['cam_type'] == 'receipt' ){
                        echo "<div class='cam_content_type1' >";
                            echo '<div class="form_help">[ 방문형 ]</div>';
                            echo editor_html("cam_content", get_text($setting['set_cam_content_cam_type1'], true));
                        echo "</div>";
                        
                        echo "<div class='cam_content_type2'>";
                            echo '<div class="form_help">[ 배송형 ]</div>';
                            echo editor_html("cam_content1", get_text($setting['set_cam_content_cam_type2'], true));
                        echo "</div>";
                        
                        echo "<div class='cam_content_PressCorps'>";
							echo '<div class="form_help">[ 기자단 ]</div>';
                            echo editor_html("cam_content2", get_text($setting['set_cam_content_PressCorps'], true));				
                        echo "</div>";
                        echo "<div class='cam_content_receipt'>";
                            echo '<div class="form_help">[ 영수증 리뷰 ]</div>';
                            echo editor_html("cam_content3", get_text($cam['cam_content'], true));
                        echo "</div>";
                        echo "<div class='cam_content_reservation'>";
                            echo '<div class="form_help">[ 예약자 리뷰 ]</div>';
                            echo editor_html("cam_content4", get_text($setting['set_cam_content_cam_reservation'], true));
                        echo "</div>";
                    }
                    // 예약자 리뷰 - cam_content4
                    if($cam['cam_type'] == 'reservation' ){
                        echo "<div class='cam_content_type1' >";
                            echo '<div class="form_help">[ 방문형 ]</div>';
                            echo editor_html("cam_content", get_text($setting['set_cam_content_cam_type1'], true));
                        echo "</div>";
                        
                        echo "<div class='cam_content_type2'>";
                            echo '<div class="form_help">[ 배송형 ]</div>';
                            echo editor_html("cam_content1", get_text($setting['set_cam_content_cam_type2'], true));
                        echo "</div>";
                        
                        echo "<div class='cam_content_PressCorps'>";
							echo '<div class="form_help">[ 기자단 ]</div>';
                            echo editor_html("cam_content2", get_text($setting['set_cam_content_PressCorps'], true));				
                        echo "</div>";
                        echo "<div class='cam_content_receipt'>";
                            echo '<div class="form_help">[ 영수증 리뷰 ]</div>';
                            echo editor_html("cam_content3", get_text($setting['set_cam_content_cam_receipt'], true));
                        echo "</div>";
                        echo "<div class='cam_content_reservation'>";
                            echo '<div class="form_help">[ 예약자 리뷰 ]</div>';
                            echo editor_html("cam_content4", get_text($cam['cam_content'], true));
                        echo "</div>";
				    }					
				}
				else{
					echo "<div class='cam_content_type1'>";
						echo '<div class="form_help">[ 방문형 ]</div>';
						echo editor_html("cam_content", get_text($setting['set_cam_content_cam_type1'], true));
					echo "</div>";
					
					echo "<div class='cam_content_type2'>";
						echo '<div class="form_help">[ 배송형 ]</div>';
						echo editor_html("cam_content1", get_text($setting['set_cam_content_cam_type2'], true));						
					echo "</div>";
					
					echo "<div class='cam_content_PressCorps'>";
						echo '<div class="form_help">[ 기자단 ]</div>';
						echo editor_html("cam_content2", get_text($setting['set_cam_content_PressCorps'], true));						
                    echo "</div>";
                    echo "<div class='cam_content_receipt'>";
						echo '<div class="form_help">[ 영수증리뷰 ]</div>';
						echo editor_html("cam_content3", get_text($setting['set_cam_content_cam_receipt'], true));						
					echo "</div>";
					
				    echo "<div class='cam_content_reservation'>";
						echo '<div class="form_help">[ 예약자리뷰 ]</div>';
						echo editor_html("cam_content4", get_text($setting['set_cam_content_cam_reservation'], true));						
                    echo "</div>";
				}
                echo "</div>";
                // print_r2($setting['set_cam_content_cam_type2']);
				?>
            </td>
            </tr>
            <tr>
            <th scope="row">
				<label for="cp_addr">주소<strong class="sound_only">필수</strong><span class="agree_ck"> 필수 </span></label>				
			</th>
            <td class="cp_addr" >				
				<!-- <div class="form_help">업체명 선택 하시면 자동 입력 됩니다.</div> -->
                <input type="text" name="com_addr1" value="<?= $cam['com_addr1'];?>" placeholder="업체명 선택 하시면 자동 입력 됩니다." style="width:35%;color:#C3C3C3;" class="frm_input" readonly="readonly">
                <input type="text" name="com_addr2" value="<?= $cam['com_addr2'];?>" placeholder="" style="width:25%;color:#C3C3C3;;" class="frm_input" readonly="readonly">
				<div id="map" style="width:99%;height:300px;margin-top:10px;display:none;"></div>
				    
				<input type="hidden" name="com_zip" value="<?= $cam['com_zip'] ?>">   
				<input type="hidden" name="com_latitude" id="com_latitude" value="<?= $cam['com_latitude'] ?>">
				<input type="hidden" name="com_longitude" id="com_longitude" value="<?= $cam['com_longitude'] ?>">
			</td>
        </tr>
		<!--
		<tr>
            <th scope="row">
				<label for="cp_head_ct">확인사항</label>				
			</th>
            <td class="cp_head_ct">				
				<?//= $cam_head_content;?>					
            </td>
        </tr>
		-->
		<?php 
		if( $cam['cam_notice'] != '' ){
			echo '<tr>';
				echo '<th scope="row">';
					echo '<label for="cp_content">반려사유</label>';				
				echo '</th>';
				echo '<td class="cp_content">';
					echo $cam['cam_notice'];
				echo '</td>';
			echo '</tr>';
		}
		?>
		<!--
		<tr>
            <th scope="row">
				<label for="cp_head_ct">인스타그램#태그</label>				
			</th>
            <td class="cp_i_tag">
				<?php 
					//echo help('( # )샾으로 구분하여 입력 하세요.'); 					
					
					//$sql3 = " SELECT trm_idx FROM {$g5['term_relation_table']} WHERE tmr_db_key = 'campaign_tag' AND tmr_db_id = '{$cam_idx}' ";
					//$trm1 = sql_query($sql3);					
					//for ($j=0; $row=sql_fetch_array($trm1); $j++){						
					//	$trm2 = sql_fetch(" SELECT trm_idx,trm_name FROM {$g5['term_table']} WHERE trm_taxonomy = 'campaign_tag' AND trm_idx = '{$row['trm_idx']}' ");
					//	$trm['trm_name'] .= '#'.$trm2['trm_name']; //변수 값(문자열) 연결 
					//}
				?>
			
				<input type="hidden" id="tag_text" name="tag_text" value="<?//=$trm['trm_name'] ?>" placeholder="( #kafain_태그명 )으로 한번만 입력하세요." style="width:90%;color:#C3C3C3;" class="frm_input" readonly="readonly">						          											
			</td>
        </tr>
		-->
		<!-- 인스타 에서 태그 복수로 안됨 , 프로그램은 작업 되어있음.(#태그로 구분함)  -->
		<input type="hidden" id="tag_text" name="tag_text" value="" placeholder="( #kafain_태그명 )으로 한번만 입력하세요." style="width:90%;color:#C3C3C3;" class="frm_input" readonly="readonly">
		
		<?php 
		if( $w == '' ){ 
		 echo '<input type="hidden" name="cam_status" value="pending">';
		} 
		if( $w == 'u' ){  
		?>
		<tr>
            <th scope="row">
				<label for="cp_head_ct">상태</label>				
			</th>
            <td class="cp_i_tag">
				<?php if( $cam['cam_status'] == 'reject' ){ ?>
				<select name="cam_status" id="cam_status">
					<?//=$g5['set_cam_status_options']?>
					<option value="reject">반려</option>
					<option value="re_pending">재접수</option>
				</select>
				<script>$('select[name="cam_status"]').val('<?=$cam['cam_status']?>');</script>
				<?php 
					} 
					else{ 
						echo $g5['set_cam_status'][$cam['cam_status']];
						 echo '<input type="hidden" name="cam_status" value="'.$cam['cam_status'].'">';
					}
				?>
				
				
            </td>
        </tr>
		<?php } ?>
		
		<?php if($cam_reg_dt){ ?>
		<tr>
            <th scope="row">
				<label for="cp_head_ct">등록일</label>				
			</th>
            <td class="cp_i_tag">
				<span>
					<?= date("Y-m-d",strtotime($cam['cam_reg_dt']));?>
				<span class="cp_cnt_title" for="cp_head_ct">조회수</span>
					<?= $cam['cam_hit'];?>	
				</span>
            </td>
        </tr>
		<?php } ?>
        </tbody>
        </table>
    </div>
    <div class="btn_confirm">
        <input type="submit" value="<?= $w == 'u' ? '수정':'확인'; ?>" id="btn_submit" class="btn_submit" accesskey="s">
        <a href="<?php echo G5_USER_URL ?>/k/campaign_list.php" id="btn_cancel" class="btn_cancel">목록</a>
		
		<?php
		//캠페인 복사				
		//echo $cam_last['cam_prd_time'];
		//echo $proo['pdo_prd_times'];
		
		//영업자, 업체 구분하기.
		$ck_mb_id = $member['mb_level'] == '4' ? $member['mb_id'] : $mb_id;
		
		//tail안에 모달 사용변수 선언.
		$pro_mb_id = $ck_mb_id;
		
		// *** 상품신청 (구매) 상품이 있는지 체크 ***
		$pdo = sql_query(" SELECT pdo_idx, pdo_recruit_count
							,( SELECT prd_times FROM {$g5['product_table']} WHERE prd_idx = pdo.prd_idx ) AS prd_times
							,( SELECT count(cam_idx) FROM {$g5['campaign_table']} WHERE pdo_idx = pdo.pdo_idx AND cam_status IN ('pending','ing','ok') ) AS cam_count
						FROM {$g5['product_order_table']} AS pdo 
						WHERE pdo_pay_status = 'payall' AND mb_id = '{$ck_mb_id}' ");
		for ($i=0; $row2=sql_fetch_array($pdo); $i++) {
			//echo $row2['prd_times'].' / '.$row2['cam_count'].'<br>';
			if($row2['prd_times'] > $row2['cam_count']){
				$a++;
			}
		}

		if( $cam_last['cam_prd_time'] != 0 && $a>0 ){
			echo ' <span class="cam_copy">복사</span>';
			echo ' <input type="hidden" class="cam_idx_copy" value="'.$cam_idx.'"> ';
		}
		?>

    </div>
</form>
<!--} 캠페인 입력/수정 끝 -->
</div>


<?php
// 분리 (미사용 참고용.)
$holidays = explode('^', $setting['set_campaign_holidays']);
foreach ($holidays as $holiday) {	
	//echo $holiday.'<br>';	
}
unset($holidays);unset($holiday);				
?>


<script>
//대표이미지 plus 함수.
$(document).on('click','.file_plus',function(e){
	//수정확인.
	var upd = $("input[name='w']").val();	
	//cnt
	var n = $(".value_cnt").val();	
	//plus 이미지 setting개수만큼 보여주기.
	if( n == '<?=$setting['set_cam_title_img'] -1;?>'){
		$(this).hide();
	}
	
	var fileRow = '<div class="file_make_img_wrap"><input type="file" name="campaign_img_file['+n+']" class="frm_input file_make_img"> <a class="sns_btn_del"><img src="'+g5_theme_url+'/mobile/img/btn_minus.png" style="width:27px;margin-left:2px;" /></a></div>';
	
	//입력부분.
	if( upd == 'u'){
		//var fileRow = '<input type="file" name="campaign_img_file['+n+']" class="frm_input file_make_img"> <a class="sns_btn_del"><img src="'+g5_theme_url+'/mobile/img/btn_minus.png" style="width:27px;margin-left:2px;" /></a>';
		$(".div_file_img").last().after(fileRow);
	}else{		
		$(".file_make_img_wrap").last().after(fileRow);
	}
	
	//카운트 +하기.
	$(".value_cnt").val( parseInt(n)+1 );
});
//대표이미지 리스트 삭제
$(document).on('click','.sns_btn_del',function(e){
	 n = $(".value_cnt").val();	
	//카운트 -하기.
	$(".value_cnt").val( parseInt(n)-1 );	
	//삭제하기.
	$(this).parent().remove();	
	//plus 이미지 setting개수보다 작으면 안보여주기.
	if( n <= '<?=$setting['set_cam_title_img'];?>'){
		$(".file_plus").show();
	}
});


// **** 달력 ****
// 2016-6-7문자로 입력된 날짜를 월,일을 2자리 만드는 함수
function stringToYYYYMMDD(date)
{	
	var YMD = date.split('-');
	
    function pad(num) {			        
		//num = num + '';        
		return num.length < 2 ? '0' + num : num;
    }

   return YMD[0]+'-'+pad(YMD[1])+'-'+pad(YMD[2]);
}
			
// 특정날짜들 배열
disabledDays = [<?= $setting['set_campaign_holidays']; ?>];

if('<?=$w?>' == ''){
	
	//캠페인 시간 설정 에서 리뷰어 신청 이후 부분들은 전부 disabled
	$('#cam_recruit_end_dt').css("background","#EAEAEA").attr('disabled',true);
	$('#cam_notice_dt').css("background","#EAEAEA").attr('disabled',true);
	$('#cam_review_start_dt').css("background","#EAEAEA").attr('disabled',true);
	$('#cam_review_end_dt').css("background","#EAEAEA").attr('disabled',true);
	$('#cam_best_select_dt').css("background","#EAEAEA").attr('disabled',true);
			
	//리뷰어 신청 시작
	$("#cam_recruit_start_dt").datepicker({
		changeMonth: true,
		changeYear: true,
		dateFormat: "yy-mm-dd",
		showButtonPanel: true,
		yearRange: "c-99:c+99",
		beforeShowDay: function(date){
				//주말(토, 일요일) 선택 막기
				var day = date.getDay();
				
				// 특정일 선택막기				
				var m = date.getMonth(), d = date.getDate(), y = date.getFullYear();
				for (i = 0; i < disabledDays.length; i++) {
					if($.inArray(y + '-' +(m+1) + '-' + d,disabledDays) != -1) {
						return [false];
					}
				}
				
				//주말 포함하여 계산
				if(<?= $setting['set_campaign_holiday_include_yn']?> == 0){
					if(<?=$setting['set_weekend_holidays_yn']?> == 0){
						return [true],[(day != 0)]; //일 주말 설정
					}
					else{
						return [true],[(day != 0 && day != 6)]; //토 / 일 주말 설정 
					}
				}
				//주말 건너뛰고 계산
				else{					
					return [true];
				}
			}
		//,maxDate: "+1d"
		//,minDate: "+1d"
	});

//리뷰어 신청 입력
$("#cam_recruit_start_dt").on('click', function(){	
	$("#cam_recruit_start_dt").change(function(){
		
		//환경설정에서 값 가져오기
		var holiday = "<?=$setting['set_campaign_holidays']?>";
		var holidays = $.trim(holiday);//공백 정리.
		var holidays_array = holidays.split(',');//콤마 기준으로 자르기.
		
		//활성화하기
		$('#cam_recruit_end_dt').css("background","#fff").attr('disabled',false).removeClass('hasDatepicker');
		$('#cam_notice_dt').css("background","#fff").attr('disabled',false).removeClass('hasDatepicker');
		$('#cam_review_start_dt').css("background","#fff").attr('disabled',false).removeClass('hasDatepicker');
		$('#cam_review_end_dt').css("background","#fff").attr('disabled',false).removeClass('hasDatepicker');
		$('#cam_best_select_dt').css("background","#fff").attr('disabled',false).removeClass('hasDatepicker');	
		
		//(리뷰신청 시작 날짜) 만들기
		var start_dt_val = $(this).val();		
		var arr = start_dt_val.split('-');
		var m_date = new Date( arr[0],arr[1]-1,arr[2] );
		var m_date1 = new Date( arr[0],arr[1]-1,arr[2] );
		
//자동 계산 +D 입력.
//***** 리뷰어 신청 끝 자동입력 ******
		m_date.setDate(m_date.getDate() + <?=$setting['set_campaign_recruit_end_dday']?>);
		var recruit_end_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();

		//주말 포함하여 계산 하기
		if(<?= $setting['set_campaign_holiday_include_yn']?> == 0){			
			var cnt_Day =  <?=$setting['set_campaign_recruit_end_dday']?>;
			
			//시작~끝 날짜안에 토/일 있는지 검사.
			for(var i = 1; i <= cnt_Day; i++){				
				m_date1.setDate(m_date1.getDate() + 1);				
				var start_day = new Date(m_date1).getDay(); //요일 추출
				
				//익스에서는 안됨.
				//var start_val = m_date1.getFullYear() + "," + (m_date1.getMonth()+1) + "," + m_date1.getDate();//시작날짜 추출				
				//var start_day = new Date(start_val).getDay(); //요일 추출
				
				//일요일이 있으면 +1.
				if(<?=$setting['set_weekend_holidays_yn']?> == 0 && start_day == 0){
					m_date.setDate(m_date.getDate() + 1);
					recruit_end_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
				}
				
				//주말설정 : 토/일요일. 
				if(<?=$setting['set_weekend_holidays_yn']?> == 1 && start_day == 6){
					m_date.setDate(m_date.getDate() + 2);
					recruit_end_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();	
				
					//요일확인(일요일이 마지막 날인지 확인하기 위해서)
					var day_confirm = new Date(m_date).getDay();
					//일요일이 마지막 날이면 +1 하기.
					if(day_confirm == 0){
						m_date.setDate(m_date.getDate() + 1);
						recruit_end_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
					}
				}			
				//주말설정 : 일요일.( 르푸돌면서 적용됨. )
				//if(<?=$setting['set_weekend_holidays_yn']?> == 1 && start_day == 0){					
				//	m_date.setDate(m_date.getDate() + 1);
				//	recruit_end_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
				//}				
			}
		}

		//공휴일 확인 및 작업
		$.each( holidays_array, function(index,value){			
			//날짜 비교하기 위한작업
			var value1 = value.replace(/'/gi,'');			
			//var value3 = value2.replace(/-/gi,',');
			
			//공휴일 날짜 월,일 1자리를 2자리로 만들기.
			var value2 = stringToYYYYMMDD(value1);
			var start_dt_val2 = stringToYYYYMMDD(start_dt_val);
			var recruit_end_make2 = stringToYYYYMMDD(recruit_end_make);
			
			var strDate = new Date( value2 );//환경설정-공휴일
			var endDate = new Date(start_dt_val2);//리뷰어 신청 시작일
			var endDate2 = new Date(recruit_end_make2);//입력되는 날짜.
			
			//시작~끝 날짜 사이에 공휴일 있으면 +1씩 하기.
			if( strDate >= endDate){
				if(strDate <= endDate2){
					//요일먼저 확인
					day_confirm = new Date(m_date).getDay();
					
					//공휴일 있으면 +1씩 하기
					m_date.setDate(m_date.getDate() + 1);
					recruit_end_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
				
					//주말 포함하여 계산 하기
					if(<?= $setting['set_campaign_holiday_include_yn']?> == 0){
						//토/일요일 포함.
						if(<?=$setting['set_weekend_holidays_yn']?> == 1 ){
							//토요일이 있으면 +2 하기.
							if(day_confirm == 6){					
								m_date.setDate(m_date.getDate() + 2);
								recruit_end_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
							}
						}
						//일요일 포함.
						if(<?=$setting['set_weekend_holidays_yn']?> == 0 ){
							//일요일이 있으면 +1 하기.
							if(day_confirm == 0){
								m_date.setDate(m_date.getDate() + 1);
								recruit_end_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
							}
						}
					}
					
				}
			}
		});

		//주말 포함하여 계산 하기
		if(<?= $setting['set_campaign_holiday_include_yn']?> == 0){			
			//다시 요일확인(토/일요일이 마지막 날인지 확인하기 위해서)
			day_confirm = new Date(m_date).getDay();
			if(<?=$setting['set_weekend_holidays_yn']?> == 1 ){				
				//토요일이 마지막 날이면 +2 하기.
				if(day_confirm == 6){					
					m_date.setDate(m_date.getDate() + 2);
					recruit_end_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
				}
				//일요일이 마지막 날이면 +1 하기.
				if(day_confirm == 0){				
					m_date.setDate(m_date.getDate() + 1);
					recruit_end_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
				}
			}
			
			//일요일이 마지막 날이면 +1 하기.
			day_confirm = new Date(m_date).getDay();
			if(<?=$setting['set_weekend_holidays_yn']?> == 0 ){				
				if(day_confirm == 0){				
					m_date.setDate(m_date.getDate() + 1);
					recruit_end_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
				}
			}
		}

		//값 입력.
		$('#cam_recruit_end_dt').val( recruit_end_make );
		
//***** 리뷰어 발표 자동입력 ******	
		//이전 날짜값 분할하기 
		arr = recruit_end_make.split('-');
		var m_date2 = new Date( arr[0],arr[1]-1,arr[2] );
		
		//자동 계산 D-day + 하기. 
		m_date.setDate(m_date.getDate() + <?=$setting['set_campaign_notice_dday']?>);
		var notice_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
	
		//주말 포함하여 계산 하기
		if(<?= $setting['set_campaign_holiday_include_yn']?> == 0){			
			cnt_Day =  <?=$setting['set_campaign_notice_dday']?>;
			
			//시작~끝 날짜안에 토/일 있는지 검사.
			for(var i = 1; i <= cnt_Day; i++){
				m_date2.setDate(m_date2.getDate() + 1);
				start_day = new Date(m_date2).getDay(); //요일 추출
				
				//익스에서는 안됨.
				//start_val = m_date2.getFullYear() + "," + (m_date2.getMonth()+1) + "," + m_date2.getDate();//앞에 날짜값 추출				
				//start_day = new Date(start_val).getDay(); //요일 추출
				

				//일요일이 있으면 +1.
				if(<?=$setting['set_weekend_holidays_yn']?> == 0 && start_day == 0){					
					m_date.setDate(m_date.getDate() + 1);
					notice_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
				}
				
				//주말설정 : 토/일요일. 
				if(<?=$setting['set_weekend_holidays_yn']?> == 1 && start_day == 6){
					m_date.setDate(m_date.getDate() + 2);
					notice_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
					
					//요일확인(일요일이 마지막 날인지 확인하기 위해서)
					day_confirm = new Date(m_date).getDay();
					//일요일이 마지막 날이면 +1 하기.
					if(day_confirm == 0){
						m_date.setDate(m_date.getDate() + 1);
						notice_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
					}
				}
				//주말설정 : 일요일. ( 르푸돌면서 적용됨. )
				//if(<?=$setting['set_weekend_holidays_yn']?> == 1 && start_day == 0){					
				//	m_date.setDate(m_date.getDate() + 1);
				//	notice_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
				//}
			}			
		}
	
		//공휴일 확인 및 작업
		$.each( holidays_array, function(index,value){
			value1 = value.replace(/'/gi,'');
						
			//공휴일 날짜 월,일 1자리를 2자리로 만들기.
			value2 = stringToYYYYMMDD(value1);
			start_dt_val2 = stringToYYYYMMDD(recruit_end_make);
			recruit_end_make2 = stringToYYYYMMDD(notice_dt_make);
			
			strDate = new Date(value2);
			endDate = new Date(start_dt_val2);
			endDate2 = new Date(recruit_end_make2);

			if( strDate >= endDate){
				if(strDate <= endDate2){
					//요일먼저 확인
					day_confirm = new Date(m_date).getDay();
					
					//공휴일 있으면 +1씩 하기
					m_date.setDate(m_date.getDate() + 1);
					notice_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
				
					//주말 포함하여 계산 하기
					if(<?= $setting['set_campaign_holiday_include_yn']?> == 0){	
						//토/일요일 포함.
						if(<?=$setting['set_weekend_holidays_yn']?> == 1 ){
							//토요일이 있으면 +2 하기.
							if(day_confirm == 6){					
								m_date.setDate(m_date.getDate() + 2);
								notice_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
							}
						}
						//일요일 포함.
						if(<?=$setting['set_weekend_holidays_yn']?> == 0 ){
							//일요일이 있으면 +1 하기.
							if(day_confirm == 0){
								m_date.setDate(m_date.getDate() + 1);
								notice_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
							}
						}
					}

				}
			}
		});

		//주말 포함하여 계산 하기
		if(<?= $setting['set_campaign_holiday_include_yn']?> == 0){
			//다시 요일확인(토/일요일이 마지막 날인지 확인하기 위해서)
			day_confirm = new Date(m_date).getDay();
			if(<?=$setting['set_weekend_holidays_yn']?> == 1 ){
				//토요일이 마지막 날이면 +2 하기.
				if(day_confirm == 6){			
					m_date.setDate(m_date.getDate() + 2);
					notice_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
				}
				//일요일이 마지막 날이면 +1 하기.
				if(day_confirm == 0){			
						m_date.setDate(m_date.getDate() + 1);
						notice_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
				}
			}
			
			//일요일이 마지막 날이면 +1 하기.
			day_confirm = new Date(m_date).getDay();
			if(<?=$setting['set_weekend_holidays_yn']?> == 0 && day_confirm == 0){							
				m_date.setDate(m_date.getDate() + 1);
				notice_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();				
			}
		}

		$('#cam_notice_dt').val( notice_dt_make );

//***** 리뷰 등록 시작 자동입력 ******		
		//이전 날짜값 분할하기
		arr = notice_dt_make.split('-');
		var m_date3 = new Date( arr[0],arr[1]-1,arr[2] );
		
		m_date.setDate(m_date.getDate() + <?=$setting['set_campaign_review_start_dday']?>);		
		var review_start_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
		
		//주말 포함하여 계산 하기
		if(<?= $setting['set_campaign_holiday_include_yn']?> == 0){			
			cnt_Day =  <?=$setting['set_campaign_review_start_dday']?>;
			
			//시작~끝 날짜안에 토/일 있는지 검사.
			for(var i = 1; i <= cnt_Day; i++){
				m_date3.setDate(m_date3.getDate() + 1);
				start_day = new Date(m_date3).getDay(); //요일 추출
				
				//익스에서는 안됨.
				//start_val = m_date3.getFullYear() + "," + (m_date3.getMonth()+1) + "," + m_date3.getDate();//앞에 날짜값 추출
				//start_day = new Date(start_val).getDay(); //요일 추출
			
				//일요일이 있으면 +1.
				if(<?=$setting['set_weekend_holidays_yn']?> == 0 && start_day == 0){					
					m_date.setDate(m_date.getDate() + 1);
					review_start_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
				}				
				//주말설정 : 토/일요일. 
				if(<?=$setting['set_weekend_holidays_yn']?> == 1 && start_day == 6){					
					m_date.setDate(m_date.getDate() + 2);
					review_start_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
					
					//요일확인(일요일이 마지막 날인지 확인하기 위해서)
					day_confirm = new Date(m_date).getDay();					
					//일요일이 마지막 날이면 +1 하기.
					if(day_confirm == 0){						
						m_date.setDate(m_date.getDate() + 1);
						review_start_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
					}
				}
				//주말설정 : 일요일. ( 르푸돌면서 적용됨. )
				//if(<?=$setting['set_weekend_holidays_yn']?> == 1 && start_day == 0){					
				//	m_date.setDate(m_date.getDate() + 1);
				//	review_start_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
				//}
			}			
		}
		
		//공휴일 확인 및 작업
		$.each( holidays_array, function(index,value){
			value1 = value.replace(/'/gi,'');
			
			//공휴일 날짜 월,일 1자리를 2자리로 만들기.
			value2 = stringToYYYYMMDD(value1);
			start_dt_val2 = stringToYYYYMMDD(notice_dt_make);
			recruit_end_make2 = stringToYYYYMMDD(review_start_dt_make);
			
			strDate = new Date(value2);
			endDate = new Date(start_dt_val2);
			endDate2 = new Date(recruit_end_make2);

			if( strDate >= endDate){
				if(strDate <= endDate2){
					//요일먼저 확인
					day_confirm = new Date(m_date).getDay();
					
					//공휴일 있으면 +1씩 하기
					m_date.setDate(m_date.getDate() + 1);
					review_start_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
				
					//주말 포함하여 계산 하기
					if(<?= $setting['set_campaign_holiday_include_yn']?> == 0){	
						//토/일요일 포함.
						if(<?=$setting['set_weekend_holidays_yn']?> == 1 ){
							//토요일이 있으면 +2 하기.
							if(day_confirm == 6){					
								m_date.setDate(m_date.getDate() + 2);
								review_start_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
							}
						}
						//일요일 포함.
						if(<?=$setting['set_weekend_holidays_yn']?> == 0 ){
							//일요일이 있으면 +1 하기.
							if(day_confirm == 0){
								m_date.setDate(m_date.getDate() + 1);
								review_start_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
							}
						}
					}
					
				}
			}			
		});
		
		//주말 포함하여 계산 하기
		if(<?= $setting['set_campaign_holiday_include_yn']?> == 0){
			//다시 요일확인(토/일요일이 마지막 날인지 확인하기 위해서)
			day_confirm = new Date(m_date).getDay();
			if(<?=$setting['set_weekend_holidays_yn']?> == 1 ){
				//토요일이 마지막 날이면 +2 하기.
				if(day_confirm == 6){			
					m_date.setDate(m_date.getDate() + 2);
					review_start_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
				}
				//일요일이 마지막 날이면 +1 하기.
				if(day_confirm == 0){			
						m_date.setDate(m_date.getDate() + 1);
						review_start_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
				}
			}
			
			//일요일이 마지막 날이면 +1 하기.
			day_confirm = new Date(m_date).getDay();
			if(<?=$setting['set_weekend_holidays_yn']?> == 0 && day_confirm == 0){						
				m_date.setDate(m_date.getDate() + 1);
				review_start_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();				
			}
		}
		
		$('#cam_review_start_dt').val( review_start_dt_make );

//***** 리뷰 등록 끝 자동입력 ******				
		//이전 날짜값 분할하기
		arr = review_start_dt_make.split('-');
		var m_date4 = new Date( arr[0],arr[1]-1,arr[2] );
		
		m_date.setDate(m_date.getDate() + <?=$setting['set_campaign_review_end_dday']?>);		
		var review_end_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
		
		//주말 포함하여 계산 하기
		if(<?= $setting['set_campaign_holiday_include_yn']?> == 0){			
			cnt_Day =  <?=$setting['set_campaign_review_end_dday']?>;
			
			//시작~끝 날짜안에 토/일 있는지 검사.
			for(var i = 1; i <= cnt_Day; i++){
				m_date4.setDate(m_date4.getDate() + 1);
				start_day = new Date(m_date4).getDay(); //요일 추출
				
				//익스에서는 안됨.
				//start_val = m_date4.getFullYear() + "," + (m_date4.getMonth()+1) + "," + m_date4.getDate();//앞에 날짜값 추출
				//start_day = new Date(start_val).getDay(); //요일 추출
			
				//일요일이 있으면 +1.
				if(<?=$setting['set_weekend_holidays_yn']?> == 0 && start_day == 0){					
					m_date.setDate(m_date.getDate() + 1);
					review_end_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
				}				
				//주말설정 : 토/일요일. 
				if(<?=$setting['set_weekend_holidays_yn']?> == 1 && start_day == 6){					
					m_date.setDate(m_date.getDate() + 2);
					review_end_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
					
					//요일확인(일요일이 마지막 날인지 확인하기 위해서)
					day_confirm = new Date(m_date).getDay();					
					//일요일이 마지막 날이면 +1 하기.
					if(day_confirm == 0){						
						m_date.setDate(m_date.getDate() + 1);
						review_end_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
					}
				}
				//주말설정 : 일요일. ( 르푸돌면서 적용됨. )
				//if(<?=$setting['set_weekend_holidays_yn']?> == 1 && start_day == 0){	
				//	m_date.setDate(m_date.getDate() + 1);
				//	review_end_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
				//}
			}			
		}

		//공휴일 확인 및 작업
		$.each( holidays_array, function(index,value){
			value1 = value.replace(/'/gi,'');
						
			//공휴일 날짜 월,일 1자리를 2자리로 만들기.
			value2 = stringToYYYYMMDD(value1);
			start_dt_val2 = stringToYYYYMMDD(review_start_dt_make);
			recruit_end_make2 = stringToYYYYMMDD(review_end_dt_make);
			
			strDate = new Date(value2);
			endDate = new Date(start_dt_val2);
			endDate2 = new Date(recruit_end_make2);
			
			if( strDate >= endDate){
				if(strDate <= endDate2){
					//요일먼저 확인
					day_confirm = new Date(m_date).getDay();
					
					//공휴일 있으면 +1씩 하기
					m_date.setDate(m_date.getDate() + 1);
					review_end_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
				
					//주말 포함하여 계산 하기
					if(<?= $setting['set_campaign_holiday_include_yn']?> == 0){	
						//토/일요일 포함.
						if(<?=$setting['set_weekend_holidays_yn']?> == 1 ){
							//토요일이 있으면 +2 하기.
							if(day_confirm == 6){					
								m_date.setDate(m_date.getDate() + 2);
								review_end_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
							}
						}
						//일요일 포함.
						if(<?=$setting['set_weekend_holidays_yn']?> == 0 ){
							//일요일이 있으면 +1 하기.
							if(day_confirm == 0){
								m_date.setDate(m_date.getDate() + 1);
								review_end_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
							}
						}
					}
					
				}
			}
		});
	
		//주말 포함하여 계산 하기
		if(<?= $setting['set_campaign_holiday_include_yn']?> == 0){	
			//다시 요일확인(토/일요일이 마지막 날인지 확인하기 위해서)
			day_confirm = new Date(m_date).getDay();
			if(<?=$setting['set_weekend_holidays_yn']?> == 1 ){
				//토요일이 마지막 날이면 +2 하기.
				if(day_confirm == 6){			
					m_date.setDate(m_date.getDate() + 2);
					review_end_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
				}
				//일요일이 마지막 날이면 +1 하기.
				if(day_confirm == 0){			
						m_date.setDate(m_date.getDate() + 1);
						review_end_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
				}
			}
			
			//일요일이 마지막 날이면 +1 하기.
			day_confirm = new Date(m_date).getDay();
			if(<?=$setting['set_weekend_holidays_yn']?> == 0 && day_confirm == 0){						
				m_date.setDate(m_date.getDate() + 1);
				review_end_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();				
			}
		}
		$('#cam_review_end_dt').val( review_end_dt_make );
		
//***** 베스트 발표 자동입력 ******	
		//이전 날짜값 분할하기
		arr = review_end_dt_make.split('-');
		var m_date5 = new Date( arr[0],arr[1]-1,arr[2] );
		
		m_date.setDate(m_date.getDate() + <?=$setting['set_campaign_best_select_dday']?>);		
		var best_select_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();		
		
		//주말 포함하여 계산 하기
		if(<?= $setting['set_campaign_holiday_include_yn']?> == 0){			
			cnt_Day =  <?=$setting['set_campaign_best_select_dday']?>;
			
			//시작~끝 날짜안에 토/일 있는지 검사.
			for(var i = 1; i <= cnt_Day; i++){
				m_date5.setDate(m_date5.getDate() + 1);
				start_day = new Date(m_date5).getDay(); //요일 추출
				
				//익스에서는 안됨.
				//start_val = m_date5.getFullYear() + "," + (m_date5.getMonth()+1) + "," + m_date5.getDate();//앞에 날짜값 추출
				//start_day = new Date(start_val).getDay(); //요일 추출
			
				//일요일이 있으면 +1.
				if(<?=$setting['set_weekend_holidays_yn']?> == 0 && start_day == 0){					
					m_date.setDate(m_date.getDate() + 1);
					best_select_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
				}				
				//주말설정 : 토/일요일. 
				if(<?=$setting['set_weekend_holidays_yn']?> == 1 && start_day == 6){					
					m_date.setDate(m_date.getDate() + 2);
					best_select_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
					
					//요일확인(일요일이 마지막 날인지 확인하기 위해서)
					day_confirm = new Date(m_date).getDay();
					//일요일이 마지막 날이면 +1 하기.
					if(day_confirm == 0){
						m_date.setDate(m_date.getDate() + 1);
						best_select_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
					}
				}
				//주말설정 : 일요일. ( 르푸돌면서 적용됨. )
				//if(<?=$setting['set_weekend_holidays_yn']?> == 1 && start_day == 0){					
				//	m_date.setDate(m_date.getDate() + 1);
				//	best_select_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
				//}				
			}			
		}
		
		//공휴일 확인 및 작업
		$.each( holidays_array, function(index,value){
			value1 = value.replace(/'/gi,'');
			
			//공휴일 날짜 월,일 1자리를 2자리로 만들기.
			value2 = stringToYYYYMMDD(value1);
			start_dt_val2 = stringToYYYYMMDD(review_end_dt_make);
			recruit_end_make2 = stringToYYYYMMDD(best_select_dt_make);
			
			strDate = new Date(value2);
			endDate = new Date(start_dt_val2);
			endDate2 = new Date(recruit_end_make2);
			
			if( strDate >= endDate){
				if(strDate <= endDate2){
					//요일먼저 확인
					day_confirm = new Date(m_date).getDay();

					//공휴일 있으면 +1씩 하기
					m_date.setDate(m_date.getDate() + 1);
					best_select_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
				
					//주말 포함하여 계산 하기
					if(<?= $setting['set_campaign_holiday_include_yn']?> == 0){	
						//토/일요일 포함.
						if(<?=$setting['set_weekend_holidays_yn']?> == 1 ){
							//토요일이 있으면 +2 하기.
							if(day_confirm == 6){					
								m_date.setDate(m_date.getDate() + 2);
								best_select_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
							}
						}
						//일요일 포함.
						if(<?=$setting['set_weekend_holidays_yn']?> == 0 ){
							//일요일이 있으면 +1 하기.
							if(day_confirm == 0){
								m_date.setDate(m_date.getDate() + 1);
								best_select_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
							}
						}
					}
					
				}
			}						
		});
		
		//주말 포함하여 계산 하기
		if(<?= $setting['set_campaign_holiday_include_yn']?> == 0){			
			//다시 요일확인(토/일요일이 마지막 날인지 확인하기 위해서)
			day_confirm = new Date(m_date).getDay();
			if(<?=$setting['set_weekend_holidays_yn']?> == 1 ){
				//토요일이 마지막 날이면 +2 하기.
				if(day_confirm == 6){			
					m_date.setDate(m_date.getDate() + 2);
					best_select_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
				}
				//일요일이 마지막 날이면 +1 하기.
				if(day_confirm == 0){			
						m_date.setDate(m_date.getDate() + 1);
						best_select_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();
				}
			}
			
			//일요일이 마지막 날이면 +1 하기.
			day_confirm = new Date(m_date).getDay();
			if(<?=$setting['set_weekend_holidays_yn']?> == 0 && day_confirm == 0){
				m_date.setDate(m_date.getDate() + 1);
				best_select_dt_make = m_date.getFullYear() + "-" + (m_date.getMonth()+1) + "-" + m_date.getDate();				
			}
		}
		
		$('#cam_best_select_dt').val( best_select_dt_make );
		
//***** datepicker 부분 ******
		//리뷰어 신청 종료
		var nowDate = $('#cam_recruit_start_dt').datepicker('getDate');									
		$("#cam_recruit_end_dt").datepicker({
			changeMonth: true,
			changeYear: true,
			dateFormat: "yy-mm-dd",
			showButtonPanel: true,
			yearRange: "c-99:c+99",
			minDate: nowDate,
			beforeShowDay: function(date){
				//주말(토, 일요일) 선택 막기
				var day = date.getDay();
				
				// 특정일 선택막기				
				var m = date.getMonth(), d = date.getDate(), y = date.getFullYear();
				for (i = 0; i < disabledDays.length; i++) {
					if($.inArray(y + '-' +(m+1) + '-' + d,disabledDays) != -1) {
						return [false];
					}
				}
				
				//주말 포함하여 계산
				if(<?= $setting['set_campaign_holiday_include_yn']?> == 0){
					if(<?=$setting['set_weekend_holidays_yn']?> == 0){
						return [true],[(day != 0)]; //일 주말 설정
					}
					else{
						return [true],[(day != 0 && day != 6)]; //토 / 일 주말 설정 
					}					
				}
				//주말 건너뛰고 계산
				else{
					return [true];
				}
			}
		});
		
		
		//리뷰어 발표
		var recruit_start = $("#cam_recruit_end_dt").val();		
		var recruit_start_array = recruit_start.split('-');
		var recruit_start_year = recruit_start_array[0];
		var recruit_start_month = recruit_start_array[1];
		var recruit_start_day = recruit_start_array[2];		
		$("#cam_notice_dt").datepicker({
			changeMonth: true,
			changeYear: true,
			dateFormat: "yy-mm-dd",
			showButtonPanel: true,
			yearRange: "c-99:c+99",
			minDate: new Date(recruit_start_year, recruit_start_month - 1, recruit_start_day),
			beforeShowDay: function(date){
				//주말(토, 일요일) 선택 막기
				var day = date.getDay();
				
				// 특정일 선택막기				
				var m = date.getMonth(), d = date.getDate(), y = date.getFullYear();
				for (i = 0; i < disabledDays.length; i++) {
					if($.inArray(y + '-' +(m+1) + '-' + d,disabledDays) != -1) {
						return [false];
					}
				}
				
				//주말 포함하여 계산
				if(<?= $setting['set_campaign_holiday_include_yn']?> == 0){
					if(<?=$setting['set_weekend_holidays_yn']?> == 0){
						return [true],[(day != 0)]; //일 주말 설정
					}
					else{
						return [true],[(day != 0 && day != 6)]; //토 / 일 주말 설정 
					}					
				}
				//주말 건너뛰고 계산
				else{					
					return [true];
				}
			}
		});
		
		//리뷰등록 시작
		var nowDate = $('#cam_notice_dt').datepicker('getDate');		
		$("#cam_review_start_dt").datepicker({
			changeMonth: true,
			changeYear: true,
			dateFormat: "yy-mm-dd",
			showButtonPanel: true,
			yearRange: "c-99:c+99",
			minDate: nowDate,
			beforeShowDay: function(date){
				//주말(토, 일요일) 선택 막기
				var day = date.getDay();
				
				// 특정일 선택막기				
				var m = date.getMonth(), d = date.getDate(), y = date.getFullYear();
				for (i = 0; i < disabledDays.length; i++) {
					if($.inArray(y + '-' +(m+1) + '-' + d,disabledDays) != -1) {
						return [false];
					}
				}
				
				//주말 포함하여 계산
				if(<?= $setting['set_campaign_holiday_include_yn']?> == 0){
					if(<?=$setting['set_weekend_holidays_yn']?> == 0){
						return [true],[(day != 0)]; //일 주말 설정
					}
					else{
						return [true],[(day != 0 && day != 6)]; //토 / 일 주말 설정 
					}					
				}
				//주말 건너뛰고 계산
				else{					
					return [true];
				}
			}
		});
		
		//리뷰등록 종료		
		var nowDate = $('#cam_review_start_dt').datepicker('getDate');				
		$("#cam_review_end_dt").datepicker({
			changeMonth: true,
			changeYear: true,
			dateFormat: "yy-mm-dd",
			showButtonPanel: true,
			yearRange: "c-99:c+99",
			minDate: nowDate,
			beforeShowDay: function(date){
				//주말(토, 일요일) 선택 막기
				var day = date.getDay();
				
				// 특정일 선택막기				
				var m = date.getMonth(), d = date.getDate(), y = date.getFullYear();
				for (i = 0; i < disabledDays.length; i++) {
					if($.inArray(y + '-' +(m+1) + '-' + d,disabledDays) != -1) {
						return [false];
					}
				}
				
				//주말 포함하여 계산
				if(<?= $setting['set_campaign_holiday_include_yn']?> == 0){
					if(<?=$setting['set_weekend_holidays_yn']?> == 0){
						return [true],[(day != 0)]; //일 주말 설정
					}
					else{
						return [true],[(day != 0 && day != 6)]; //토 / 일 주말 설정 
					}					
				}
				//주말 건너뛰고 계산
				else{					
					return [true];
				}
			}
		});
		
		//베스트 발표
		var nowDate = $('#cam_review_end_dt').datepicker('getDate');				
		$("#cam_best_select_dt").datepicker({
			changeMonth: true,
			changeYear: true,
			dateFormat: "yy-mm-dd",
			showButtonPanel: true,
			yearRange: "c-99:c+99",
			minDate: nowDate,
			beforeShowDay: function(date){
				//주말(토, 일요일) 선택 막기
				var day = date.getDay();
				
				// 특정일 선택막기				
				var m = date.getMonth(), d = date.getDate(), y = date.getFullYear();
				for (i = 0; i < disabledDays.length; i++) {
					if($.inArray(y + '-' +(m+1) + '-' + d,disabledDays) != -1) {
						return [false];
					}
				}
				
				//주말 포함하여 계산
				if(<?= $setting['set_campaign_holiday_include_yn']?> == 0){
					if(<?=$setting['set_weekend_holidays_yn']?> == 0){
						return [true],[(day != 0)]; //일 주말 설정
					}
					else{
						return [true],[(day != 0 && day != 6)]; //토 / 일 주말 설정 
					}					
				}
				//주말 건너뛰고 계산
				else{					
					return [true];
				}
			}
		});

		//리뷰신청 날짜가 빈값이면 전부 초기화.
		$cam_recruit_start_val = $(this).val();
		if($cam_recruit_start_val == ''){			
			//나머지들 초기화.		
			$('#cam_recruit_end_dt').val('').css("background","#EAEAEA").attr('disabled',true);
			$('#cam_notice_dt').val('').css("background","#EAEAEA").attr('disabled',true);
			$('#cam_review_start_dt').val('').css("background","#EAEAEA").attr('disabled',true);
			$('#cam_review_end_dt').val('').css("background","#EAEAEA").attr('disabled',true);
			$('#cam_best_select_dt').val('').css("background","#EAEAEA").attr('disabled',true);
		}	

	});
	
});

	//리뷰어 발표 (개별로 변경시.)
	$("#cam_recruit_end_dt").change(function(){
		//활성화하기
		$('#cam_notice_dt').val('').css("background","#fff").attr('disabled',false).removeClass('hasDatepicker');		
		
		//나머지들 초기화.		
		$('#cam_review_start_dt').val('').css("background","#EAEAEA").attr('disabled',true);
		$('#cam_review_end_dt').val('').css("background","#EAEAEA").attr('disabled',true);
		$('#cam_best_select_dt').val('').css("background","#EAEAEA").attr('disabled',true);

		//리뷰어 신청
		var recruit_start = $("#cam_recruit_end_dt").val();
			
		//날짜 자르기
		var recruit_start_array = recruit_start.split('-');
		var recruit_start_year = recruit_start_array[0];
		var recruit_start_month = recruit_start_array[1];
		var recruit_start_day = recruit_start_array[2];
		
		$("#cam_notice_dt").datepicker({
			changeMonth: true,
			changeYear: true,
			dateFormat: "yy-mm-dd",
			showButtonPanel: true,
			yearRange: "c-99:c+99",
			minDate: new Date(recruit_start_year, recruit_start_month - 1, recruit_start_day),
			beforeShowDay: function(date){
				//주말(토, 일요일) 선택 막기
				var day = date.getDay();
				
				// 특정일 선택막기				
				var m = date.getMonth(), d = date.getDate(), y = date.getFullYear();
				for (i = 0; i < disabledDays.length; i++) {
					if($.inArray(y + '-' +(m+1) + '-' + d,disabledDays) != -1) {
						return [false];
					}
				}
				
				//주말 포함하여 계산
				if(<?= $setting['set_campaign_holiday_include_yn']?> == 0){
					if(<?=$setting['set_weekend_holidays_yn']?> == 0){
						return [true],[(day != 0)]; //일 주말 설정
					}
					else{
						return [true],[(day != 0 && day != 6)]; //토 / 일 주말 설정 
					}					
				}
				//주말 건너뛰고 계산
				else{					
					return [true];
				}
			}
		});
	});
		
	//리뷰 등록 시작
	$("#cam_notice_dt").change(function(){
		//활성화하기
		$('#cam_review_start_dt').val('').css("background","#fff").attr('disabled',false).removeClass('hasDatepicker');
		
		//나머지들 초기화.
		$('#cam_review_end_dt').val('').css("background","#EAEAEA").attr('disabled',true);
		$('#cam_best_select_dt').val('').css("background","#EAEAEA").attr('disabled',true);
		
		//리뷰어 신청
		var nowDate = $('#cam_notice_dt').datepicker('getDate');
		
		$("#cam_review_start_dt").datepicker({
			changeMonth: true,
			changeYear: true,
			dateFormat: "yy-mm-dd",
			showButtonPanel: true,
			yearRange: "c-99:c+99",
			minDate: nowDate,
			beforeShowDay: function(date){
				//주말(토, 일요일) 선택 막기
				var day = date.getDay();
				
				// 특정일 선택막기				
				var m = date.getMonth(), d = date.getDate(), y = date.getFullYear();
				for (i = 0; i < disabledDays.length; i++) {
					if($.inArray(y + '-' +(m+1) + '-' + d,disabledDays) != -1) {
						return [false];
					}
				}
				
				//주말 포함하여 계산
				if(<?= $setting['set_campaign_holiday_include_yn']?> == 0){
					if(<?=$setting['set_weekend_holidays_yn']?> == 0){
						return [true],[(day != 0)]; //일 주말 설정
					}
					else{
						return [true],[(day != 0 && day != 6)]; //토 / 일 주말 설정 
					}					
				}
				//주말 건너뛰고 계산
				else{					
					return [true];
				}
			}
		});
	});
	
	//리뷰 등록 끝
	$("#cam_review_start_dt").change(function(){
		//활성화하기
		$('#cam_review_end_dt').val('').css("background","#fff").attr('disabled',false).removeClass('hasDatepicker');
		
		//나머지들 초기화.		
		$('#cam_best_select_dt').val('').css("background","#EAEAEA").attr('disabled',true);
				
		//리뷰어 신청
		var nowDate = $('#cam_review_start_dt').datepicker('getDate');
				
		$("#cam_review_end_dt").datepicker({
			changeMonth: true,
			changeYear: true,
			dateFormat: "yy-mm-dd",
			showButtonPanel: true,
			yearRange: "c-99:c+99",
			minDate: nowDate,
			beforeShowDay: function(date){
				//주말(토, 일요일) 선택 막기
				var day = date.getDay();
				
				// 특정일 선택막기				
				var m = date.getMonth(), d = date.getDate(), y = date.getFullYear();
				for (i = 0; i < disabledDays.length; i++) {
					if($.inArray(y + '-' +(m+1) + '-' + d,disabledDays) != -1) {
						return [false];
					}
				}
				
				//주말 포함하여 계산
				if(<?= $setting['set_campaign_holiday_include_yn']?> == 0){
					if(<?=$setting['set_weekend_holidays_yn']?> == 0){
						return [true],[(day != 0)]; //일 주말 설정
					}
					else{
						return [true],[(day != 0 && day != 6)]; //토 / 일 주말 설정 
					}					
				}
				//주말 건너뛰고 계산
				else{					
					return [true];
				}
			}
		});
	});	
	
	//리뷰 등록 끝
	$("#cam_review_end_dt").change(function(){
		//활성화하기
		$('#cam_best_select_dt').val('').css("background","#fff").attr('disabled',false).removeClass('hasDatepicker');		
		//리뷰어 신청
		var nowDate = $('#cam_review_end_dt').datepicker('getDate');
				
		$("#cam_best_select_dt").datepicker({
			changeMonth: true,
			changeYear: true,
			dateFormat: "yy-mm-dd",
			showButtonPanel: true,
			yearRange: "c-99:c+99",
			minDate: nowDate,
			beforeShowDay: function(date){
				//주말(토, 일요일) 선택 막기
				var day = date.getDay();
				
				// 특정일 선택막기				
				var m = date.getMonth(), d = date.getDate(), y = date.getFullYear();
				for (i = 0; i < disabledDays.length; i++) {
					if($.inArray(y + '-' +(m+1) + '-' + d,disabledDays) != -1) {
						return [false];
					}
				}
				
				//주말 포함하여 계산
				if(<?= $setting['set_campaign_holiday_include_yn']?> == 0){
					if(<?=$setting['set_weekend_holidays_yn']?> == 0){
						return [true],[(day != 0)]; //일 주말 설정
					}
					else{
						return [true],[(day != 0 && day != 6)]; //토 / 일 주말 설정 
					}					
				}
				//주말 건너뛰고 계산
				else{					
					return [true];
				}
			}
		});
	});	
	
}
//수정
else{	
	//리뷰어 신청 시작
	$("#cam_recruit_start_dt,#cam_recruit_end_dt,#cam_notice_dt,#cam_review_start_dt,#cam_review_end_dt,#cam_best_select_dt").datepicker({
		changeMonth: true,
		changeYear: true,
		dateFormat: "yy-mm-dd",
		showButtonPanel: true,
		yearRange: "c-99:c+99",
		beforeShowDay: function(date){
			//주말(토, 일요일) 선택 막기
			var day = date.getDay();
			
			// 특정일 선택막기				
			var m = date.getMonth(), d = date.getDate(), y = date.getFullYear();
			for (i = 0; i < disabledDays.length; i++) {
				if($.inArray(y + '-' +(m+1) + '-' + d,disabledDays) != -1) {
					return [false];
				}
			}
			
			//주말 포함하여 계산
			if(<?= $setting['set_campaign_holiday_include_yn']?> == 0){
				if(<?=$setting['set_weekend_holidays_yn']?> == 0){
					return [true],[(day != 0)]; //일 주말 설정
				}
				else{
					return [true],[(day != 0 && day != 6)]; //토 / 일 주말 설정 
				}					
			}
			//주말 건너뛰고 계산
			else{					
				return [true];
			}
		}
		//,maxDate: "+1d"
		//,minDate: "+1d"
	});		
}
// **** 달력 ****
</script>

<script>
//업체페이지에서 상단 캠페인신청으로 진행했을때 사용되는 함수.
function goods_name(g){	
	var blog_array = g.split(',');
	var blog_ck = blog_array[1];
	var set_naver_product = $("input[name='set_naver_product']").val();
	
	//블로그상품 확인-신규 , -1 = 없다. 
	if( set_naver_product.indexOf(blog_ck) != '-1' ){ 
		$(".channel_50").show();
	}else{
		$(".channel_50").hide();
	}
	//console.log( set_naver_product );
	//console.log( blog_ck );
	//console.log( set_naver_product.indexOf(blog_ck) );		
}

$(function(){	
	//신청관리에서 캠페인 진행했을때.
	//블로그상품 확인 변수 (있을때만 1)
	var blog_check = $("input[name='blog_check']").val();
	//블로그상품 확인-신규
	if( blog_check ){
		$(".channel_50").show();
	}
	
	var w = $('input[name=w]').val();	
	//모집인원 입력
	if( w != 'u' ){
		$('select[name=goods_check]').change(function(){
			var goods_check = $('select[name=goods_check]').val();
			var goods_check_array = goods_check.split(',');
			//pdo_recruit_count는 5번째 있음.
			var pdo_recruit_count = goods_check_array[4];
			
			$('input[name=cam_recruit_count]').val( pdo_recruit_count );
			
			$('.div_recruit_count').text('');
			$('.div_recruit_count').text( pdo_recruit_count+' 명' );
			//alert(pdo_recruit_count);
		});		
	}
		
	//if( w == 'u' ){
	//	$cam_type_val = $( 'input:radio[name=cam_type]:checked' ).val();		
	//	if($cam_type_val == 'visite'){			
	//		$(".cam_content_type1").show();
	//		$(".cam_content_type2").hide();
	//	}
	//	if($cam_type_val == 'delivery'){
	//		$(".cam_content_type2").show();
	//		$(".cam_content_type1").hide();
	//		$(".cam_content_type2").css('padding-top','0px');
	//	}
	//}
	
	//내용 방문형 배송형 따라서 변경하기.
	$('input:radio[name=cam_type]').change(function(){
		$cam_type_val = $( 'input:radio[name=cam_type]:checked' ).val();
		if($cam_type_val == 'visite'){			
			$(".cam_content_type1").show();
			$(".cam_content_type2").hide();
			$(".cam_content_PressCorps").hide();
			
		}
		if($cam_type_val == 'delivery'){
			$(".cam_content_type1").hide();
			$(".cam_content_type2").show();			
			$(".cam_content_PressCorps").hide();
			$(".cam_content_type2").css('padding-top','0px');
		}
		if($cam_type_val == 'PressCorps'){
			$(".cam_content_type1").hide();
			$(".cam_content_type2").hide();			
			$(".cam_content_PressCorps").show();
			$(".cam_content_PressCorps").css('padding-top','0px');
		}
	});
});


// submit 최종 폼체크
function cp_f_submit1(f)
{
	//구매상품선택(신규) com_idx	
	if('<?php echo $kfi?>' == '1'){
		if (f.goods_check.value.length < 1) {			
			alert("구매상품을 선택해주세요.");
			f.goods_check.focus();
			return false;
		};
	}
	
	//업체명 com_idx	
	if (f.com_idx.value.length < 1) {
		alert("업체명을 선택해주세요.");
		f.com_idx.focus();
		return false;
	};	
	//카테고리1
	if (f.cat1_trm_idxs.value.length < 1) {
		alert("카테고리1를 선택해주세요.");
		f.cat1_trm_idxs.focus();
		return false;
	};
	//캠페인명
	if (f.cam_name.value.length < 1) {
		alert("캠페인명을 입력해주세요.");
		f.cam_name.focus();
		return false;
	};
	//등록 가능 리뷰 sns_channel_46
	if( !$("input[name='sns_channel[]']").is(':checked') ){		
		alert("등록 가능 리뷰을 1개 이상 선택해주세요.");		
		return false;
	}
	//캠페인 기간 설정들	
	if (f.cam_recruit_start_dt.value.length < 1) {
		alert("리뷰어 신청 시작 기간설정을 입력해주세요.");
		 f.cam_recruit_start_dt.focus();
		return false;
	};
	if (f.cam_recruit_end_dt.value.length < 1) {
		alert("리뷰어 신청 끝 기간설정을 입력해주세요.");
		 f.cam_recruit_end_dt.focus();
		return false;
	};
	if (f.cam_notice_dt.value.length < 1) {
		alert("리뷰어 발표 기간설정을 입력해주세요.");
		 f.cam_notice_dt.focus();
		return false;
	};
	if (f.cam_review_start_dt.value.length < 1) {
		alert("리뷰 등록 시작 기간설정을 입력해주세요.");
		 f.cam_review_start_dt.focus();
		return false;
	};
	if (f.cam_review_end_dt.value.length < 1) {
		alert("리뷰 등록 끝 기간설정을 입력해주세요.");
		 f.cam_review_end_dt.focus();
		return false;
	};
	if(f.cam_best_use_yn.value == '1'){
		if (f.cam_best_select_dt.value.length < 1) {
			alert("베스트 발표 기간설정을 입력해주세요.");
			f.cam_best_select_dt.focus();
			return false;
		};
	}
	//복사테그
	if (f.cam_tags.value.length < 2) {
		alert("두자이상 복사테그을 입력해주세요.");
		f.cam_tags.focus();
		return false;
	};
	
	
	
	//캠페인 타입
	$cam_type = $('input:radio[name="cam_type"]').is(":checked");	
	if( $cam_type == false ){		
		alert("캠페인 타입을 선택해주세요.");
		$('#cam_type1').focus();
		return false;
	}
	
	//방문형,배송형에 따라서 기본 내용부분 변경때문.
	var w = $('input[name=w]').val();
	
	<?php echo get_editor_js("cam_content"); ?>
	<?php echo get_editor_js("cam_content1"); ?>
	<?php echo get_editor_js("cam_content2"); ?>
	
	//내용확인(수정)
	//if(f.w.value == 'u'){
	//	<?php echo chk_editor_js("cam_content"); ?>
	//};
			
	//업데이트 중에 두번클릭 막기.
	//document.getElementById("btn_submit").disabled = "disabled";
	//document.getElementById("btn_submit2").disabled = "disabled";
	//document.getElementById("btn_cancel").disabled = "disabled";
	
	$("#btn_submit").hide();
	$("#btn_cancel").hide();
	$("#btn_submit2").hide();
	$(".cam_copy").hide();
	
	$(".btn_confirm").append(" <img src='"+g5_theme_url+"/img/loading.gif' alt=''> <div class='up_ing'>등록중 입니다.</div>");
	
	//일괄수정  = 1, 일반수정 = 0
	//alert(f.cam_auto.value);
		
	//return true;
}

	
// 일괄수정 클릭.
$('#btn_submit2').click(function(){	
	var result = confirm( '[ <?=$proo['pdo_prd_name']?> 상품 ] 캠페인들 기간설정을 일괄수정 하시겠습니까?' );
	if(result){
		$("#cam_auto").val(1); //value 값 변경(일괄수정  = 1, 일반수정 = 0).
		$("#cp_f").submit();
	}else{
		return false;
	}
});

</script>

<!--다음 지도 (campaign_form.js 안에도 지도 코드가 있음. 수정 할때 보여지기 위해서 여기도 선언함.!!! ) {-->
<script src="//apis.daum.net/maps/maps3.js?apikey=3897b932a47d6c2a935edad34443c63d&libraries=services"></script>
<script>
$(function() { 	
	$(document).on('change','select[name=com_idx]',function(e) {
		setTimeout(function(e){
			$('#map').css('display','block');
			$com_latitude = $('#com_latitude').val();
			$com_longitude = $('#com_longitude').val();
			
			//alert($com_latitude);
			//alert($com_longitude);
			
			var mapContainer = document.getElementById('map'), // 지도를 표시할 div
				mapOption = {
					center: new daum.maps.LatLng($com_latitude,$com_longitude), // 지도의 중심좌표
					level: 3 // 지도의 확대 레벨
				};
			
			//지도를 미리 생성
			var map = new daum.maps.Map(mapContainer, mapOption);
			//주소-좌표 변환 객체를 생성
			var geocoder = new daum.maps.services.Geocoder();
			//마커를 미리 생성
			var marker = new daum.maps.Marker({
				position: new daum.maps.LatLng($com_latitude,$com_longitude),
				map: map
			});	
		},1600);
	});
	
	//수정할때
	if('<?=$w?>' == 'u'){
		$('#map').css('display','block');
		$com_latitude = $('#com_latitude').val();
		$com_longitude = $('#com_longitude').val();
		
		//alert($com_latitude);
		//alert($com_longitude);
		
		var mapContainer = document.getElementById('map'), // 지도를 표시할 div
			mapOption = {
				center: new daum.maps.LatLng($com_latitude,$com_longitude), // 지도의 중심좌표
				level: 3 // 지도의 확대 레벨
			};
		
		//지도를 미리 생성
		var map = new daum.maps.Map(mapContainer, mapOption);
		//주소-좌표 변환 객체를 생성
		var geocoder = new daum.maps.services.Geocoder();
		//마커를 미리 생성
		var marker = new daum.maps.Marker({
			position: new daum.maps.LatLng($com_latitude,$com_longitude),
			map: map
		});	
	}
	
});
</script>